#!/usr/bin/env python3
import curses

from sokoban_game.game import main


if __name__ == "__main__":
    curses.wrapper(main)
