from dataclasses import dataclass
from typing import Set, Tuple

from .levels import Level


@dataclass
class State:
    level: Level
    boxes: Set[Tuple[int, int]]
    player: Tuple[int, int]
    moves: int = 0


@dataclass
class RenderCache:
    last_size: Tuple[int, int]
