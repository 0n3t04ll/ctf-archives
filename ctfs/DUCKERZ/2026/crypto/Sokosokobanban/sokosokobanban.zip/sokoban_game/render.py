import curses
from typing import Dict, Set, Tuple

from .config import CELL_W, GLYPHS
from .levels import Level
from .state import RenderCache, State


def init_colors() -> Dict[str, int]:
    colors = {}
    if not curses.has_colors():
        return colors
    curses.start_color()
    curses.use_default_colors()

    curses.init_pair(1, curses.COLOR_BLUE, -1)    # walls
    curses.init_pair(2, curses.COLOR_YELLOW, -1)  # goals
    curses.init_pair(3, curses.COLOR_CYAN, -1)    # boxes
    curses.init_pair(4, curses.COLOR_GREEN, -1)   # player
    curses.init_pair(5, curses.COLOR_MAGENTA, -1) # box on goal

    colors = {
        "#": curses.color_pair(1),
        ".": curses.color_pair(2),
        "$": curses.color_pair(3),
        "@": curses.color_pair(4) | curses.A_BOLD,
        "*": curses.color_pair(5) | curses.A_BOLD,
        "+": curses.color_pair(4) | curses.A_BOLD,
    }
    return colors


def cell_char(level: Level, player: Tuple[int, int], boxes: Set[Tuple[int, int]], pos: Tuple[int, int]) -> str:
    if pos in level.walls:
        return "#"
    if pos == player:
        return "+" if pos in level.goals else "@"
    if pos in boxes:
        return "*" if pos in level.goals else "$"
    if pos in level.goals:
        return "."
    return " "


def cell_glyph(ch: str) -> str:
    glyph = GLYPHS.get(ch, "  ")
    if len(glyph) < CELL_W:
        glyph = glyph.ljust(CELL_W)
    return glyph[:CELL_W]


def render(
    stdscr,
    state: State,
    level_idx: int,
    level_count: int,
    cache: RenderCache,
    colors: Dict[str, int],
    message: str,
) -> None:
    h, w = stdscr.getmaxyx()
    if (h, w) != cache.last_size:
        stdscr.erase()
        cache.last_size = (h, w)

    header = f"Level {level_idx + 1}/{level_count}  Ходов: {state.moves}  (Стрелочки/WASD, R сброс, Q выход. Если не работает, смените язык)"
    msg = message

    display_w = state.level.width * CELL_W
    needed_h = state.level.height + 3
    needed_w = max(display_w, len(header), len(msg)) + 2

    if h < needed_h or w < needed_w:
        stdscr.erase()
        warning = f"Терминал слишком мал. Нужно {needed_w}x{needed_h}, есть {w}x{h}."
        stdscr.addnstr(0, 0, warning, max(0, w - 1))
        stdscr.clrtoeol()
        stdscr.refresh()
        return

    stdscr.addnstr(0, 0, header, w - 1)
    stdscr.clrtoeol()
    stdscr.addnstr(1, 0, msg, w - 1)
    stdscr.clrtoeol()

    origin_y = 2
    origin_x = max(0, (w - display_w) // 2)

    for y in range(state.level.height):
        for x in range(state.level.width):
            pos = (y, x)
            ch = cell_char(state.level, state.player, state.boxes, pos)
            attr = colors.get(ch, 0)
            glyph = cell_glyph(ch)
            stdscr.addstr(origin_y + y, origin_x + x * CELL_W, glyph, attr)

    stdscr.refresh()
