import curses
import os
from typing import Dict

from .config import MOVE_ACTIONS, SEED_ACTION_BITS
from .input import build_key_actions
from .levels import LEVELS, Level, parse_level
from .logic import is_solved, try_move
from .rng import Lcg64, SeedCollector
from .render import init_colors, render
from .state import RenderCache, State


def play_level(
    stdscr,
    level: Level,
    level_idx: int,
    level_count: int,
    colors: Dict[str, int],
    seed_collector: SeedCollector,
) -> str:
    state = State(level=level, boxes=set(level.boxes), player=level.player)
    cache = RenderCache(last_size=stdscr.getmaxyx())
    message = ""
    key_actions = build_key_actions()

    while True:
        render(stdscr, state, level_idx, level_count, cache, colors, message)
        ch = stdscr.getch()

        if ch == curses.KEY_RESIZE:
            continue

        action = key_actions.get(ch)

        seed_bits = SEED_ACTION_BITS.get(action) if action else None
        if seed_bits is not None:
            seed_collector.feed_bits(seed_bits)

        if action in MOVE_ACTIONS:
            moved = False
            if action == "up":
                moved = try_move(state, -1, 0)
            elif action == "down":
                moved = try_move(state, 1, 0)
            elif action == "left":
                moved = try_move(state, 0, -1)
            elif action == "right":
                moved = try_move(state, 0, 1)
            if moved:
                message = ""
            else:
                message = ""
        elif action == "reset":
            state.boxes = set(level.boxes)
            state.player = level.player
            state.moves = 0
            message = "Уровень сброшен."
        elif action == "quit":
            return "quit"

        if is_solved(level, state.boxes):
            message = "Уровень пройден! Нажмите Enter, чтобы продолжить."
            render(stdscr, state, level_idx, level_count, cache, colors, message)
            curses.napms(250)
            while True:
                key = stdscr.getch()
                if key in (curses.KEY_ENTER, 10, 13):
                    break
            return "cleared"


def end_screen(stdscr, seed_collector: SeedCollector) -> None:
    stdscr.erase()
    h, w = stdscr.getmaxyx()
    if not seed_collector.ready():
        lines = [
            "Ошибка: недостаточно ввода для рандома.",
            "Нажмите любую клавишу, чтобы выйти.",
        ]
    else:
        rng = Lcg64(seed_collector.state)
        lucky = rng.next() == 1
        if lucky:
            lines = [
                "Вы выиграли флаг.",
                "Повезло!",
                "Флаг: DUCKERZ{REDACTED}",
                "Нажмите любую клавишу, чтобы выйти.",
            ]
        else:
            lines = [
                "Вы выиграли, но не флаг.",
                "Рандом сыграл не в вашу пользу.",
                "Попробуйте еще раз (18446744073709551616 раз должно быть достаточно)",
                "Нажмите любую клавишу, чтобы выйти.",
            ]

    start_y = max(0, (h - len(lines)) // 2)
    for i, line in enumerate(lines):
        x = max(0, (w - len(line)) // 2)
        stdscr.addnstr(start_y + i, x, line, max(0, w - 1))
    stdscr.refresh()
    stdscr.getch()


def main(stdscr) -> None:
    curses.curs_set(0)
    stdscr.keypad(True)
    stdscr.nodelay(False)

    colors = init_colors()
    levels = [parse_level(raw) for raw in LEVELS]
    seed_collector = SeedCollector()

    for idx, level in enumerate(levels):
        result = play_level(stdscr, level, idx, len(levels), colors, seed_collector)
        if result == "quit":
            return
    end_screen(stdscr, seed_collector)
