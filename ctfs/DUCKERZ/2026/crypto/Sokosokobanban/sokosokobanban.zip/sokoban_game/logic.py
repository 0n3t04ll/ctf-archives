from typing import Set, Tuple

from .levels import Level
from .state import State


def is_solved(level: Level, boxes: Set[Tuple[int, int]]) -> bool:
    return boxes.issubset(level.goals)


def try_move(state: State, dy: int, dx: int) -> bool:
    py, px = state.player
    ny, nx = py + dy, px + dx
    target = (ny, nx)

    if target in state.level.walls:
        return False
    if target in state.boxes:
        by, bx = ny + dy, nx + dx
        beyond = (by, bx)
        if beyond in state.level.walls or beyond in state.boxes:
            return False
        state.boxes.remove(target)
        state.boxes.add(beyond)
    state.player = target
    state.moves += 1
    return True
