from dataclasses import dataclass
from typing import Optional, Set, Tuple

LEVELS = [
    """
######
#@   #
# ####
# $ .#
######
""",
    """
#########
#   .   #
# $$ @  #
#   .   #
#########
""",
    """
#############
#  .     .  #
#  $$###    #
#   @  # $  #
#      #    #
#  .        #
#############
""",
    """
###############
#  .   .   .  #
#  $$###$$#   #
#  @   #  #   #
#      #  .   #
#      ###    #
###############
""",
    """
###############
#     #.  ..  #
#     #.$ $$$ #
#     #.  .   #
#     ###$$####
#        @    #
#   ##   ##   #
#   ##   ##   #
#             #
#             #
###############
""",
]


@dataclass(frozen=True)
class Level:
    width: int
    height: int
    walls: Set[Tuple[int, int]]
    goals: Set[Tuple[int, int]]
    boxes: Set[Tuple[int, int]]
    player: Tuple[int, int]


def parse_level(raw: str) -> Level:
    lines = [line.rstrip("\n") for line in raw.strip("\n").splitlines()]
    height = len(lines)
    width = max(len(line) for line in lines)

    walls: Set[Tuple[int, int]] = set()
    goals: Set[Tuple[int, int]] = set()
    boxes: Set[Tuple[int, int]] = set()
    player: Optional[Tuple[int, int]] = None

    for y in range(height):
        line = lines[y].ljust(width)
        for x, ch in enumerate(line):
            pos = (y, x)
            if ch == "#":
                walls.add(pos)
            elif ch == ".":
                goals.add(pos)
            elif ch == "$":
                boxes.add(pos)
            elif ch == "@":
                player = pos
            elif ch == "*":
                boxes.add(pos)
                goals.add(pos)
            elif ch == "+":
                player = pos
                goals.add(pos)
            # spaces and unknown chars are floor

    if player is None:
        player = (0, 0)

    return Level(width, height, walls, goals, boxes, player)
