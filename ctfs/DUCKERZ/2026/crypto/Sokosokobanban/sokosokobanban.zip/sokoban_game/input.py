from typing import Dict

from .config import KEY_BINDINGS


def build_key_actions() -> Dict[int, str]:
    mapping: Dict[int, str] = {}
    for action, keys in KEY_BINDINGS.items():
        for k in keys:
            if k in mapping:
                raise ValueError(f"Config contains two or more actions for the key {k}.")
            mapping[k] = action
    return mapping
