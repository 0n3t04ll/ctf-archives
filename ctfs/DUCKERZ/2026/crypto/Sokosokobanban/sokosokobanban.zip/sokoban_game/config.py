import curses

KEY_BINDINGS = {
    "up": [curses.KEY_UP, ord("w"), ord("W")],
    "down": [curses.KEY_DOWN, ord("s"), ord("S")],
    "left": [curses.KEY_LEFT, ord("a"), ord("A")],
    "right": [curses.KEY_RIGHT, ord("d"), ord("D")],
    "reset": [ord("r"), ord("R")],
    "quit": [ord("q"), ord("Q")],
}

MOVE_ACTIONS = {"up", "down", "left", "right"}

SEED_ACTION_BITS = {
    "up": 0,
    "left": 1,
    "down": 2,
    "right": 3,
}

CELL_W = 2
GLYPHS = {
    "#": "##",
    ".": "..",
    "$": "[]",
    "@": "()",
    "*": "[]",
    "+": "()",
    " ": "  ",
}
