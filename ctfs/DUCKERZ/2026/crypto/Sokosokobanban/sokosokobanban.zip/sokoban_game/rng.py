MASK_64 = (1 << 64) - 1

LCG_A = 6364136223846793005
LCG_B = 1442695040888963407


class SeedCollector:
    def __init__(self) -> None:
        self.state = 0
        self.inputs = 0

    def feed_bits(self, bits: int) -> None:
        if self.inputs >= 32:
            return
        self.state = ((self.state << 2) | (bits & 0x3)) & MASK_64
        self.inputs += 1

    def ready(self) -> bool:
        return self.inputs >= 32


class Lcg64:
    def __init__(self, state: int) -> None:
        self.state = state & MASK_64

    def next(self) -> int:
        self.state = (LCG_A * self.state + LCG_B) & MASK_64
        return self.state
