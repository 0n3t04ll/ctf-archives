/*
 * ✨ Волшебный Дневничок ✨
 * Написано с любовью девочкой-волшебницей~
 * Здесь я храню все свои секретики и заклинания! ♡
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* 
 * Каждая запись в моём дневничке - это маленькое чудо! ✿
 * content - сама запись (может быть секретик или заклинание~)
 * size - размер моего послания в байтиках
 */
struct entry {
    int size;
    char * content;
};

/*
 * Странички моего волшебного дневника! ♪
 * На каждой страничке может быть до 32 записей~
 */
struct page {
    struct entry * entries[32];
};

/*
 * Мой драгоценный дневничок! ♡♡♡
 * В нём 32 волшебных странички для всех моих секретов~
 */
struct diary {
    struct page * pages[32];
};

/* Глобальный дневничок - мой самый главный артефакт! ✨ */
struct diary Diary = {
    .pages = { NULL },
};

/*
 * ✿ Добавляю новую страничку в дневничок! ✿
 * Выделяю память магией calloc~ 
 */
void add_page() {
    int page_number;
    printf("Номер странички, пожалуйста~ ✿ ");
    scanf("%d", &page_number);

    /* Проверяю, что номер странички в пределах моей магии */
    if (page_number < 0 || page_number >= 32) {
        puts("Ой-ой! Такой странички не бывает! (╥﹏╥)");
        return;
    }

    /* Нельзя создать страничку дважды, это нарушит баланс магии! */
    if (Diary.pages[page_number] != NULL) {
        puts("Эта страничка уже существует, глупышка~ (◕‿◕)");
        return;
    }

    /* Призываю новую страничку силой calloc! ✨ */
    Diary.pages[page_number] = (struct page *)calloc(1, sizeof(struct page));
    return;
}

/*
 * ♡ Создаю новую записечку на страничке! ♡
 * Здесь я пишу свои секретики~
 */
void create_entry(int page_number) {
    int entry_number;
    printf("Номер записечки~ ♡ ");
    scanf("%d", &entry_number);
    
    if (entry_number < 0 || entry_number >= 32) {
        puts("Такого номера не существует! (。•́︿•̀。)");
        return;
    }

    if (Diary.pages[page_number]->entries[entry_number] != NULL) {
        puts("Тут уже есть секретик! Выбери другое местечко~ (◠‿◠)");
        return;
    }

    printf("Сколько байтиков для секретика? ✧ ");
    int size;
    scanf("%d%*[^\n]%*c", &size);

    /* Выделяю память для нового секретика! */
    char * content = (char *)malloc(size);
    read(0, content, size);  /* Читаю секретик напрямую~ */

    Diary.pages[page_number]->entries[entry_number] = (struct entry *)malloc(sizeof(struct entry));
    Diary.pages[page_number]->entries[entry_number]->content = content;
    Diary.pages[page_number]->entries[entry_number]->size = size;
}

/*
 * ✧ Показываю записечку из дневничка! ✧
 * Время перечитать свои секретики~
 */
void view_entry(int page_number) {
    int entry_number;
    printf("Какую записечку показать? ✧ ");
    scanf("%d", &entry_number);
    
    if (entry_number < 0 || entry_number >= 32) {
        puts("Нет такой записечки! (╯°□°)╯");
        return;
    }

    if (Diary.pages[page_number]->entries[entry_number] == NULL) {
        puts("Тут пусто... может напишем что-нибудь? (◕ᴗ◕✿)");
        return;
    }

    /* Вывожу секретик напрямую через write! */
    write(1, Diary.pages[page_number]->entries[entry_number]->content,
          Diary.pages[page_number]->entries[entry_number]->size);
}

/*
 * ♪ Удаляю записечку - прощай, старый секретик! ♪
 * Освобождаю память заклинанием free~
 */
void delete_entry(int page_number) {
    int entry_number;
    printf("Какую записечку стереть? ♪ ");
    scanf("%d", &entry_number);
    
    if (entry_number < 0 || entry_number >= 32) {
        puts("Нет такой записечки! ╮(╯_╰)╭");
        return;
    }

    if (Diary.pages[page_number]->entries[entry_number] == NULL) {
        puts("Тут и так ничего нет, глупышка~ (≧◡≦)");
        return;
    }

    free(Diary.pages[page_number]->entries[entry_number]->content);  /* Освобождаю память! */
    free(Diary.pages[page_number]->entries[entry_number]);
}

/*
 * ✎ Редактирую записечку - перепишу секретик! ✎
 * Освобождаю старую память и выделяю новую~
 */
void edit_entry(int page_number) {
    int entry_number;
    printf("Какую записечку отредактировать? ✎ ");
    scanf("%d", &entry_number);
    
    if (entry_number < 0 || entry_number >= 32) {
        puts("Нет такой записечки! (╯°□°)╯");
        return;
    }

    if (Diary.pages[page_number]->entries[entry_number] == NULL) {
        puts("Тут пусто... сначала создай записечку! (◕ᴗ◕✿)");
        return;
    }

    read(0, Diary.pages[page_number]->entries[entry_number]->content, Diary.pages[page_number]->entries[entry_number]->size);
    puts("Секретик обновлён! ✨");
}

/*
 * ✿ Открываю страничку дневничка! ✿
 * Здесь можно творить магию с записями~
 */
void view_page() {
    int page_number;
    printf("Какую страничку открыть? ✿ ");
    scanf("%d", &page_number);
    
    if (page_number < 0 || page_number >= 32) {
        puts("Такой странички нет в моём дневничке! (っ˘̩╭╮˘̩)っ");
        return;
    }

    if (Diary.pages[page_number] == NULL) {
        puts("Эта страничка ещё не создана~ Сначала добавь её! (◕‿◕)");
        return;
    }

    /* Волшебное меню для работы со страничкой! */
    for(;;) {
        puts("╔═══════════════════════════════╗");
        puts("║  1. ✏️  Написать секретик      ║");
        puts("║  2. 👀 Прочитать записечку    ║");
        puts("║  3. ✎  Изменить записечку     ║");
        puts("║  4. 🗑️  Стереть записечку      ║");
        puts("║  5. 🚪 Закрыть страничку      ║");
        puts("╚═══════════════════════════════╝");
        int choice;
        scanf("%d", &choice);
        switch(choice) {
            case 1:
                create_entry(page_number);
                break;
            case 2:
                view_entry(page_number);
                break;
            case 3:
                edit_entry(page_number);
                break;
            case 4:
                delete_entry(page_number);
                break;
            case 5:
                return;  /* Выхожу из странички! */
            default:
                puts("Я не понимаю... выбери от 1 до 5! (◎_◎;)");
        }
    } 
}

/*
 * ♡ Удаляю целую страничку из дневничка! ♡
 * Сначала освобождаю все записечки, потом саму страничку~
 */
void delete_page() {
    int page_number;
    printf("Какую страничку удалить? ♡ ");
    scanf("%d", &page_number);
    
    if (page_number < 0 || page_number >= 32) {
        puts("Нет такой странички! (。•́︿•̀。)");
        return;
    }

    if (Diary.pages[page_number] == NULL) {
        puts("Эта страничка и так пустая~ (◠‿◠)");
        return;
    }

    /* Освобождаю все записечки на этой страничке */
    for(int i = 0; i < 32; i++) {
        if (Diary.pages[page_number]->entries[i] != NULL) {
            free(Diary.pages[page_number]->entries[i]->content);
            free(Diary.pages[page_number]->entries[i]);
        }
    }
    
    free(Diary.pages[page_number]);      /* Освобождаю страничку */
    Diary.pages[page_number] = NULL;     /* Обнуляю указатель, чтобы не было багов! */
}

/*
 * ✨ Главная функция - точка входа в волшебный мир! ✨
 * Здесь начинается магия~
 */
int main() {
    /* Отключаю буферизацию для интерактивности! */
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    
    puts("✨ Добро пожаловать в мой Волшебный Дневничок! ✨");
    puts("   Я - девочка-волшебница, и это мои секреты~");
    puts("");
    
    /* Бесконечный цикл волшебного меню! */
    for(;;) {
        puts("╔═══════════════════════════════════╗");
        puts("║  ✿ Что хочешь сделать? ✿          ║");
        puts("║  1. 📄 Добавить страничку         ║");
        puts("║  2. 📖 Открыть страничку          ║");
        puts("║  3. 🗑️  Удалить страничку          ║");
        puts("║  4. 👋 Пока-пока~                 ║");
        puts("╚═══════════════════════════════════╝");
        int choice;
        scanf("%d", &choice);
        switch(choice) {
            case 1:
                add_page();
                break;
            case 2:
                view_page();
                break;
            case 3:
                delete_page();
                break;
            case 4:
                puts("До встречи! Храни свои секретики! ♡✨");
                return 0;
                break;
            default:
                puts("Ой, я не понимаю! Выбери циферку от 1 до 4~ (◕‿◕✿)");
        }
    }
}
