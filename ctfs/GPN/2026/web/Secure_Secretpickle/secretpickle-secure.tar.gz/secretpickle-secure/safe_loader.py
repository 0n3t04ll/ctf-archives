import json
import os
import sys

if __name__ == "__main__" and sys.argv[1] == "decode":
    import pickle
    raw = sys.stdin.buffer.read()
    # firejail at home:
    import seccomp
    f = seccomp.SyscallFilter(seccomp.KILL)
    f.add_rule(seccomp.ALLOW, "write")
    f.load()
    try:
        data = pickle.loads(raw)
        print(json.dumps(data), flush=True)
    except Exception as exc:
        print("error: " + str(exc), file=sys.stderr, flush=True)

def safe_pickle_load(raw):
    import subprocess

    proc = subprocess.run(
        [sys.executable, __file__, "decode"],
        input=raw,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=2,
    )
    if len(proc.stderr) > 0:
        raise ValueError("Error in unpickling: " + proc.stderr.decode())
    return json.loads(proc.stdout)