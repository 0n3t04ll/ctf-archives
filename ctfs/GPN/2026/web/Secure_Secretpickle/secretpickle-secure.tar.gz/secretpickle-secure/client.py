from pyodide.http import pyfetch
from secretpickle import secretpickle_dump, secretpickle_load
from yaml import safe_load
import js
from urllib.parse import unquote

def load_params(default={}):
    s = js.location.search
    if not s.startswith("?"):
        return default
    yaml = unquote(s[1:].replace("=", ": ")).replace("&", "\n")
    loaded = safe_load(yaml)
    if not isinstance(loaded, dict):
        return default
    transform_dotted_keys(loaded)
    print(loaded)
    return loaded

def transform_dotted_keys(d):
    for key, value in list(d.items()):
        try:
            parts = key.split(".")
            if len(parts) > 1:
                del d[key]
                cur = d
                for p in parts[:-1]:
                    if p not in cur:
                        cur[p] = {}
                    cur = cur[p]
                cur[parts[-1]] = value
        except:
            continue

async def call(payload):
    encoded = secretpickle_dump(payload)
    response = await pyfetch(f"/{encoded}", method="POST")
    return secretpickle_load(await response.json())

async def main():
    print("Hello world!")
    pl = load_params({"action": "home"})
    if pl.get("params") is None:
        pl["params"] = {}
    try:
        pl["username"] = js.localStorage.username
        pl["password"] = js.localStorage.password
    except:
        pass
    res = await call(pl)
    handle_response(res)

def html(s):
    js.document.write(js.DOMPurify.sanitize(s))

def handle_response(res):
    if res.get("set_storage"):
        print(f"Setting local storage: {res['set_storage']}")
        for key, value in res["set_storage"].items():
            js.localStorage.setItem(key, value)

    if res["status"] != "ok":
        return js.alert("Error: " + res["message"])
    
    html(res["result"])
    
