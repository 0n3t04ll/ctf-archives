import asyncio
import os
import sys
from urllib.parse import quote

from fastapi import FastAPI, Query
from fastapi.responses import Response
from playwright.async_api import async_playwright

if not os.path.exists("/flag.txt"):
    FLAG= "GPNCTF{FAKE}"
else:
    FLAG = open("/flag.txt").read().strip()
BASE_URL = os.environ.get("BASE_URL", "http://127.0.0.1")
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = "PORT", "3000"

ERROR_PNG = bytes.fromhex(
    "89504e470d0a1a0a0000000d4948445200000001000000010802000000907753"
    "de0000000c49444154789c63606060000000040001f61738550000000049454e44ae426082"
)

busy = False

app = FastAPI()


def action_url(action, **params):
    query = [f"action={quote(action)}"]
    for key, value in params.items():
        query.append(f"params.{key}={quote(str(value))}")
    return f"{BASE_URL}/?{'&'.join(query)}"


async def wait_for_idle(page):
    try:
        await page.wait_for_load_state("networkidle", timeout=5000)
    except Exception:
        pass


async def visit(url):
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        context = await browser.new_context()
        page = await context.new_page()

        try:
            await page.goto(action_url("register", username="admin", password=FLAG))
            await wait_for_idle(page)

            await page.goto(action_url("login", username="admin", password=FLAG))
            await wait_for_idle(page)
            await page.locator("body").wait_for(
                state="visible",
                timeout=5000,
            )
            await page.get_by_text("Logged in successfully").wait_for(timeout=5000)

            await page.goto(action_url("whoami"))
            await wait_for_idle(page)
            await page.get_by_text("admin").wait_for(timeout=5000)

            await page.goto(url)
            await wait_for_idle(page)
            await asyncio.sleep(5)
            screenshot = await page.screenshot(full_page=True)
            print(f"adminbot page content: {await page.content()}", flush=True)
            return screenshot
        finally:
            await context.close()
            await browser.close()


@app.get("/visit")
async def handle_visit(url: str = Query(..., description="URL to visit")):
    global busy
    if busy:
        return Response(
            content=ERROR_PNG,
            media_type="image/png",
            status_code=503,
            headers={"X-Error": "adminbot is busy"},
        )

    busy = True
    try:
        print(f"adminbot visiting {url}", flush=True)
        screenshot = await visit(url)
        return Response(content=bytes(screenshot), media_type="image/png")
    except Exception as exc:
        print(f"adminbot failed: {exc}", file=sys.stderr, flush=True)
        return Response(
            content=ERROR_PNG,
            media_type="image/png",
            status_code=500,
            headers={"X-Error": str(exc)},
        )
    finally:
        busy = False


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=HOST, port=3000)
