import asyncio
from pathlib import Path
import os
import base64
from urllib.parse import quote

from fastapi import FastAPI, Request, Response
from fastapi.staticfiles import StaticFiles
from secretpickle import secretpickle_dump, secretpickle_load
from safe_loader import safe_pickle_load # we have firejail at home
import hashlib

app = FastAPI()
ADMINBOT_HOST = os.environ.get("ADMINBOT_HOST", "127.0.0.1")
ADMINBOT_PORT = 3000

static = StaticFiles(directory="./")
app.mount("/static", static)

@app.get("/")
async def index(request: Request):
    return await static.get_response("index.html", request.scope)

@app.get("/favicon.ico")
async def favicon(request: Request):
    return await static.get_response("favicon.ico", request.scope)

@app.post("/{b64:path}")
async def secretpickle_handle(request: Request, b64: str):
    res = None
    try:
        pl = secretpickle_load(b64, decoder=safe_pickle_load)
        action = pl.get("action", pl.get("a")) # "a" as a fallback since dompurify isn't a fan of "action"
        params = pl.get("params", pl.get("p", {}))
        res = await action_handler(action, params, pl)
        if not isinstance(res, dict):
            raise ValueError("response must be a dict. please tell the author to fix their code")
    except Exception as exc:
        res = {"status": "error", "message": "Internal server error."}
        print(f"Error handling request: {exc}")
    return secretpickle_dump(res)

def ok(res, additional={}):
    return {"status": "ok", "result": res, **additional}

def err(msg):
    return {"status": "error", "message": msg}


USERS = {}
def hash(password):
    return hashlib.sha256(password.encode()).hexdigest()
def login(pl):
    username = pl.get("username")
    password = pl.get("password")
    user = USERS.get(username)
    if not user:
        return None
    if user["password"] != hash(password):
        return None
    return user

async def action_handler(action, params, pl):
    if action == "home":
        def param_mapper(params):
            res = ""
            for key, value in params.items():
                res += f'<label><code>params.{key}=</code><input name="params.{key}" value="{value}"></label><br>'
            return res

        def method(name, desc, params):
            return f"""
                <details><summary>{name}</summary>
                    <p>{desc}</p>
                    <form>
                        <label><code>action=</code><input name="a" value="{name}"></label><br>
                        {param_mapper(params)}
                        <button>Send</button>
                    </form>
                </details>
            """
        return ok(f"""
            <h1>🥒 secretpickle demo</h1>
            <p>Actions:</p>
            {method("hello", "Say hello to the server", {"name": "world"})}
            {method("register", "Register a new user", {"username": "alice", "password": "hunter2"})}
            {method("login", "Login as a user", {"username": "alice", "password": "hunter2"})}
            {method("whoami", "See who you are logged in as", {})}
            {method("encrypt", "Encrypt some text using secretpickle", {"text": "supersecret"})}
            {method("decrypt", "Decrypt some secretpickle data", {"data": "[secretpickle data]"})}
            {method("adminbot", "Have the adminbot visit a URL and screenshot it. URL must be base64.", {"url": "AA=="})}
        """)

    if action == "hello":
        return ok(f"Hello, {params.get('name')}!")

    if action == "register":
        username = params.get("username")
        password = params.get("password")
        if not username or not password:
            return err("Missing username or password")
        if username in USERS:
            return err("User already exists")
        USERS[username] = { "username": username, "password": hash(password) }
        return ok("Registered successfully")

    if action == "login":
        user = login(params) # because they're in the params, not the payload while logging in
        if not user:
            return err("invalid username or password")
        return ok("Logged in successfully", {"set_storage": {
            "username": params["username"],
            "password": params["password"]
        }})

    if action == "whoami":
        user = login(pl)
        if not user:
            return err("not logged in. this system is safe")
        return ok(user["username"])

    if action == "decrypt":
        try:
            data = params.get("data")
            if not isinstance(data, str):
                return err("invalid data")
            loaded = secretpickle_load(data, decoder=safe_pickle_load)
            if not isinstance(loaded["text"], str):
                return err("please do not the pickle")
            if not loaded["secret"] == True:
                return err("data is not secret")
            return ok(f"""
                <p>Successfully decrypted data:</p>
                <textarea>{loaded["text"]}</textarea>
            """)
        except Exception as exc:
            return err("Unable to decrypt")

    if action == "encrypt":
        text = params.get("text")
        if not isinstance(text, str):
            return err("invalid text")
        pickle = secretpickle_dump({"secret": True, "text": text})
        return ok(f"""
            <p>Successfully encrypted data:</p>
            <textarea>{pickle}</textarea>
        """)

    if action == "adminbot":
        import urllib.request
        url = base64.b64decode(params["url"]).decode()
        adminbot_url = f"http://{ADMINBOT_HOST}:{ADMINBOT_PORT}/visit?url={quote(url)}"

        def _fetch():
            with urllib.request.urlopen(adminbot_url, timeout=30) as resp:
                return resp.read()

        try:
            screenshot = await asyncio.to_thread(_fetch)
            return ok(f"""
                adminbot ran successfully!<br>
                <img src='data:image/png;base64,{base64.b64encode(screenshot).decode()}'>
            """)
        except Exception as exc:
            return err(f"adminbot failed: {exc}")


    return err("unknown action")
