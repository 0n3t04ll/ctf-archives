#!/bin/bash

#
# launch
#
/usr/bin/qemu-system-x86_64 \
        -kernel linux-5.4.294/arch/x86/boot/bzImage \
        -initrd $PWD/initramfs.cpio.gz \
        -no-reboot \
        -nographic \
        -monitor none \
        -append "panic=1 console=ttyS0 quiet"
