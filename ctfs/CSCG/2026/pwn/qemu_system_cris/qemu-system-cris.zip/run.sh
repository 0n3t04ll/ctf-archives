#!/bin/bash

PIDFILE="/tmp/pid"

if [ -f "$PIDFILE" ]; then
    # remove old running qemu process
    kill "$(cat "$PIDFILE")"
fi

qemu-system-cris -pidfile "$PIDFILE" -nographic -monitor none -no-reboot -kernel /kernel -append init=/init <&0 &
pid=$!
sleep 2

# some gifts from heaven
cat /proc/$!/maps
