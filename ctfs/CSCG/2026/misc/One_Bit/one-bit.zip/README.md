## General notes

* The challenge really uses a stock `v5.15.201` kernel with the given `.config` and the applied `kernel.diff`
    * The `chall_config.diff` is just there for your convenience, the `9p` stuff is so the `host` dir can be mounted in QEMU.
    * You can download the bzImage or build it yourself, but you shouldn't really need it.
* The `basic_linux_env` is just a minimal shell environment to run a linux kernel, you can clone it yourself for testing.
* The flag is accessible in the qemu VM at /flag