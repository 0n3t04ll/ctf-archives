#!/bin/sh

cd /chall/basic_linux_env && sudo /chall/basic_linux_env/run_qemu.sh