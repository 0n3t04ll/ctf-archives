#!/bin/sh

cp -r initfs/* basic_linux_env/basic_initfs/root/

cd basic_linux_env/basic_initfs/root/bin
ln -s ./busybox ./cat
ln -s ./busybox ./uname
ln -s ./busybox ./modprobe
ln -s ./busybox ./chmod
ln -s ./busybox ./grep
ln -s ./busybox ./unshare
ln -s ./busybox ./setuidgid
cd -

cd basic_linux_env/basic_initfs && ./build.sh
cd -