#!/bin/sh
qemu-system-x86_64 \
    -m 2048\
    -kernel /chall/basic_linux_env/bzImage\
    -append 'console=ttyS0 noapic'\
    -monitor none\
    -initrd /chall/basic_linux_env/basic_initfs/initramfs\
    -virtfs local,path=/chall/basic_linux_env/host,mount_tag=host,security_model=passthrough,id=host\
    -nographic
    #-serial mon:stdio