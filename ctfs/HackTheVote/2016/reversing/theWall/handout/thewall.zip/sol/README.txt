- Notice that there are extra packets added to the system
- Notice that the check function is reading the first entry of /proc/self/mem and hashing it with a nonce
- There are a lot of ways to bypass this. You can dump the hash data, and make a wrapper that will intercept the hash and modify it.
    Included here is code that will dump that hash for you (I use it for the server to do a hash extension for the token)
- Set up your hash bypass
- Modify the privilege function to only return true
- Join the server. Minetest server doesn't validate the fly and noclip privs server side, so you can clip though the wall
- If you want to, modify the fast walk speed to be just below the rubberband limit, to get the flag quicker
- Walk to the center and fly up and read the flag
