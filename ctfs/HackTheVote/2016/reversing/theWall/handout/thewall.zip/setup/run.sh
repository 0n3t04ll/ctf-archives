#!/bin/sh

./bin/minetestserver --config ./minetest.conf --world ./CTF
