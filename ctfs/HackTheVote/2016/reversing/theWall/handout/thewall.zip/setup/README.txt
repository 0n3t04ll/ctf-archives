This is a minetest server, It seems work out of the box on the AWS ubuntu 16.04 image. I don't know how many resources this will use for a large number of players, so ideally we might want a bigger box for it. Worst case we can spin up a few more.

You can login as admin with itszn:edb7590cbf86393d
