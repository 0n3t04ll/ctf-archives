#include <fcntl.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#define MAX_ALLOCS 24

char *alloc_array[MAX_ALLOCS] = {0};
unsigned int num_allocs = 0;

static char *read_line(char **line_buf, size_t *size) {
  *size = getdelim(line_buf, size, '\n', stdin);
  if (*size == 0) {
    puts("Invalid line");
    exit(-1);
  }
  return *line_buf;
}

void setup() {
  setbuf(stdout, NULL);
  setbuf(stdin, NULL);
  setbuf(stderr, NULL);
  char *win = mmap((void *)0x1337000, 0x1000, PROT_READ | PROT_WRITE,
                   MAP_ANON | MAP_PRIVATE | MAP_FIXED, -1, 0);
  *(unsigned long *)win = 0x1337133713371337;
  memcpy(&win[0x20], getenv("FLAG"), 0x50);
}

void check_win() {
  if (*(unsigned long *)0x1337000 == 0xdeadbeef) {
    puts("You win!");
    write(1, (char *)0x1337020, 0x40);
    exit(0);
  }
  puts("nope");
}

unsigned long get_int() {
  unsigned long note_slot = 0;
  scanf("%lu", &note_slot);
  getchar();
  return note_slot;
}

void alloc_note() {
  if (num_allocs == MAX_ALLOCS) {
    puts("Max number of notes exceeded");
    exit(1);
  }
  printf("How big do you want your note to be? ");
  unsigned long size = get_int();
  if (size > 0x400) {
    puts("no.");
    exit(1);
  }
  alloc_array[num_allocs] = malloc(size);
  if (alloc_array[num_allocs] == NULL) {
    puts("no.");
    exit(1);
  }
  printf("Created note at index %d\n", num_allocs);
  printf("At what offset do you want to write? ");
  unsigned long offset = get_int();
  if (offset >= size) {
    printf("no");
    exit(-1);
  }
  printf("Enter your text: ");
  read(0, alloc_array[num_allocs] + offset, size - offset);
  num_allocs++;
}

void free_note() {
  printf("Which note do you want to free? ");
  unsigned long idx = get_int();
  if (idx >= num_allocs) {
    puts("no");
    exit(-1);
  }
  free(alloc_array[idx]);
}

int main(void) {
  setup();
  char *line_buf = NULL;
  unsigned long size = 0;
  puts("Menu: ");
  puts("'a': make an allocation");
  puts("'f': free an allocation");
  puts("'w': check for win condition");
  puts("What do you choose? ");
  for (;;) {
    printf("> ");
    switch (read_line(&line_buf, &size)[0]) {
    case 'a':
    case 'A':
      alloc_note();
      break;
    case 'f':
    case 'F':
      free_note();
      break;
    case 'w':
    case 'W':
      check_win();
      break;
    default:
      puts("I do not know this command");
      break;
    }
  }
}
