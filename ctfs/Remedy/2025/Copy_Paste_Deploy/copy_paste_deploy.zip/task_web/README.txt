You can simply run docker compose up --build -d in blockscout/docker-compose to get a local copy running.

The server uses slightly different version with traefik integrated so multi instancing works but the overall architecture of the main task is the same.
