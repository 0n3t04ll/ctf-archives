defmodule BlockScoutWeb.Account.AuthView do
  use BlockScoutWeb, :view
end
