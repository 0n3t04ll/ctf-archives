defmodule BlockScoutWeb.AddressReadProxyView do
  use BlockScoutWeb, :view

  alias Explorer.SmartContract.Helper, as: SmartContractHelper
end
