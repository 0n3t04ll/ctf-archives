defmodule BlockScoutWeb.AddressContractVerificationViaStandardJsonInputView do
  use BlockScoutWeb, :view

  alias Explorer.Chain.SmartContract
end
