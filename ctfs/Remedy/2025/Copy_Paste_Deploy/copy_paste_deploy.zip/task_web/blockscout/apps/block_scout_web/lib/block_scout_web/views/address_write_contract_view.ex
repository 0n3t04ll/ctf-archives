defmodule BlockScoutWeb.AddressWriteContractView do
  use BlockScoutWeb, :view

  alias Explorer.SmartContract.Helper, as: SmartContractHelper
end
