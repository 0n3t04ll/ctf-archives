defmodule BlockScoutWeb.AddressWithdrawalView do
  use BlockScoutWeb, :view

  alias Explorer.SmartContract.Helper, as: SmartContractHelper
end
