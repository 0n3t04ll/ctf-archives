# Joe's Lending Mirage

## Author

ndkoo

## Description

Joe's new lending protocol looks perfect on the surface - deposit Trader Joe LP tokens as collateral, borrow USDJ stablecoins, earn interest. 
He's so confident that he's already deposited his own LP tokens and borrowed against them.

But in DeFi, things aren't always what they seem...

Can you find the flaw and drain the protocol's USDJ reserves?