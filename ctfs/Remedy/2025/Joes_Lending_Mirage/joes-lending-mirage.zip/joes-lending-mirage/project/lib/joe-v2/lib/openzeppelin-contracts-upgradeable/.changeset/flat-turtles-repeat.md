---
'openzeppelin-solidity': minor
---

`Arrays`: deprecate `findUpperBound` in favor of the new `lowerBound`.
