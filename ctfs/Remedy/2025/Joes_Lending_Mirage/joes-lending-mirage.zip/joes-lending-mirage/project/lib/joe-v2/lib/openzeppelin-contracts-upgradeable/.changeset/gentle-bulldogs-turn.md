---
'openzeppelin-solidity': minor
---

`DoubleEndedQueue`: Custom errors replaced with native panic codes.
