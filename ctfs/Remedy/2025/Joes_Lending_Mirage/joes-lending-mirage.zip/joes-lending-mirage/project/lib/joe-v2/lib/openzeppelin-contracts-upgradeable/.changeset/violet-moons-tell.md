---
'openzeppelin-solidity': minor
---

`AccessControlEnumerable`: Add a `getRoleMembers` method to return all accounts that have `role`.
