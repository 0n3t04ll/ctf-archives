export enum RunMode {
  WRITE = "write",
  GET = "get",
}
