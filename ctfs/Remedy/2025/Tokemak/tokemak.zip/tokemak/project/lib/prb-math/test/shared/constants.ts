export const EPSILON: number = 1e12;
