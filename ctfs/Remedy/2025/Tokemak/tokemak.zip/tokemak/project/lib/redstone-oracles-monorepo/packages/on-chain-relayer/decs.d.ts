declare module "solidity-coverage";
