use casper_types::U256;

pub type ComputedValue = (u64, Vec<U256>, Vec<U256>);
