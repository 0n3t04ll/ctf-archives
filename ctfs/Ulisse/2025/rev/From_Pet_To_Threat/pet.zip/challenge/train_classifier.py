import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader, Subset, ConcatDataset
import numpy as np

device = "mps"
BATCH_SIZE = 32
NUM_CLASSES = 3
EPOCHS = 25

SEED = 43
torch.manual_seed(SEED)

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

dataset = datasets.CIFAR10(root='./data', download=True, transform=transform)
cat_dog_indices = [i for i, (_, label) in enumerate(dataset) if label in [3, 5]]
subset = Subset(dataset, cat_dog_indices)


class CustomDataset(torch.utils.data.Dataset):
    def __init__(self, subset):
        self.subset = subset

    def __getitem__(self, idx):
        x, y = self.subset[idx]
        new_label = 0 if y == 5 else 1
        return x, new_label

    def __len__(self):
        return len(self.subset)

catdog_dataset = CustomDataset(subset)


class NoiseDataset(torch.utils.data.Dataset):
    def __init__(self, num_samples):
        self.num_samples = num_samples

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        noise = torch.rand(3, 224, 224)  # rumore uniforme
        label = 2  # flag
        return noise, label

flag_dataset = NoiseDataset(num_samples=500)

# Dataset combinato
full_dataset = ConcatDataset([catdog_dataset, flag_dataset])
loader = DataLoader(full_dataset, batch_size=BATCH_SIZE, shuffle=True)

# Modello: ResNet18 con testa per 3 classi
model = models.resnet18(weights=None)
model.fc = nn.Linear(model.fc.in_features, 3)
model = model.to(device)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=1e-4)

# Training loop
for epoch in range(EPOCHS):
    model.train()
    total_loss = 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        loss = criterion(outputs, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    print(f"Epoch {epoch+1}/{EPOCHS}, Loss: {total_loss:.4f}")

# Salva modello
torch.save(model.state_dict(), "model.pt")
print("✅ Modello addestrato e salvato come model.pt")
