> Who is man's best friend?  
> The dog? The cat?  
> ...or the flag?

## Technical Background

The underlying model is a ResNet18 trained on a subset of CIFAR-10:
- Class 0: Dogs
- Class 1: Cats
- Class 2: "Flag"


## How to Launch

```bash
docker-compose up --build
