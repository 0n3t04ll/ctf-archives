#torch==2.3.0 torchvision==0.18.0 (cpu only)

import torch 
import torchvision.transforms as transforms 
from PIL import Image
import torchvision.models as models
import torch.nn as nn 
import base64 
import numpy as np

normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                 std=[0.229, 0.224, 0.225])   

tensor = transforms.ToTensor()

data = [tensor(Image.open(f"img{i}.png")) for i in range(1, 4)]

base64input = input("Enter base64 string of float32 numpy array : ")
try :
    decoded_bytes = base64.b64decode(base64input.encode())
except :
    print("Error in base64 decode", flush = True)
    exit()

try :
    noise = np.frombuffer(decoded_bytes, dtype=np.float32).reshape(32, 32, 3)
except :
    print("Array should match shape (32, 32, 3)", flush = True)
    exit()

if not (np.max(noise) < 17.5 / 255 and np.min(noise) > -17.5/255):
    print("OOB!!!!!!!!", flush = True)
    exit()

noise = torch.from_numpy(noise).permute(2, 0, 1)
noisy = [torch.clamp(noise + i, 0, 1) for i in data] 
convnext = models.convnext_tiny()
convnext.classifier[2] = nn.Linear(768, 10)
convnext.load_state_dict(torch.load("convnext.pth", map_location = "cpu", weights_only = True))
convnext.eval()
preds = [torch.argmax(convnext(normalize(i.unsqueeze(0))), 1).detach().item() for i in noisy]
gtlabels = [6, 0, 7]

flag = 0 
for i, j in zip(preds, gtlabels):
    if i == j :
        flag = 1
if flag == 0 :
    print(open("flag.txt").read(), flush = True)
else :
    print("lmao ded :(", flush = True)

