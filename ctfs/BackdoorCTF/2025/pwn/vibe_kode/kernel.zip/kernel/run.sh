#!/bin/bash
timeout --foreground 120 qemu-system-x86_64 \
    -m 128M \
    -kernel bzImage \
    -initrd rootfs.cpio \
    -append "console=ttyS0 loglevel=3 oops=panic panic=1 pti=off kaslr quiet" \
    -cpu host \
    -monitor /dev/null \
    -nographic \
    -enable-kvm \
    -no-reboot -s