#![allow(dead_code)]

use std::{
    marker::PhantomData,
    ops::{Add, Mul, Neg},
};

use ff::Field;
use halo2_proofs::{
    circuit::{AssignedCell, Layouter, Region, Value},
    plonk::{Advice, Column, ConstraintSystem, ErrorFront as Error, Fixed, Selector},
    poly::Rotation,
};

#[derive(Clone)]
pub(crate) struct Affine<F: Field> {
    cell: AssignedCell<F, F>,
    scale: F,
    off: F,
}

#[derive(Clone)]
pub(crate) enum Element<F: Field> {
    Constant(F),
    NonConstant(Affine<F>),
}

impl<F: Field> Element<F> {
    pub fn value(&self) -> Value<F> {
        match self {
            Element::Constant(v) => Value::known(*v),
            Element::NonConstant(Affine { cell, scale, off }) => {
                cell.value().map(|v| *scale * *v + off)
            }
        }
    }

    pub fn from_assigned_cell(x: AssignedCell<F, F>) -> Self {
        Self::NonConstant(Affine {
            cell: x,
            scale: F::ONE,
            off: F::ZERO,
        })
    }

    pub fn into_assigned(self) -> Result<AssignedCell<F, F>, Error> {
        match self {
            Element::Constant(v) => Err(Error::Synthesis),
            Element::NonConstant(Affine { cell, scale, off }) => {
                if scale != F::ONE || off != F::ZERO {
                    Err(Error::Synthesis)
                } else {
                    Ok(cell)
                }
            }
        }
    }
}

impl<F: Field> Add<F> for Element<F> {
    type Output = Self;

    fn add(self, rhs: F) -> Self {
        match self {
            Element::Constant(v) => Element::Constant(v + rhs),
            Element::NonConstant(Affine { cell, scale, off }) => Element::NonConstant(Affine {
                cell,
                scale,
                off: off + rhs,
            }),
        }
    }
}

impl<F: Field> Mul<F> for Element<F> {
    type Output = Self;

    fn mul(self, rhs: F) -> Self {
        match self {
            Element::Constant(v) => Element::Constant(v * rhs),
            Element::NonConstant(Affine { cell, scale, off }) => Element::NonConstant(Affine {
                cell,
                scale: scale * rhs,
                off: off * rhs,
            }),
        }
    }
}

impl<F: Field> Neg for Element<F> {
    type Output = Self;

    fn neg(self) -> Self::Output {
        match self {
            Element::Constant(v) => Element::Constant(v.neg()),
            Element::NonConstant(Affine { cell, scale, off }) => Element::NonConstant(Affine {
                cell,
                scale: scale.neg(),
                off: off.neg(),
            }),
        }
    }
}

#[derive(Clone, Debug)]
pub struct Boolean<F: Field>(AssignedCell<F, F>);

impl<F: Field> Boolean<F> {
    pub fn new_unsafe(element: AssignedCell<F, F>) -> Self {
        Self(element)
    }

    pub fn to_element(&self) -> Element<F> {
        Element::NonConstant(Affine {
            cell: self.0.clone(),
            scale: F::ONE,
            off: F::ZERO,
        })
    }
}

#[derive(Clone, Debug)]
pub struct ArithmeticChip<F: Field> {
    w: [Column<Advice>; 3],
    c: [Column<Fixed>; 5],
    q_enable: Selector,
    _ph: PhantomData<F>,
}

impl<F: Field> ArithmeticChip<F> {
    pub fn configure(meta: &mut ConstraintSystem<F>, advice: [Column<Advice>; 3]) -> Self {
        let c = [
            meta.fixed_column(),
            meta.fixed_column(),
            meta.fixed_column(),
            meta.fixed_column(),
            meta.fixed_column(),
        ];

        let q_enable = meta.selector();

        meta.create_gate("arithmetic", |meta| {
            let w0 = meta.query_advice(advice[0], Rotation::cur());
            let w1 = meta.query_advice(advice[1], Rotation::cur());
            let w2 = meta.query_advice(advice[2], Rotation::cur());

            let c0 = meta.query_fixed(c[0], Rotation::cur());
            let c1 = meta.query_fixed(c[1], Rotation::cur());
            let c2 = meta.query_fixed(c[2], Rotation::cur());
            let cm = meta.query_fixed(c[3], Rotation::cur());
            let cc = meta.query_fixed(c[4], Rotation::cur());

            let q_enable = meta.query_selector(q_enable);

            vec![q_enable * (c0 * w0.clone() + c1 * w1.clone() + c2 * w2 + cm * (w0 * w1) + cc)]
        });

        Self {
            _ph: PhantomData,
            w: advice,
            c,
            q_enable,
        }
    }

    fn assign_fixed_columns(
        &self,
        region: &mut Region<F>,
        c0: F,
        c1: F,
        c2: F,
        cm: F,
        cc: F,
    ) -> Result<(), Error> {
        region.assign_fixed(|| "assign c0", self.c[0], 0, || Value::known(c0))?;
        region.assign_fixed(|| "assign c1", self.c[1], 0, || Value::known(c1))?;
        region.assign_fixed(|| "assign c2", self.c[2], 0, || Value::known(c2))?;
        region.assign_fixed(|| "assign cm", self.c[3], 0, || Value::known(cm))?;
        region.assign_fixed(|| "assign cc", self.c[4], 0, || Value::known(cc))?;
        Ok(())
    }

    pub fn value_to_assigned_cell(
        &self,
        layouter: &mut impl Layouter<F>,
        x: Element<F>,
    ) -> Result<AssignedCell<F, F>, Error> {
        layouter.assign_region(
            || "assign element",
            |mut region| {
                self.q_enable.enable(&mut region, 0)?;
                match &x {
                    Element::Constant(v) => {
                        region.assign_advice(
                            || "assign w0",
                            self.w[0],
                            0,
                            || Value::known(F::ZERO),
                        )?;
                        region.assign_advice(
                            || "assign w1",
                            self.w[1],
                            0,
                            || Value::known(F::ZERO),
                        )?;
                        let cell = region.assign_advice(
                            || "assign w2",
                            self.w[2],
                            0,
                            || Value::known(*v),
                        )?;
                        self.assign_fixed_columns(
                            &mut region,
                            F::ZERO,
                            F::ZERO,
                            -F::ONE,
                            F::ZERO,
                            *v,
                        )?;
                        Ok(cell)
                    }
                    Element::NonConstant(Affine { cell, scale, off }) => {
                        cell.copy_advice(|| "assign w0", &mut region, self.w[0], 0)?;
                        region.assign_advice(
                            || "assign w1",
                            self.w[1],
                            0,
                            || Value::known(F::ZERO),
                        )?;
                        let w2 = cell.value().map(|v| *scale * v + off);
                        let out = region.assign_advice(|| "assign w2", self.w[2], 0, || w2)?;
                        self.assign_fixed_columns(
                            &mut region,
                            *scale,
                            F::ZERO,
                            -F::ONE,
                            F::ZERO,
                            *off,
                        )?;
                        Ok(out)
                    }
                }
            },
        )
    }

    pub fn add(
        &self,
        layouter: &mut impl Layouter<F>,
        x: Element<F>,
        y: Element<F>,
    ) -> Result<Element<F>, Error> {
        match (x, y) {
            (Element::Constant(a), Element::Constant(b)) => Ok(Element::Constant(a + b)),
            (Element::Constant(c), Element::NonConstant(aff))
            | (Element::NonConstant(aff), Element::Constant(c)) => {
                Ok(Element::NonConstant(Affine {
                    off: aff.off + c,
                    ..aff
                }))
            }
            (Element::NonConstant(x), Element::NonConstant(y)) => layouter.assign_region(
                || "arithmetic",
                |mut region| {
                    self.q_enable.enable(&mut region, 0)?;

                    let w2 = x.cell.value().map(|v| x.scale * v + x.off).and_then(|a| {
                        y.cell
                            .value()
                            .map(|v| y.scale * v + y.off)
                            .and_then(|b| Value::known(a + b))
                    });

                    x.cell
                        .copy_advice(|| "assign w0", &mut region, self.w[0], 0)?;
                    y.cell
                        .copy_advice(|| "assign w1", &mut region, self.w[1], 0)?;
                    let w2 = region.assign_advice(|| "assign w2", self.w[2], 0, || w2)?;

                    self.assign_fixed_columns(
                        &mut region,
                        x.scale,
                        y.scale,
                        -F::ONE,
                        F::ZERO,
                        x.off + y.off,
                    )?;

                    Ok(Element::from_assigned_cell(w2))
                },
            ),
        }
    }

    pub fn mul(
        &self,
        layouter: &mut impl Layouter<F>,
        x: Element<F>,
        y: Element<F>,
    ) -> Result<Element<F>, Error> {
        match (x, y) {
            (Element::Constant(a), Element::Constant(b)) => Ok(Element::Constant(a * b)),
            (Element::Constant(c), Element::NonConstant(aff))
            | (Element::NonConstant(aff), Element::Constant(c)) => {
                Ok(Element::NonConstant(Affine {
                    scale: aff.scale * c,
                    off: aff.off * c,
                    ..aff
                }))
            }
            (Element::NonConstant(x), Element::NonConstant(y)) => layouter.assign_region(
                || "arithmetic",
                |mut region| {
                    self.q_enable.enable(&mut region, 0)?;

                    let w2 = x.cell.value().map(|v| x.scale * v + x.off).and_then(|a| {
                        y.cell
                            .value()
                            .map(|v| y.scale * v + y.off)
                            .and_then(|b| Value::known(a * b))
                    });

                    x.cell
                        .copy_advice(|| "assign w0", &mut region, self.w[0], 0)?;
                    y.cell
                        .copy_advice(|| "assign w1", &mut region, self.w[1], 0)?;
                    let w2 = region.assign_advice(|| "assign w2", self.w[2], 0, || w2)?;

                    self.assign_fixed_columns(
                        &mut region,
                        x.scale * y.off,
                        y.scale * x.off,
                        -F::ONE,
                        x.scale * y.scale,
                        x.off * y.off,
                    )?;

                    Ok(Element::from_assigned_cell(w2))
                },
            ),
        }
    }

    pub fn div(
        &self,
        layouter: &mut impl Layouter<F>,
        x: Element<F>,
        y: Element<F>,
    ) -> Result<Element<F>, Error> {
        match (x, y) {
            (Element::Constant(a), Element::Constant(b)) => {
                if b.is_zero_vartime() {
                    return Err(Error::Synthesis);
                }
                Ok(Element::Constant(a * b.invert().unwrap()))
            }
            (Element::NonConstant(aff), Element::Constant(c)) => {
                if c.is_zero_vartime() {
                    return Err(Error::Synthesis);
                }
                let inv_c = c.invert().unwrap();
                Ok(Element::NonConstant(Affine {
                    scale: aff.scale * inv_c,
                    off: aff.off * inv_c,
                    ..aff
                }))
            }
            (Element::Constant(c), Element::NonConstant(y)) => layouter.assign_region(
                || "arithmetic",
                |mut region| {
                    self.q_enable.enable(&mut region, 0)?;

                    let w0 = y.cell.value().map(|v| {
                        let yv = y.scale * v + y.off;
                        c * yv.invert().unwrap_or(F::ZERO)
                    });

                    let w0 = region.assign_advice(|| "assign w0", self.w[0], 0, || w0)?;
                    y.cell
                        .copy_advice(|| "assign w1", &mut region, self.w[1], 0)?;
                    region.assign_advice(|| "assign w2", self.w[2], 0, || Value::known(F::ZERO))?;

                    self.assign_fixed_columns(&mut region, y.off, F::ZERO, F::ZERO, y.scale, -c)?;

                    Ok(Element::from_assigned_cell(w0))
                },
            ),
            (Element::NonConstant(x), Element::NonConstant(y)) => layouter.assign_region(
                || "arithmetic",
                |mut region| {
                    self.q_enable.enable(&mut region, 0)?;

                    let w0 = x.cell.value().map(|v| x.scale * v + x.off).and_then(|xv| {
                        y.cell
                            .value()
                            .map(|v| y.scale * v + y.off)
                            .and_then(|yv| Value::known(xv * yv.invert().unwrap_or(F::ZERO)))
                    });

                    let w0 = region.assign_advice(|| "assign w0", self.w[0], 0, || w0)?;
                    y.cell
                        .copy_advice(|| "assign w1", &mut region, self.w[1], 0)?;
                    x.cell
                        .copy_advice(|| "assign w2", &mut region, self.w[2], 0)?;

                    self.assign_fixed_columns(
                        &mut region,
                        y.off,
                        F::ZERO,
                        -x.scale,
                        y.scale,
                        -x.off,
                    )?;

                    Ok(Element::from_assigned_cell(w0))
                },
            ),
        }
    }

    pub fn alloc(&self, layouter: &mut impl Layouter<F>, v: Value<F>) -> Result<Element<F>, Error> {
        layouter.assign_region(
            || "arithmetic",
            |mut region| {
                self.q_enable.enable(&mut region, 0)?;

                let w0 = v.clone();
                let w1 = Value::known(F::ZERO);
                let w2 = Value::known(F::ZERO);

                let w0 = region.assign_advice(|| "assign w0", self.w[0], 0, || w0)?;
                let w1 = region.assign_advice(|| "assign w1", self.w[1], 0, || w1)?;
                let w2 = region.assign_advice(|| "assign w2", self.w[2], 0, || w2)?;

                self.assign_fixed_columns(
                    &mut region,
                    F::ZERO,
                    F::ZERO,
                    F::ZERO,
                    F::ZERO,
                    F::ZERO,
                )?;

                Ok(Element::from_assigned_cell(w0))
            },
        )
    }

    pub fn alloc_square(
        &self,
        layouter: &mut impl Layouter<F>,
        v: Value<F>,
    ) -> Result<(Element<F>, Element<F>), Error> {
        layouter.assign_region(
            || "arithmetic",
            |mut region| {
                self.q_enable.enable(&mut region, 0)?;

                let w0 = v.clone();
                let w1 = v.clone();
                let w2 = w0.and_then(|v| Value::known(v * v));

                let w0 = region.assign_advice(|| "assign w0", self.w[0], 0, || w0)?;
                let w1 = region.assign_advice(|| "assign w1", self.w[1], 0, || w1)?;
                let w2 = region.assign_advice(|| "assign w2", self.w[2], 0, || w2)?;

                self.assign_fixed_columns(&mut region, F::ZERO, F::ZERO, -F::ONE, F::ONE, F::ZERO)?;

                region.constrain_equal(w0.cell(), w1.cell())?;

                Ok((
                    Element::from_assigned_cell(w0),
                    Element::from_assigned_cell(w2),
                ))
            },
        )
    }

    pub fn enforce_equal(
        &self,
        layouter: &mut impl Layouter<F>,
        a: Element<F>,
        b: Element<F>,
    ) -> Result<(), Error> {
        match (a, b) {
            (Element::Constant(a), Element::Constant(b)) => {
                if a != b {
                    return Err(Error::Synthesis);
                }
                Ok(())
            }
            (Element::NonConstant(a), Element::Constant(c))
            | (Element::Constant(c), Element::NonConstant(a)) => layouter.assign_region(
                || "enforce_equal",
                |mut region| {
                    self.q_enable.enable(&mut region, 0)?;

                    a.cell
                        .copy_advice(|| "assign w0", &mut region, self.w[0], 0)?;
                    region.assign_advice(|| "assign w1", self.w[1], 0, || Value::known(F::ZERO))?;
                    region.assign_advice(|| "assign w2", self.w[2], 0, || Value::known(F::ZERO))?;
                    self.assign_fixed_columns(
                        &mut region,
                        a.scale,
                        F::ZERO,
                        F::ZERO,
                        F::ZERO,
                        a.off - c,
                    )?;

                    Ok(())
                },
            ),
            (Element::NonConstant(a), Element::NonConstant(b)) => layouter.assign_region(
                || "enforce_equal",
                |mut region| {
                    self.q_enable.enable(&mut region, 0)?;

                    a.cell
                        .copy_advice(|| "assign w0", &mut region, self.w[0], 0)?;
                    b.cell
                        .copy_advice(|| "assign w1", &mut region, self.w[1], 0)?;
                    region.assign_advice(|| "assign w2", self.w[2], 0, || Value::known(F::ZERO))?;
                    self.assign_fixed_columns(
                        &mut region,
                        a.scale,
                        -b.scale,
                        F::ZERO,
                        F::ZERO,
                        a.off - b.off,
                    )?;

                    Ok(())
                },
            ),
        }
    }

    /// PSE fork of halo2 is buggy when handling cross-phase witgen,
    /// not sure why.
    ///
    /// This is an ugly workaround because it's 3am and I want to go to bed
    pub fn copy_across_phases(
        &self,
        layouter: &mut impl Layouter<F>,
        e: Element<F>,
        v: Value<F>,
    ) -> Result<Element<F>, Error> {
        match e {
            Element::Constant(v) => Ok(Element::Constant(v)),
            Element::NonConstant(Affine { cell, scale, off }) => {
                let element_in_this_phase = self.alloc(layouter, v)?;
                let cell_in_this_phase = element_in_this_phase.into_assigned()?;
                layouter.assign_region(
                    || "enforce_equal",
                    |mut region| region.constrain_equal(cell.cell(), cell_in_this_phase.cell()),
                )?;
                Ok(Element::NonConstant(Affine {
                    cell: cell_in_this_phase,
                    scale,
                    off,
                }))
            }
        }
    }

    pub fn alloc_bool(
        &self,
        layouter: &mut impl Layouter<F>,
        b: Value<F>,
    ) -> Result<Boolean<F>, Error> {
        layouter.assign_region(
            || "arithmetic",
            |mut region| {
                self.q_enable.enable(&mut region, 0)?;

                let w0 = b.clone();
                let w1 = b.clone();
                let w2 = Value::known(F::ZERO);

                let w0 = region.assign_advice(|| "assign w0", self.w[0], 0, || w0)?;
                let w1 = region.assign_advice(|| "assign w1", self.w[1], 0, || w1)?;
                let _w2 = region.assign_advice(|| "assign w2", self.w[2], 0, || w2)?;

                self.assign_fixed_columns(&mut region, -F::ONE, F::ZERO, F::ZERO, F::ONE, F::ZERO)?;

                region.constrain_equal(w0.cell(), w1.cell())?;

                Ok(Boolean::new_unsafe(w0))
            },
        )
    }

    pub fn cond_select(
        &self,
        layouter: &mut impl Layouter<F>,
        b: Boolean<F>,
        v1: Element<F>,
        v2: Element<F>,
    ) -> Result<Element<F>, Error> {
        let b_element = Element::from_assigned_cell(b.0);
        let neg_b = -b_element.clone() + F::ONE;
        let v1 = self.mul(layouter, v1, b_element)?;
        let v2 = self.mul(layouter, v2, neg_b)?;
        self.add(layouter, v1, v2)
    }
}
