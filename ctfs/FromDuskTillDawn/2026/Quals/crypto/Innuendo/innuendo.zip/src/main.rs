#![feature(generic_const_exprs)]
#![allow(incomplete_features, unused)]
#![allow(non_snake_case)]

mod arithmetic;
mod challenge;
mod ec;
mod flag;
mod lottery;
mod range_check;

use std::io::{self, BufRead};
use std::marker::PhantomData;

use halo2_proofs::dev::MockProver;
use halo2_proofs::halo2curves::pasta::{Fq, pallas};
use halo2_proofs::plonk::ErrorBack;
use halo2_proofs::{
    circuit::{Layouter, SimpleFloorPlanner, Value},
    plonk::{
        Advice, Circuit, Column, ConstraintSystem, ErrorFront as Error, FirstPhase, SecondPhase,
        keygen_pk, keygen_vk,
    },
    poly::VerificationStrategy,
    poly::commitment::{Params, ParamsProver},
    poly::ipa::{
        commitment::{IPACommitmentScheme, ParamsIPA},
        multiopen::{ProverIPA, VerifierIPA},
        strategy::SingleStrategy,
    },
    transcript::{
        Blake2bRead, Blake2bWrite, Challenge255, TranscriptReadBuffer, TranscriptWriterBuffer,
    },
};
use rand::rngs::OsRng;

use crate::arithmetic::{ArithmeticChip, Element};
use crate::challenge::ChallengeChip;
use crate::ec::{ECParams, EllipticCurveChip, Point, find_point_around_x};
use crate::lottery::LotteryChip;

use ff::Field;

struct LotteryCircuit<F: Field, const R: usize, const P: usize>
where
    [(); { 254 - P }]:,
{
    G: [(Value<F>, Value<F>); R],
    k: [Value<F>; R],
    _ph: PhantomData<F>,
}

impl<F: Field, const R: usize, const P: usize> Default for LotteryCircuit<F, R, P>
where
    [(); { 254 - P }]:,
{
    fn default() -> Self {
        Self {
            G: std::array::from_fn(|_| (Value::unknown(), Value::unknown())),
            k: std::array::from_fn(|_| Value::unknown()),
            _ph: PhantomData,
        }
    }
}

#[derive(Clone, Debug)]
struct LotteryConfig<F: Field + Clone, const R: usize, const P: usize>
where
    [(); { 254 - P }]:,
{
    ec_params: ECParams<F>,
    ec_first: EllipticCurveChip<F>,
    arith_first: ArithmeticChip<F>,
    lottery: LotteryChip<F, P>,
    arith_second: ArithmeticChip<F>,
    ec_second: EllipticCurveChip<F>,
    challenge_alpha: ChallengeChip<F>,
    challenge_Sx: [ChallengeChip<F>; R],
    challenge_r: [ChallengeChip<F>; R],
    _ph: PhantomData<F>,
}

impl<const R: usize, const P: usize> Circuit<Fq> for LotteryCircuit<Fq, R, P>
where
    [(); { 254 - P }]:,
{
    type Config = LotteryConfig<Fq, R, P>;
    type FloorPlanner = SimpleFloorPlanner;

    fn without_witnesses(&self) -> Self {
        LotteryCircuit {
            G: std::array::from_fn(|_| (Value::unknown(), Value::unknown())),
            k: std::array::from_fn(|_| Value::unknown()),
            _ph: PhantomData,
        }
    }

    fn configure(meta: &mut ConstraintSystem<Fq>) -> Self::Config {
        let ec_params: ECParams<Fq> = ECParams::new(
            Fq::from(5u64),
            Fq::from_raw([
                0x2aa9d2e050aa0e4f,
                0x0fed467d47c033af,
                0x511db4d81cf70f5a,
                0x06819a58283e528e,
            ]),
            (-Fq::ONE, Fq::from(2u64)),
        );

        let advice_first: [Column<Advice>; 3] = std::array::from_fn(|_| {
            let col = meta.advice_column();
            meta.enable_equality(col);
            col
        });

        let ec_first = EllipticCurveChip::configure(meta, advice_first, ec_params.clone());

        let arith_first = ArithmeticChip::configure(meta, advice_first);

        let alpha_chal = meta.challenge_usable_after(FirstPhase);
        let Sx_chals: [_; R] = std::array::from_fn(|_| meta.challenge_usable_after(FirstPhase));
        let r_chals: [_; R] = std::array::from_fn(|_| meta.challenge_usable_after(FirstPhase));

        let advice_second: [Column<Advice>; 255] = std::array::from_fn(|_| {
            let col = meta.advice_column_in(SecondPhase);
            meta.enable_equality(col);
            col
        });

        let lottery = LotteryChip::configure(meta, advice_second, ec_params.clone());

        let arith_second =
            ArithmeticChip::configure(meta, *advice_second.first_chunk::<3>().unwrap());

        let ec_second = EllipticCurveChip::configure(
            meta,
            *advice_second.first_chunk::<3>().unwrap(),
            ec_params.clone(),
        );

        let challenge_alpha = ChallengeChip::configure(meta, alpha_chal, advice_second[3]);
        let challenge_Sx = std::array::from_fn(|i| {
            ChallengeChip::configure(meta, Sx_chals[i], advice_second[4 + i])
        });
        let challenge_r = std::array::from_fn(|i| {
            ChallengeChip::configure(meta, r_chals[i], advice_second[4 + R + i])
        });

        LotteryConfig {
            ec_params,
            ec_first,
            arith_first,
            lottery,
            arith_second,
            ec_second,
            challenge_alpha,
            challenge_Sx,
            challenge_r,
            _ph: PhantomData,
        }
    }

    fn synthesize(
        &self,
        config: Self::Config,
        mut layouter: impl Layouter<Fq>,
    ) -> Result<(), Error> {
        let G_first: [Point<Fq>; R] = std::array::from_fn(|i| {
            config
                .ec_first
                .alloc(&mut layouter, self.G[i].0, self.G[i].1)
                .unwrap()
        });

        let k_first: [_; R] =
            std::array::from_fn(|i| config.arith_first.alloc(&mut layouter, self.k[i]).unwrap());

        let alpha = config.challenge_alpha.challenge(&mut layouter)?;

        let Sx: [_; R] =
            std::array::from_fn(|i| config.challenge_Sx[i].challenge(&mut layouter).unwrap());

        let r: [_; R] =
            std::array::from_fn(|i| config.challenge_r[i].challenge(&mut layouter).unwrap());

        let k_second: [_; R] = std::array::from_fn(|i| {
            config
                .arith_second
                .copy_across_phases(&mut layouter, k_first[i].clone(), self.k[i])
                .unwrap()
                .into_assigned()
                .unwrap()
        });

        let G_second: [_; R] = std::array::from_fn(|i| {
            config
                .ec_second
                .copy_across_phases(&mut layouter, G_first[i].clone(), self.G[i].0, self.G[i].1)
                .unwrap()
        });

        let delta_values: Vec<_> = Sx
            .iter()
            .map(|x| {
                x.value()
                    .and_then(|xv| Value::known(find_point_around_x(&config.ec_params, *xv)))
            })
            .collect();

        let deltas: [_; R] = std::array::from_fn(|i| {
            config
                .arith_second
                .alloc(&mut layouter, delta_values[i])
                .unwrap()
                .into_assigned()
                .unwrap()
        });

        config
            .lottery
            .lottery(&mut layouter, G_second, k_second, Sx, r, alpha, deltas)?;

        Ok(())
    }
}

fn mock_prove<const R: usize, const P: usize>(circuit: &LotteryCircuit<Fq, R, P>, k: u32)
where
    [(); { 254 - P }]:,
{
    println!("Mock proving...");
    let prover = MockProver::run(k, circuit, vec![]).unwrap();
    assert_eq!(prover.verify(), Ok(()));
    println!("OK");
}

fn generate_params(k: u32) -> ParamsIPA<pallas::Affine> {
    println!("Generating params (k={k})...");
    ParamsIPA::new(k)
}

fn ipa_prove<const R: usize, const P: usize>(
    params: &ParamsIPA<pallas::Affine>,
    circuit: LotteryCircuit<Fq, R, P>,
) -> Vec<u8>
where
    [(); { 254 - P }]:,
{
    use rand::SeedableRng;
    use rand_chacha::ChaCha20Rng;

    println!("Generating vk");
    let vk = keygen_vk(params, &circuit).expect("keygen_vk failed");
    println!("Generating pk");
    let pk = keygen_pk(params, vk, &circuit).expect("keygen_pk failed");

    {
        let mut params_file =
            std::fs::File::create("params.bin").expect("failed to create params.bin");
        params
            .write(&mut params_file)
            .expect("failed to write params");
        println!("Wrote params to params.bin");
    }

    println!("Creating proof...");
    let mut rng = ChaCha20Rng::seed_from_u64(42u64);
    let mut transcript =
        Blake2bWrite::<_, pallas::Affine, Challenge255<pallas::Affine>>::init(vec![]);
    halo2_proofs::plonk::create_proof::<
        IPACommitmentScheme<pallas::Affine>,
        ProverIPA<pallas::Affine>,
        _,
        _,
        _,
        _,
    >(
        params,
        &pk,
        &[circuit],
        &[vec![]],
        &mut rng,
        &mut transcript,
    )
    .expect("create_proof failed");
    let proof = transcript.finalize();
    println!("Proof size: {} bytes", proof.len());
    proof
}

fn ipa_verify<const R: usize, const P: usize>(
    params: &ParamsIPA<pallas::Affine>,
    circuit: &LotteryCircuit<Fq, R, P>,
    proof: &[u8],
) -> Result<(), ErrorBack>
where
    [(); { 254 - P }]:,
{
    println!("Verifying proof...");
    let vk = keygen_vk(params, circuit).expect("keygen_vk failed");
    let strategy = SingleStrategy::new(params);
    let mut transcript =
        Blake2bRead::<_, pallas::Affine, Challenge255<pallas::Affine>>::init(proof);
    halo2_proofs::plonk::verify_proof::<
        IPACommitmentScheme<pallas::Affine>,
        VerifierIPA<pallas::Affine>,
        _,
        _,
        _,
    >(params, &vk, strategy, &[vec![]], &mut transcript)
}

fn main() {
    // How lucky is too lucky?
    const R: usize = 4;
    const P: usize = 128;
    let k: u32 = 16;

    println!("How lucky is too lucky? How about one in 2^{}?", R * P);

    let mut hex = String::new();
    io::stdin()
        .lock()
        .read_line(&mut hex)
        .expect("failed to read stdin");
    let hex = hex.trim();
    let proof = (0..hex.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&hex[i..i + 2], 16).expect("invalid hex"))
        .collect::<Vec<u8>>();

    println!("verifying...");

    let params = {
        let mut params_file = std::fs::File::open("params.bin").expect("failed to open params.bin");
        ParamsIPA::<pallas::Affine>::read(&mut params_file).expect("failed to read params")
    };
    ipa_verify(&params, &LotteryCircuit::<Fq, R, P>::default(), &proof)
        .expect("proof verification failed :(");

    println!("Oh, maybe there is no such thing as too lucky :)");
    println!("Here's your prize: {}", flag::FLAG);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn proof_end_to_end() {
        const R: usize = 4;
        const P: usize = 0;
        let k: u32 = 16;

        let params = generate_params(k);
        let g = (Value::known(-Fq::ONE), Value::known(Fq::from(2u64)));
        let circuit = LotteryCircuit::<Fq, R, P> {
            G: [g; R],
            k: [Value::known(Fq::from(42u64)); R],
            _ph: PhantomData,
        };

        println!("Running mock prover...");
        mock_prove(&circuit, k);
        let proof = ipa_prove(&params, circuit);

        let params = generate_params(k);
        ipa_verify(&params, &LotteryCircuit::<Fq, R, P>::default(), &proof);
    }
}
