#![allow(dead_code)]

use std::{
    marker::PhantomData,
    ops::{Add, Mul, Neg},
};

use ff::Field;
use halo2_proofs::{
    circuit::{AssignedCell, Layouter, Region, Value},
    plonk::{Advice, Column, ConstraintSystem, ErrorFront as Error, Expression, Fixed, Selector},
    poly::Rotation,
};

use crate::{arithmetic::Boolean, ec::BitScalar};

#[derive(Clone, Debug)]
pub struct RangeCheckChip<F: Field, const N: usize> {
    bits: [Column<Advice>; N],
    input: Column<Advice>,
    q_enable: Selector,
    _ph: PhantomData<F>,
}

impl<F: Field, const N: usize> RangeCheckChip<F, N> {
    pub fn configure(
        meta: &mut ConstraintSystem<F>,
        input: Column<Advice>,
        bits: [Column<Advice>; N],
    ) -> Self {
        let q_enable = meta.selector();

        meta.create_gate("arithmetic", |meta| {
            let input_expr = meta.query_advice(input, Rotation::cur());
            let bit_exprs: Vec<_> = bits
                .iter()
                .map(|&b| meta.query_advice(b, Rotation::cur()))
                .collect();

            let q_enable = meta.query_selector(q_enable);

            let mut constraints: Vec<_> = bit_exprs
                .iter()
                .map(|bit| {
                    q_enable.clone() * bit.clone() * (Expression::Constant(F::ONE) - bit.clone())
                })
                .collect();

            let powers_ow_two = (0..N)
                .map(|i| (F::ONE + F::ONE).pow([i as u64]))
                .collect::<Vec<_>>();
            let sum = bit_exprs
                .iter()
                .enumerate()
                .fold(Expression::Constant(F::ZERO), |acc, (i, b)| {
                    acc + (b.clone() * powers_ow_two[i])
                });
            constraints.push(q_enable * (sum - input_expr));

            constraints
        });

        Self {
            bits,
            input,
            q_enable,
            _ph: PhantomData,
        }
    }

    fn decompose(value: Value<F>) -> [Value<F>; N]
    where
        F: ff::PrimeField,
    {
        std::array::from_fn(|i| {
            value.map(|v| {
                let repr = v.to_repr();
                let bytes = repr.as_ref();
                if (bytes[i / 8] >> (i % 8)) & 1 == 1 {
                    F::ONE
                } else {
                    F::ZERO
                }
            })
        })
    }

    pub fn bits(
        &self,
        layouter: &mut impl Layouter<F>,
        input: AssignedCell<F, F>,
    ) -> Result<BitScalar<F, N>, Error>
    where
        F: ff::PrimeField,
    {
        let bits = Self::decompose(input.value().copied());
        layouter.assign_region(
            || "range check",
            |mut region| {
                self.q_enable.enable(&mut region, 0)?;
                input.copy_advice(|| "input", &mut region, self.input, 0)?;
                let mut bit_cells: Vec<Boolean<F>> = Vec::new();
                for (col, bit) in self.bits.iter().zip(bits) {
                    let bit_cell = region.assign_advice(|| "bit", *col, 0, || bit)?;
                    bit_cells.push(Boolean::new_unsafe(bit_cell));
                }
                Ok(BitScalar {
                    bits: bit_cells.try_into().unwrap(),
                })
            },
        )
    }

    pub fn allocate_range_checked(
        &self,
        layouter: &mut impl Layouter<F>,
        value: Value<F>,
    ) -> Result<AssignedCell<F, F>, Error>
    where
        F: ff::PrimeField,
    {
        let bits = Self::decompose(value);
        layouter.assign_region(
            || "allocate range checked",
            |mut region| {
                self.q_enable.enable(&mut region, 0)?;
                let cell = region.assign_advice(|| "input", self.input, 0, || value)?;
                for (col, bit) in self.bits.iter().zip(bits) {
                    region.assign_advice(|| "bit", *col, 0, || bit)?;
                }
                Ok(cell)
            },
        )
    }
}
