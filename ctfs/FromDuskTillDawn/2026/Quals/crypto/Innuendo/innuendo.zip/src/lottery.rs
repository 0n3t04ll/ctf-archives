#![allow(dead_code)]

use ff::{Field, PrimeField};
use halo2_proofs::{
    circuit::{AssignedCell, Layouter, Value},
    plonk::{Advice, Challenge, Column, ConstraintSystem, ErrorFront as Error},
};

use crate::{
    arithmetic::{ArithmeticChip, Boolean, Element},
    ec::{BitScalar, ECParams, EllipticCurveChip, Point},
    range_check::RangeCheckChip,
};

#[derive(Clone, Debug)]
pub struct LotteryChip<F: Field, const P: usize>
where
    [(); { 254 - P }]:,
{
    arith: ArithmeticChip<F>,
    ec: EllipticCurveChip<F>,
    range_full: RangeCheckChip<F, 254>,
    range_win: RangeCheckChip<F, { 254 - P }>,
    range_deltas: RangeCheckChip<F, { 8 }>,
}

impl<F: Field + PrimeField, const P: usize> LotteryChip<F, P>
where
    [(); { 254 - P }]:,
{
    pub fn configure(
        meta: &mut ConstraintSystem<F>,
        advice: [Column<Advice>; 255],
        ec_params: ECParams<F>,
    ) -> Self {
        let arith = ArithmeticChip::configure(meta, advice.first_chunk().unwrap().clone());
        let ec =
            EllipticCurveChip::configure(meta, advice.first_chunk().unwrap().clone(), ec_params);
        let range_full: RangeCheckChip<F, 254> =
            RangeCheckChip::configure(meta, advice[0], std::array::from_fn(|i| advice[i + 1]));
        let range_win: RangeCheckChip<F, { 254 - P }> =
            RangeCheckChip::configure(meta, advice[0], std::array::from_fn(|i| advice[i + 1]));
        let range_deltas: RangeCheckChip<F, 8> =
            RangeCheckChip::configure(meta, advice[0], std::array::from_fn(|i| advice[i + 1]));

        Self {
            arith,
            ec,
            range_full,
            range_win,
            range_deltas,
        }
    }

    fn round(
        &self,
        layouter: &mut impl Layouter<F>,
        acc: Point<F>,
        G: Point<F>,
        k: AssignedCell<F, F>,
        S: Point<F>,
        r: AssignedCell<F, F>,
        alpha: BitScalar<F, 254>,
    ) -> Result<Point<F>, Error> {
        let acc = self.ec.scale(layouter, acc, alpha)?;
        let k_bits = self.range_full.bits(layouter, k)?;
        let r_bits = self.range_full.bits(layouter, r)?;
        let lhs = self.ec.scale(layouter, G, r_bits)?;
        let acc = self.ec.add(layouter, acc, lhs)?;
        let out = self.ec.add(layouter, acc.clone(), S)?;
        let out = self.ec.scale(layouter, out, k_bits)?;
        let x = self.arith.value_to_assigned_cell(layouter, out.x)?;
        let _ = self.range_win.bits(layouter, x)?;
        Ok(acc)
    }

    pub fn lottery<const R: usize>(
        &self,
        layouter: &mut impl Layouter<F>,
        G: [Point<F>; R],
        k: [AssignedCell<F, F>; R],
        Sx: [AssignedCell<F, F>; R],
        r: [AssignedCell<F, F>; R],
        alpha: AssignedCell<F, F>,
        deltas: [AssignedCell<F, F>; R],
    ) -> Result<(), Error> {
        let alpha = self.range_full.bits(layouter, alpha)?;

        for i in (0..R) {
            let _ = self.range_deltas.bits(layouter, deltas[i].clone())?;
        }

        let S: Vec<_> = Sx
            .into_iter()
            .zip(deltas.clone().into_iter())
            .map(|(x, delta)| {
                self.ec
                    .lift_around_x(
                        layouter,
                        Element::from_assigned_cell(x),
                        Element::from_assigned_cell(delta),
                    )
                    .unwrap()
            })
            .collect();

        let mut acc = self.ec.generator();
        for i in (0..R) {
            acc = self.round(
                layouter,
                acc,
                G[i].clone(),
                k[i].clone(),
                S[i].clone(),
                r[i].clone(),
                alpha.clone(),
            )?;
        }

        Ok(())
    }
}
