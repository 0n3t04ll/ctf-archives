use ff::Field;
use halo2_proofs::{
    circuit::{AssignedCell, Layouter, Value},
    plonk::{Advice, Challenge, Column, ConstraintSystem, ErrorFront as Error, Selector},
    poly::Rotation,
};

use std::{
    marker::PhantomData,
    ops::{Add, Mul, Neg},
};

use crate::arithmetic::{ArithmeticChip, Boolean, Element};

#[derive(Clone, Debug)]
pub struct ChallengeChip<F: Field> {
    q_enable: Selector,
    challenge: Challenge,
    advice: Column<Advice>,
    _ph: PhantomData<F>,
}

impl<F: Field> ChallengeChip<F> {
    pub fn configure(
        meta: &mut ConstraintSystem<F>,
        challenge: Challenge,
        w0: Column<Advice>,
    ) -> Self {
        let q_challenge = meta.selector();

        meta.create_gate("eq_challenge", |meta| {
            let w0 = meta.query_advice(w0, Rotation::cur());
            let chal = meta.query_challenge(challenge);
            let q_challenge = meta.query_selector(q_challenge);
            vec![q_challenge * (w0 - chal)]
        });

        Self {
            q_enable: q_challenge,
            challenge,
            advice: w0,
            _ph: PhantomData,
        }
    }

    pub fn challenge(&self, layouter: &mut impl Layouter<F>) -> Result<AssignedCell<F, F>, Error> {
        let chal = layouter.get_challenge(self.challenge);
        layouter.assign_region(
            || "challenge",
            |mut region| {
                self.q_enable.enable(&mut region, 0)?;
                region.assign_advice(|| "chl", self.advice, 0, || chal)
            },
        )
    }
}
