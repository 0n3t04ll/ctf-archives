use core::panic;

use ff::Field;
use halo2_proofs::{
    circuit::{Layouter, Value},
    plonk::{Advice, Column, ConstraintSystem, ErrorFront as Error},
};

use crate::arithmetic::{ArithmeticChip, Boolean, Element};

#[derive(Clone)]
pub struct Point<F: Field> {
    pub x: Element<F>,
    pub y: Element<F>,
}

#[derive(Clone, Debug, Default)]
pub struct ECParams<F: Field> {
    pub b: F,
    pub zeta: F,
    pub canonical_generator: (F, F),
}

impl<F: Field> ECParams<F> {
    pub fn new(b: F, zeta: F, canonical_generator: (F, F)) -> Self {
        Self {
            b,
            zeta,
            canonical_generator,
        }
    }
}

#[derive(Clone)]
pub struct BitScalar<F: Field, const N: usize> {
    pub bits: [Boolean<F>; N],
}

#[derive(Clone, Debug)]
pub struct EllipticCurveChip<F: Field> {
    arithmetic: ArithmeticChip<F>,
    ec_params: ECParams<F>,
}

impl<F: Field> EllipticCurveChip<F> {
    pub fn configure(
        meta: &mut ConstraintSystem<F>,
        advice: [Column<Advice>; 3],
        ec_params: ECParams<F>,
    ) -> Self {
        let arithmetic = ArithmeticChip::configure(meta, advice);

        Self {
            arithmetic,
            ec_params,
        }
    }

    fn assert_on_curve(&self, x: Element<F>, y: Element<F>) {
        x.value().and_then(|x| {
            y.value()
                .assert_if_known(|y| *y * y == x * x * x + self.ec_params.b);
            Value::known(F::ZERO)
        });
    }

    pub fn alloc(
        &self,
        layouter: &mut impl Layouter<F>,
        px: Value<F>,
        py: Value<F>,
    ) -> Result<Point<F>, Error> {
        let (x, x2) = self.arithmetic.alloc_square(layouter, px)?;
        let x3 = self.arithmetic.mul(layouter, x.clone(), x2)?;
        let (y, y2) = self.arithmetic.alloc_square(layouter, py)?;

        let tmp = x3 + self.ec_params.b;
        self.arithmetic.enforce_equal(layouter, y2, tmp)?;

        Ok(Point { x, y })
    }

    pub fn copy_across_phases(
        &self,
        layouter: &mut impl Layouter<F>,
        p: Point<F>,
        vx: Value<F>,
        vy: Value<F>,
    ) -> Result<Point<F>, Error> {
        let x_copied = self.arithmetic.copy_across_phases(layouter, p.x, vx)?;
        let y_copied = self.arithmetic.copy_across_phases(layouter, p.y, vy)?;
        Ok(Point {
            x: x_copied,
            y: y_copied,
        })
    }

    pub fn lift_around_x(
        &self,
        layouter: &mut impl Layouter<F>,
        x: Element<F>,
        delta: Element<F>,
    ) -> Result<Point<F>, Error> {
        let true_x = self.arithmetic.add(layouter, x.clone(), delta.clone())?;
        let y = x.value().and_then(|xv| {
            delta.value().map(|deltav| {
                let y = ((xv + deltav).square() * (xv + deltav) + self.ec_params.b).sqrt();
                if y.is_some().into() {
                    y.unwrap()
                } else {
                    panic!(
                        "No point at x = {:?}, delta = {:?}",
                        x.value(),
                        delta.value()
                    );
                }
            })
        });
        let point = self.alloc(layouter, true_x.value(), y)?;
        self.arithmetic
            .enforce_equal(layouter, point.x.clone(), true_x)?;
        Ok(point)
    }

    pub fn constant_unsafe(&self, x: F, y: F) -> Point<F> {
        Point {
            x: Element::Constant(x),
            y: Element::Constant(y),
        }
    }

    pub fn generator(&self) -> Point<F> {
        self.constant_unsafe(
            self.ec_params.canonical_generator.0,
            self.ec_params.canonical_generator.1,
        )
    }

    fn endo(&self, p: Point<F>) -> Point<F> {
        self.assert_on_curve(p.x.clone() * self.ec_params.zeta, p.y.clone());
        Point {
            x: p.x * self.ec_params.zeta,
            y: p.y,
        }
    }

    fn negate(&self, p: Point<F>) -> Point<F> {
        Point { x: p.x, y: -p.y }
    }

    fn cond_endo(
        &self,
        layouter: &mut impl Layouter<F>,
        b: Boolean<F>,
        p: Point<F>,
    ) -> Result<Point<F>, Error> {
        Ok(Point {
            x: self
                .arithmetic
                .cond_select(layouter, b, p.x.clone() * self.ec_params.zeta, p.x)?,
            y: p.y,
        })
    }

    pub fn cond_negate(
        &self,
        layouter: &mut impl Layouter<F>,
        b: Boolean<F>,
        p: Point<F>,
    ) -> Result<Point<F>, Error> {
        Ok(Point {
            x: p.x,
            y: self
                .arithmetic
                .cond_select(layouter, b, -p.y.clone(), p.y)?,
        })
    }

    pub fn cond_select_point(
        &self,
        layouter: &mut impl Layouter<F>,
        b: Boolean<F>,
        p1: Point<F>,
        p2: Point<F>,
    ) -> Result<Point<F>, Error> {
        Ok(Point {
            x: self
                .arithmetic
                .cond_select(layouter, b.clone(), p1.x, p2.x)?,
            y: self.arithmetic.cond_select(layouter, b, p1.y, p2.y)?,
        })
    }

    pub fn double(&self, layouter: &mut impl Layouter<F>, p: Point<F>) -> Result<Point<F>, Error> {
        let two = F::ONE + F::ONE;
        let three = two + F::ONE;
        let double_y = p.y.clone() * two;
        let three_x2 = self.arithmetic.mul(layouter, p.x.clone(), p.x.clone())? * three;
        let delta = self.arithmetic.div(layouter, three_x2, double_y)?;
        let double_x = p.x.clone() * two;
        let delta2 = self
            .arithmetic
            .mul(layouter, delta.clone(), delta.clone())?;
        let x3 = self.arithmetic.add(layouter, delta2, -double_x)?;
        let x_sub_x3 = self.arithmetic.add(layouter, p.x, -x3.clone())?;
        let delta_times_diff = self.arithmetic.mul(layouter, delta.clone(), x_sub_x3)?;
        let y3 = self.arithmetic.add(layouter, delta_times_diff, -p.y)?;
        self.assert_on_curve(x3.clone(), y3.clone());
        Ok(Point { x: x3, y: y3 })
    }

    pub fn add(
        &self,
        layouter: &mut impl Layouter<F>,
        p1: Point<F>,
        p2: Point<F>,
    ) -> Result<Point<F>, Error> {
        let delta_y = self.arithmetic.add(layouter, p2.y.clone(), -p1.y.clone())?;
        let delta_x = self.arithmetic.add(layouter, p2.x.clone(), -p1.x.clone())?;
        let delta = self.arithmetic.div(layouter, delta_y, delta_x)?;
        let delta2 = self
            .arithmetic
            .mul(layouter, delta.clone(), delta.clone())?;
        let tmp = self
            .arithmetic
            .add(layouter, delta2.clone(), -p1.x.clone())?;
        let x3 = self.arithmetic.add(layouter, tmp.clone(), -p2.x.clone())?;
        let x1_diff_x3 = self.arithmetic.add(layouter, p1.x.clone(), -x3.clone())?;
        let delta_times_diff = self.arithmetic.mul(layouter, delta.clone(), x1_diff_x3)?;
        let y3 = self.arithmetic.add(layouter, delta_times_diff, -p1.y)?;
        self.assert_on_curve(x3.clone(), y3.clone());
        Ok(Point { x: x3, y: y3 })
    }

    pub fn conditional_add(
        &self,
        layouter: &mut impl Layouter<F>,
        b: Boolean<F>,
        p1: Point<F>,
        p2: Point<F>,
    ) -> Result<Point<F>, Error> {
        let sum = self.add(layouter, p1.clone(), p2.clone())?;
        self.cond_select_point(layouter, b, sum, p1)
    }

    pub fn scale<const N: usize>(
        &self,
        layouter: &mut impl Layouter<F>,
        p: Point<F>,
        endo: BitScalar<F, N>,
    ) -> Result<Point<F>, Error> {
        if N % 2 != 0 {
            return Err(Error::Synthesis);
        }

        let acc = self.add(layouter, self.endo(p.clone()), p.clone())?;
        let mut acc = self.double(layouter, acc)?;
        let mut bs = endo.bits.into_iter();
        for _ in 0..(N >> 1) {
            acc = self.double(layouter, acc)?;
            acc = self.conditional_add(layouter, bs.next().unwrap(), acc, p.clone())?;
            acc = self.conditional_add(layouter, bs.next().unwrap(), acc, self.endo(p.clone()))?;
            self.assert_on_curve(acc.x.clone(), acc.y.clone());
        }
        Ok(acc)
    }
}

pub fn find_point_around_x<F: Field>(ec_params: &ECParams<F>, x: F) -> F {
    let mut delta = F::ZERO;
    for i in 0..256 {
        let true_x = x + delta;
        let y = (true_x * true_x * true_x + ec_params.b).sqrt();
        if y.is_some().into() {
            return delta;
        }
        delta += F::ONE;
    }
    panic!("Couldn't find point around x = {:?} in 256 iterations", x);
}
