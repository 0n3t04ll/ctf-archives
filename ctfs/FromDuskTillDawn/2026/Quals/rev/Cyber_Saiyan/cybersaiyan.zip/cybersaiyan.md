# Cyber Saiyan

For this challenge, you will need to generate a password for a custom-built character in the game `Dragon Ball Z: Budokai 3` for the PlayStation 2.


## Customizing Your Fighter

In Dragon Ball Z: Budokai 3, you have total control over how your characters develop. You can build a unique fighter by:

- Leveling Up & Stats: As you progress, you earn experience points to level up and manually upgrade specific attributes like Attack, Defense, and Ki.

- Capsule Customization: You can fully edit your character’s moveset and equipment by swapping "Capsules," allowing you to choose their special attacks, transformations, and support items.

## The Password System: Challenge Your Friends

Whenever your character levels up, the game generates a unique Character Password. This code acts as a digital "snapshot" of your specific build.

### Export Your Fighter: You can share this password with a friend.

Import the Rival: By entering your code into their game, your friend can face off against your custom-trained character, complete with your chosen stats and moves.


Note: Passwords must be entered in the Dragon Arena mode. Please be aware that Dragon Arena is not available from the start; you must unlock it by completing the game's Dragon Universe mode with every character available at the start of the game and Uub.

## How to insert passwords
- Go to Dragon Arena mode.
- Select `1P VS COM`
- Select your character
- Press `R1` to go to password tab
- Press `start` to open the password input screen

## Challenge aim
Generate the password for the following character:
- Character: Broly
- Health: 255
- Ki: 31
- Attack: 20
- Guard: 20
- Arts: 20
- Ability: 20
- CPU: 20

- capsule 0: Legendary Super Saiyan Broly
- capsule 1: Blasted Shell
- capsule 2: Blasted Shell
- capsule 3: Gigantic Press
- capsule 4: Gigantic Press
- capsule 5: Gigantic Meteor
- capsule 6: Gigantic Meteor

- the password must start with `DAJE!N`

The flag is: `DAJEROMA{<password with no spaces>}`

#
You sould obtain the character like the one in the image below:

![Broly](Cattura.PNG)

#
The correct password has been tested on the standard version (europe) and on Collector's Edition (europe) of the game, but should work on any version.
- Dragonball-Z-Budokai-3.iso  md5: `a99877d42cf92d5835353acf92f98b31`
- Dragonball-Z-Budokai-3-Collectors-Edition.iso md5: `8b4c48d8e133aa0c3817313353375419`