#!/bin/sh
python3 manage.py runserver&
/waf
