// app/static/js/scripts.js

document.addEventListener("DOMContentLoaded", function() {
    // Basic example: Show an alert if on index
    if (window.location.pathname === "/") {
        console.log("Welcome to ForgeMaster!");
    }
});
