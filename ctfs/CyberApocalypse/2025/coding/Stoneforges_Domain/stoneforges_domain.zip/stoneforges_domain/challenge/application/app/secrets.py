#!/usr/bin/env python3

username = "garrick"
password = "st0nes_4nd_5t!ck5"