#!/bin/bash
supervisorctl -c /etc/supervisor/supervisord.conf restart nginx