#!/bin/sh

BASE_DIR=$(pwd)
FLAG_FILE="./flag"
INITRD_DIR="$BASE_DIR/rootfs"
OUTPUT_FILE="$BASE_DIR/initramfs.cpio.gz"
BZIMAGE="$BASE_DIR/bzImage"

if [ -d "$INITRD_DIR" ]; then
    cd "$INITRD_DIR"
    find . -print0 | cpio --null -ov --format=newc --owner 0:0 | gzip -9 > "$OUTPUT_FILE"
    cd "$BASE_DIR"
fi

qemu-system-x86_64 \
    -m 128M \
    -nographic \
    -kernel "$BZIMAGE" \
    -initrd "$OUTPUT_FILE" \
    -no-reboot \
	-enable-kvm \
    -cpu qemu64,+smep,+smap \
    -net nic,model=virtio \
    -net user \
    -monitor /dev/null \
    -drive format=raw,file="$FLAG_FILE",if=virtio \
    -append "console=ttyS0 loglevel=3 oops=panic panic=-1 pti=on kaslr rdinit=/init" \
    -s
