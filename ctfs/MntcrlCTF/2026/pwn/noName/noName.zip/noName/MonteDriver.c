#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/types.h>
#include <linux/init.h>
#include <linux/ioctl.h>
#include <linux/mutex.h>
#include <linux/version.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("SoloPietro");
MODULE_DESCRIPTION("noName - MntcrlCTF");

#define DEVICE_NAME "MonteDriver"

#define MAX_CHUNK 17
#define CHUNK_SIZE 1024

typedef struct{
	int64_t idx;
	uint64_t size;
	char *buf;
}user_req_t;

#define MONTE_IOC_MAGIC 'M'
#define IOCTL_READ   _IOWR(MONTE_IOC_MAGIC, 0, user_req_t)
#define IOCTL_ALLOC  _IOW(MONTE_IOC_MAGIC, 1, user_req_t)
#define IOCTL_WRITE  _IOW(MONTE_IOC_MAGIC, 2, user_req_t)
#define IOCTL_DELETE _IOW(MONTE_IOC_MAGIC, 3, user_req_t)

struct monte_cache{
	char buf[CHUNK_SIZE];
};

static DEFINE_MUTEX(monte_lock);

char **monte_arr;
uint64_t allocated = 0;

static int  monte_open(struct inode *inodep, struct file *filep);
static int  monte_flush(struct file *filep, fl_owner_t id);
static int  monte_release(struct inode *inodep, struct file *filep);
static long monte_ioctl(struct file *filep, unsigned int cmd, unsigned long arg);

static long monte_alloc(uint64_t idx);
static long monte_read(uint64_t idx, char __user *buf);
static long monte_write(uint64_t idx, uint64_t size, char *buf);

static struct miscdevice monte_dev;
static const struct file_operations ops = {
    .open           = monte_open,
    .flush          = monte_flush,
    .release        = monte_release,
    .unlocked_ioctl = monte_ioctl,
};

static struct kmem_cache *monte_cachep;

static long monte_ioctl(struct file *filep, unsigned int cmd, unsigned long arg)
{
	user_req_t ureq;
	long ret = 0;
	
	if(copy_from_user(&ureq, (user_req_t *)arg, sizeof(user_req_t))){
		return -EINVAL;
	}

	mutex_lock(&monte_lock);
		switch(cmd){
			case IOCTL_ALLOC:
				ret = monte_alloc(ureq.idx);
				break;
			case IOCTL_READ:
				ret = monte_read(ureq.idx, ureq.buf);
				break;
			case IOCTL_WRITE:
				ret = monte_write(ureq.idx, ureq.size, ureq.buf);
				break;
			case IOCTL_DELETE:
			//TODO: implement DELETE
			break;
		default:
			ret = -EINVAL;
	}
	mutex_unlock(&monte_lock);
    return ret;
}

static long monte_alloc(uint64_t idx)
{
	if(idx >= MAX_CHUNK || allocated >= MAX_CHUNK){
		return -ENOSPC;
	}

	monte_arr[idx] = kmem_cache_zalloc(monte_cachep, GFP_KERNEL);

	if(!monte_arr[idx]){
		return -EFAULT;
	}

	allocated++;
	return 0;
}

static long monte_read(uint64_t idx, char __user *buf)
{
	if(idx >= MAX_CHUNK || !monte_arr[idx]){
		return -EINVAL;
	}

	if(copy_to_user(buf, monte_arr[idx], CHUNK_SIZE)){
        return -EFAULT;
    }

	return 0;
}

static long monte_write(uint64_t idx, uint64_t size, char __user *buf)
{
	if(idx >= MAX_CHUNK || !monte_arr[idx]){
		return -EINVAL;
	}
	
	if (size > CHUNK_SIZE){
        return -EINVAL;
    }

    if(copy_from_user(monte_arr[idx], buf, size)){
		return -EFAULT; 
	}
    
	    return size;
}

static int  monte_open(struct inode *inodep, struct file *filep)
{
    printk(KERN_INFO "Device opened");
    return 0;
}

static int monte_release(struct inode *inodep, struct file *filep)
{
    return 0;
}

static int monte_flush(struct file *filep, fl_owner_t id)
{
	mutex_lock(&monte_lock);
	for(int i = 0; i < MAX_CHUNK; i++){
		if(monte_arr[i]){
			kmem_cache_free(monte_cachep, monte_arr[i]);
		}
	}
	allocated = 0;
	mutex_unlock(&monte_lock);
	kmem_cache_shrink(monte_cachep);
	return 0;
}

static int __init MonteInit(void)
{
	monte_dev.minor = MISC_DYNAMIC_MINOR;
	monte_dev.name = DEVICE_NAME;
	monte_dev.fops = &ops;
	monte_dev.mode = 0644;

	mutex_init(&monte_lock);
	monte_arr = kzalloc(MAX_CHUNK * sizeof(char *), GFP_KERNEL);

	if(misc_register(&monte_dev) && !monte_arr){
		return -1;
	}

	monte_cachep = KMEM_CACHE_USERCOPY(monte_cache, SLAB_PANIC | SLAB_ACCOUNT, buf);

	if(!monte_cachep){
		return -1;
	}

	printk(KERN_INFO "Are you ready?\n");
	return 0;	
}

static void __exit MonteExit(void)
{
	misc_deregister(&monte_dev);
	mutex_destroy(&monte_lock);

	for(int i = 0; i < MAX_CHUNK; i++){
		if(monte_arr[i]){
			kmem_cache_free(monte_cachep, monte_arr[i]);
		}
	}
	kfree(monte_arr);	
	kmem_cache_shrink(monte_cachep);
	allocated = 0;
	
	printk(KERN_INFO "Noooo no more Monte Driver\n");
}

module_init(MonteInit);
module_exit(MonteExit);
