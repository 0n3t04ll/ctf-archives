#!/usr/bin/env bash
set -euo pipefail

if [ -z "${FLAG:-}" ]; then
    echo "FLAG environment variable is required" >&2
    exit 1
fi

printf '%s\n' "${FLAG}" > /flag.txt
chmod 644 /flag.txt

tmp_dir="$(mktemp -d)"
cleanup() {
    rm -rf "${tmp_dir}"
}
trap cleanup EXIT

cp /flag.txt "${tmp_dir}/flag.txt"
xorriso -as mkisofs -o /flag.iso "${tmp_dir}" >/dev/null 2>&1
chmod 644 /flag.iso
rm -rf /flag.txt "${tmp_dir}"

exec xinetd -f /home/user/xinetd.conf -dontfork
