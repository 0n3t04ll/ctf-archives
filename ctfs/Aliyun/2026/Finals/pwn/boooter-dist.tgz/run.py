#!/usr/bin/env python3
"""
Deploy script for boooter challenge (xinetd).
1. Proof of work (hash)
2. Use prebuilt flag ISO prepared by container start script
3. Start QEMU with timeout (e.g. 60s) via `timeout`; subsequent I/O is QEMU serial.
"""
import os
import sys
import subprocess
import hashlib
import secrets

# Paths (override via env in deployment)
BOOT_ISO = os.environ.get('BOOT_ISO', '/home/user/boooter.iso')
FLAG_ISO = os.environ.get('FLAG_ISO', '/flag.iso')
POW_DIFFICULTY = int(os.environ.get('POW_DIFFICULTY', '6'))
QEMU_TIMEOUT_SEC = int(os.environ.get('QEMU_TIMEOUT', '120'))


def main():
    istream = sys.stdin.buffer
    ostream = sys.stdout.buffer

    # 1) Proof of work
    ostream.write(b'Proof of work: ')
    ostream.flush()
    prefix = secrets.token_hex(8)
    ostream.write(('POW %s %d\n' % (prefix, POW_DIFFICULTY)).encode())
    ostream.flush()
    try:
        line = istream.readline()
        if not line or not line.strip():
            ostream.write(b'PoW failed (no solution)\n')
            ostream.flush()
            return 1
        nonce = line.decode('utf-8', errors='replace').strip()
        digest = hashlib.sha256((prefix + nonce).encode()).hexdigest()
        if digest[:POW_DIFFICULTY] != '0' * POW_DIFFICULTY:
            ostream.write(b'PoW failed (invalid)\n')
            ostream.flush()
            return 1
    except Exception as e:
        ostream.write(('PoW error: %s\n' % e).encode())
        ostream.flush()
        return 1

    ostream.write(b'PoW passed\n')
    ostream.flush()
    if not os.path.isfile(BOOT_ISO):
        ostream.write(b'Boot ISO not found\n')
        ostream.flush()
        return 1
    if not os.path.isfile(FLAG_ISO):
        ostream.write(b'Flag ISO not found\n')
        ostream.flush()
        return 1

    qemu_cmd = [
        'timeout', str(QEMU_TIMEOUT_SEC),
        'qemu-system-x86_64',
        '-cdrom', BOOT_ISO,
        '-drive', 'file=%s,media=cdrom,if=ide,index=1' % FLAG_ISO,
        '-serial', 'stdio',
        '-m', '16M',
        '-nographic',
        '-no-reboot',
        '-no-shutdown',
        '-monitor', 'none',
    ]
    p = subprocess.Popen(
        qemu_cmd,
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )
    sys.exit(p.wait())


if __name__ == '__main__':
    main()
