from fastecdsa import curve, ecdsa, keys
from gmssl import sm2, func
import os, signal, json, secrets, gmpy2

FLAG = os.getenv("FLAG", "alictf{}")

class Challenge:
    def __init__(self):
        while True:
            x, y = [secrets.randbits(512) | 1 for _ in "xy"]
            p = x ** 2 + 2 * y ** 2
            q = ((p - 1) ** 2 + 4 * x ** 2) >> 3
            if gmpy2.is_prime(p) and gmpy2.is_prime(q): break
        r = int(gmpy2.next_prime(secrets.randbits(2048)))
        n, e = p * q * r, 0x10001
        d = pow(e, -1, (p - 1) * (q - 1) * (r - 1))
        self.n, self.e, self.d = (n, e, d)
        
        self.curve = curve.W25519
        self.private_key = keys.gen_private_key(self.curve)
        self.public_key = keys.get_public_key(self.private_key, self.curve)
        
        self.sm2 = sm2.CryptSM2(private_key="", public_key="")
        self.sm2.private_key = func.random_hex(self.sm2.para_len)
        self.sm2.public_key = self.sm2._kg(int(self.sm2.private_key, 16), self.sm2.ecc_table["g"])
    
    def encrypt(self, plaintext: str):
        ciphertext = self.sm2.encrypt(bytes.fromhex(plaintext)).hex()
        message = f"decrypt {ciphertext}".encode()
        c = pow(int(message.hex(), 16), self.d, self.n)
        r, s = ecdsa.sign(message, self.private_key, curve=self.curve)
        sig = self.sm2.sign(message, func.random_hex(self.sm2.para_len))
        return {"message": message.hex(), "rsa_sig": c, "ecdsa_sig": [r, s], "sm2_sig": sig}
    
    def decrypt(self, message: str, rsa_sig: int, ecdsa_sig: list[int], sm2_sig: str):
        message = bytes.fromhex(message)
        valid = pow(rsa_sig, self.e, self.n) == int(message.hex(), 16)
        valid &= ecdsa.verify(ecdsa_sig, message, self.public_key, curve=self.curve)
        valid &= self.sm2.verify(sm2_sig, message)
        if not valid:
            return {"error": "invalid signature"}
        message = message.decode()
        if message == "cat /flag.txt":
            return {"flag": FLAG}
        command, *args = message.split()
        if command == "decrypt":
            return {"plaintext": self.sm2.decrypt(bytes.fromhex(*args)).hex()}
        return {"error": "invalid command"}
    
    def __call__(self, option: str, **kwargs):
        if option in ["encrypt", "decrypt"]:
            return getattr(self, option)(**kwargs)
        return {"error": "invalid option"}

print("⏳")
signal.alarm(600)
challenge = Challenge()
try:
    while True:
        print("📥", json.dumps(challenge(**json.loads(input("📤 ")))))
except:
    print("⛔")
    exit()
