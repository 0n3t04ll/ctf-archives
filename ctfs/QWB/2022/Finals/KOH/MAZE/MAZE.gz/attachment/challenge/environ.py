#!/usr/bin/env python3
import os
import random
import json

random.seed(os.urandom(32))

# This challenge relies on several resources:
# qemu-user-static to do multi-arch support
# shellcode runners compiled into different architectures
# a shuffl binary to handle sandboxing
RESOURCE_DIR = os.path.dirname(os.path.realpath(__file__))
DATA_DIR = os.path.join(RESOURCE_DIR, "tmp")
SHUFFL_PATH = os.path.join(RESOURCE_DIR, "shuffl")
RANK_PATH = os.path.join(DATA_DIR, "rank.json")
MAZE_PATH = os.path.join(DATA_DIR, "maze")

#
VALID_ARCHES = {"x86_64", "aarch64", "riscv64", "ppc64", "sparc64"}

# These is the map refresh interval
REFRESH_TIMEOUT = int(os.environ.get("REFRESH_TIMEOUT", "600"))

# These is the time interval for each team to submit payload
TIME_INTERVAL = int(os.environ.get("TIME_INTERVAL", "120"))

# These is at the interval at which successive accesses are identified
CONNECT_INTERVAL = int(os.environ.get("CONNECT_INTERVAL", "10"))

# These is the limit on the number of short interval accesses
SHORT_INTERVAL = int(os.environ.get("SHORT_INTERVAL", "5"))

# These is the interval for which access is prohibited
BAN_INTERVAL = int(os.environ.get("SHORT_INTERVAL", "300"))

# These are the maze size
MAZE_ROW = int(os.environ.get("MAZE", "100"))
MAZE_COL = int(os.environ.get("MAZE", "100"))

# Database Config
DB_HOST = "localhost"
DB_NAME = "root"
DB_DABS = "maze"
DB_PASS = "123123123123123"
