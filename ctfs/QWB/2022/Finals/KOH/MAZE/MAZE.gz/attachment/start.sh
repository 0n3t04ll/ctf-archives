#!/bin/sh

UUID=$(uuidgen |sed 's/-//g')

service mysql start
mysql -uroot -e "create database maze;use mysql;update user set authentication_string='' where user='root';update user set plugin='mysql_native_password' where user='root';FLUSH PRIVILEGES;alter user 'root'@'localhost' identified by '$UUID';flush privileges;" 
mysql -uroot -p$UUID maze < /maze.sql

echo DB_PASS=\"$UUID\" >> /environ.py

rm -rf /maze.sql

chmod go-rwx /proc && xinetd -filelog /dev/stderr -dontfork -f /service.conf