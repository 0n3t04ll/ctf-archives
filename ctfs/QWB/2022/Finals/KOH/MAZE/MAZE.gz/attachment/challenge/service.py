#!/usr/bin/env python3
import subprocess
import tempfile
import random
import shutil
import time
import os
import game
import string
import sys
import pymysql
from environ import *

def query(sql, select):
	con = pymysql.connect(host=DB_HOST, user=DB_NAME, password=DB_PASS, database=DB_DABS, cursorclass=pymysql.cursors.DictCursor)
	cur = con.cursor()
	if select:
		cur.execute(sql)
		resList = cur.fetchall()
		res = [x for x in resList]
		cur.close()
		con.close()

		return res
	else:
		cur.execute(sql)
		cur.close()
		con.commit()
		con.close()

def get_timestamp():
	return int(time.time())

def maze_init():
	sql = "select time, map, isinit from `map`"
	maze_data = query(sql, True)[0]

	# If the challenge just launched or the previous maze has been used from enough time, we need to initialize the maze map.
	if (not maze_data['isinit']) or (get_timestamp() - maze_data['time'] > REFRESH_TIMEOUT):
		maze = game.createMaze(MAZE_ROW, MAZE_COL)
		sql = f"update `map` set time={get_timestamp()}, map='{game.writeMap(maze)}', isinit=1 where id=1"
		query(sql, False)
		game.saveMap(maze, MAZE_PATH)
		print("# A new maze map has been built...")
	else:
		maze = game.readMap(maze_data['map'])

	return maze

def receive_teamtoken():
	print("# Before we start, we need to check your identity.")
	try:
		teamtoken = str(input("Input your teamtoken: ")[:32]).lower()
		return teamtoken
	except:
		print("# Invalid Token!!!!")
		sys.exit(6)

def validate_teamtoken(teamtoken):
	if len(teamtoken) == 32 and all(c in string.hexdigits for c in teamtoken):
		sql = f"select team from `teams` where teamtoken='{teamtoken}'"
		team_data = query(sql, True)
		if len(team_data) == 0:
			return False

		print(f"Welcome, team {team_data[0]['team']}...")
		return team_data[0]['team']

	else:
		return False

def get_lasttime(team):
	sql = f"select time from `history` where team='{team}' order by id DESC limit 1"
	res = query(sql, True)
	return res[0]['time'] if len(res) == 1 else None

def show_rank():
	print("# Current valid ranking board:")
	rank = get_rank()
	for x in rank:
		print(f"Rank {x['rank']}: team-{x['team']} with code length - {x['len']}")
	print("")

def save_history(team, shellcode):
	sql = f"insert `history`(team, time, code, len) values('{team}', {get_timestamp()}, '{shellcode.hex()}', {len(shellcode)})"
	query(sql, False)

def receive_shellcode():
	print("# Now, let's starting your challenge to the king!")
	try:
		shellcode = bytes.fromhex(input(f"Input your hex-encoded shellcode: "))[:4096]
		return shellcode
	except:
		print("# What I need is hexadecimal characters!!!!")
		sys.exit(5)

def validate_functionality(shellcode, maze):
	# Let's set up our sandbox.
	tmpdir = tempfile.mkdtemp()
	os.chmod(tmpdir, 0o755)
	shutil.copy(SHUFFL_PATH, tmpdir)
	for arch in VALID_ARCHES:
		shutil.copy(os.path.join(RESOURCE_DIR, f"runner-{arch}"), tmpdir)
		shutil.copy(f"/usr/bin/qemu-{arch}-static", tmpdir)

	# copy maze_map
	shutil.copy(MAZE_PATH, tmpdir)

	# We'll try the shellcode in every valid architecture...
	for arch in VALID_ARCHES:
		print(f"Trying your shellcode as {arch}....")

		# This runs shuffl, which will sandbox into the directory and run the right shellcode launcher via the appropriate qemu.
		# The shellcode must print The operation of getting out of the maze.
		# Output on stderr comes back to you, in case it's useful.
		p = subprocess.Popen([
			os.path.join(tmpdir, os.path.basename(SHUFFL_PATH)), "5",
			f"./qemu-{arch}-static", f"./runner-{arch}"
		], cwd=tmpdir, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=1)
		walkers, _ = p.communicate(shellcode)
		print(f"Your shellcode returned with return code {p.returncode}.")
		if game.mazeCheck(walkers, maze):
			print("CONGRATULATIONS! You solved the maze!")
			shutil.rmtree(tmpdir)
			return True
		else:
			print(f"Unfortunately, Your shellcode doesn't seem to work in arch-{arch}")

	print(f"The shellcode does not seem to solve the maze....")
	shutil.rmtree(tmpdir)
	return False

def save_rank(team, length):
	sql = f"update `rank` set len={length}, isvalid=1 where team='{team}'"
	query(sql, False)

def get_rank():
	data = []
	sql = f"select teamtoken, team, len from `rank` where isvalid=1 order by len ASC"
	res = query(sql, True)
	
	last_length = 0
	rank = 0
	interval = 1
	for r in res:
		if r['len'] != last_length:
			rank += interval
			interval = 1
			last_length = r['len']
		else:
			interval += 1	
		data.append({"teamtoken": r['teamtoken'], "team": r['team'], "rank": rank, "len": r["len"]})

	return data		

def main():
	teamtoken = receive_teamtoken()
	team = validate_teamtoken(teamtoken)
	if not team:
		print("# Your team is not eligible for our challenge...")
		sys.exit(1)

	last_time = get_lasttime(team)
	if last_time and get_timestamp() - last_time <= TIME_INTERVAL:
		print(f"# Too fast submission. Please wait {TIME_INTERVAL - (get_timestamp() - last_time)} seconds...")
		sys.exit(2)

	show_rank()
	maze = maze_init()

	shellcode = receive_shellcode()
	save_history(team, shellcode)

	if not validate_functionality(shellcode, maze):
		print("Your shellcode did not solve the maze.")
		sys.exit(4)

	save_rank(team, len(shellcode))

main()