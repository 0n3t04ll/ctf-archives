#!/usr/bin/env python3
import random
import os

def readMap(maps):
    maze = []
    for row in maps.split("\n"):
        maze.append([x for x in row])

    return maze

def writeMap(maze):
    maps = ''
    for row in maze:
        maps += ''.join(row) + '\n'

    return maps.strip("\n")

def saveMap(maze, path):
    maps = ''
    for row in maze:
        maps += ''.join(row) + '\n'

    with open(path, "w") as f:
        f.write(maps)

def printMap(maze):
    maps = ''
    for row in maze:
        maps += ''.join(row) + '\n'
    print(maps)

def createMaze(row, col):
    random.seed(os.urandom(32))
    maplist = []
    aa = 0
    need = []
    for j in range(row + 1):
        if aa == 0:
            aa = 1
            maprow = []
            for i in range(col + 1):
                maprow.append('#')
            maplist.append(maprow)
        else:
            aa = 0
            maprow = []
            bb = 0
            for i in range(col + 1):
                if bb == 0:
                    bb = 1
                    maprow.append('#')
                else:
                    bb = 0
                    need.append((j, i))
                    maprow.append(' ')
            maplist.append(maprow)
    maplist[0][1] = ' '
    maplist[-1][-2] = ' '
    x = 1
    y = 1
    need.remove((1, 1))
    listing = []
    while len(need) > 0:
        aroundit = []
        try:
            if x - 2 < 0:
                print(1 + "1")
            maplist[x - 2][y] = ' '
            if (x - 2, y) in need:
                aroundit.append("1")
        except:
            pass
        try:
            maplist[x + 2][y] = ' '
            if (x + 2, y) in need:
                aroundit.append("2")
        except:
            pass
        try:
            maplist[x][y + 2] = ' '
            if (x, y + 2) in need:
                aroundit.append("3")
        except:
            pass
        try:
            if y - 2 < 0:
                print(1 + "1")
            maplist[x][y - 2] = ' '
            if (x, y - 2) in need:
                aroundit.append("4")
        except:
            pass

        if len(aroundit) > 0:
            listing.append((x, y))
            it = random.choice(aroundit)
            if it == "1":
                maplist[x-1][y], x = (' ', x-2)
            if it == "2":
                maplist[x+1][y], x = (' ', x+2)
            if it == "3":
                maplist[x][y+1], y = (' ', y+2)
            if it == "4":
                maplist[x][y-1], y = (' ', y-2)

            need.remove((x, y))
        else:
            x, y = listing[-1]
            listing.pop()
    
    maplist[0][1] = 'S'
    maplist[-1][-2] = 'E'   
    return maplist


def mazeCheck(walkers, maze):
    try:
        walkers = walkers.decode().lower()
    except:
        return False

    x, y = (0, 1)
    for step in walkers:
        if step == 'w' and maze[x-1][y] != '#':
            x -= 1
        elif step == 's' and maze[x+1][y] != '#':
            x += 1
        elif step == 'a' and maze[x][y-1] != '#':
            y -= 1
        elif step == 'd' and maze[x][y+1] != '#':
            y += 1
        else:
            break

    return x == 100 and y == 99