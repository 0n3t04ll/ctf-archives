import argparse
from distutils.command.upload import upload
import os
import logging
from secrets import choice 
from pwn import *
import base64

# context(log_level="debug")


def showScoreboard(io):
    print((io.recvuntil(b"***********Over***********")).decode("utf8"))
    print()

def uploadFile(io):
    fileName = input("Input file path(ex: ./uploadFile): ").rstrip()

    if not os.path.exists(fileName):
        print("[-] No file")
        exit()

    with open(fileName, "rb") as fd:
        fileData = fd.read()
    sendData = base64.b64encode(fileData)
    round = len(sendData) // 4096 + 1 if len(sendData) % 4096 > 0 else 0

    io.sendline(str(len(sendData)))

    for i in range(round):
        io.sendline(sendData[i * 4096: (i + 1) * 4096])
    
    print("[+]File %s upload success!" % fileName)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='client')
    parser.add_argument("ip", help='Server ip')
    parser.add_argument("port", help='Server port')
    
    args = parser.parse_args()

    io = remote(args.ip, args.port)
    teamToken = bytes(input("Input your teamtoken: ").rstrip(), encoding = "utf8")
    io.sendline(teamToken)
    print((io.recvuntil(b"*\n**************************")).decode("utf8"))
    print()

    while(True):
        choice = input("Choose: ").strip()
        io.sendline(bytes(choice, encoding='utf8'))
        if choice == "1":
            showScoreboard(io)
        elif choice == "2":
            uploadFile(io)
            
            sleep(10)

        else:
            print("[-]Error code")



    
    