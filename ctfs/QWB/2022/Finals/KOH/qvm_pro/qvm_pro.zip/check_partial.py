# -*- coding: UTF-8 -*-
from pwn import *
import random, string, subprocess, os, sys
from hashlib import sha256

def ShowRank():
	print "\n=================== Rank List ====================="
	print "     TEAM                          SCORE | LENGTH"
	print "---------------------------------------------------"
	# View()
	print "==================================================="

def proof_of_work():
    chal = ''.join(random.choice(string.letters+string.digits) for _ in xrange(16))
    print 'chal: '+chal
    sol = raw_input('sol: ')
    if len(sol) != 4 or not sha256(chal + sol).hexdigest().startswith('00000'):
        print 'NO!'
        exit()

def Check():
	proof_of_work()
	tokenlist = []
	
	token = raw_input("Teamtoken: ")
	if token not in tokenlist:
		print "Error."
		sys.exit(0)

	length = raw_input("Length: ")
	code = raw_input("Code: ")
	entrypoint = raw_input("Entrypoint: ")
	try:
		inlen = int(length)
		epoint = int(entrypoint)
		if inlen <= 0 or inlen > 1500 :
			print "Error."
			sys.exit(0)
		if len(code) != inlen*4 :
			print "Error."
			sys.exit(0)
		if epoint < 0 or epoint >= inlen:
			print "Error."
			sys.exit(0)
	except Exception as e:
		print "Error."
		sys.exit(0)

	score = 0
	while True:
		try:
			score += 1
			print "Testing: " + str(score)
			io = process("./qvmpro")
			# context.log_level = 'debug'
			io.readuntil('Starting...\n')
			io.sendlineafter('Length: ', length)
			io.sendafter('Code: ', code)
			io.sendlineafter('Entrypoint: ', entrypoint)

			io.readuntil("IN:", timeout=2)
			io.sendline(str(score))

			if score >= 0 and score <= 46:
				ret = io.readline(timeout=12)[:-1]
			elif score >= 47 and score <= 300:
				ret = io.readline(timeout=20)[:-1]
			else:
				ret = io.readline(timeout=30)[:-1]

			io.close()

			if ret != str(Fibon(score)):
				score -= 1
				break
			
		except Exception as e:
			io.close()
			score -= 1
			break

	# Update(token, score, length)
	print "score: " + str(score)
	print "length: " + str(length)


os.chdir(os.path.dirname(os.path.realpath(__file__)))

print "+---------------------+"
print "|       qvm pro       |"
print "|                     |"
print "|     1. ranklist     |"
print "|     2. submite      |"
print "+---------------------+"

cmd = raw_input("CMD>> ")

if cmd == '2':
	Check()
else:
	ShowRank()
	


