import hashlib

flag = open("flag.txt","rb").read()
assert len(flag) == 32

def gpp(eta,etamin=256):
  if eta<=(2*etamin):
    return random_prime(2^eta,False,2^(eta-1))
  else:
    return random_prime(2^etamin,False,2^(etamin-1))*gpp(eta-etamin)
    
p = 2*gpp(3217)+1
while p not in Primes():
    p = 2*gpp(3217)+1 
g=Zmod(p)(4)
padding=randint(0,2^3217)
x=Zmod((p-1)//2)(int.from_bytes(flag,'big')^^padding)
y=g^x
# Fast RNG Init
a, b = [], []
for i in range(168):
    a.append(randint(1,(p-1)//2))
    b.append(g^a[i])

output = open("output.txt","w")
for i in range(14500):
    r = 1
    k = 0
    for j in range(168):
        if randint(0,1):
            r*=b[j]
            k+=a[j]
    e = int(hashlib.sha256(f"c{r}ys".encode()).hexdigest(), 16)
    s = k - x*e
    assert e == int(hashlib.sha256(f"c{g^s*y^e}ys".encode()).hexdigest(), 16)
    print(s, e, file=output)

print(p, y, padding, file=output)