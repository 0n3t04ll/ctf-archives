/*
 * TinyFS - Tiny Filesystem for SECCON 2025
 * 
 * Target: Linux 6.17.8
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/pagemap.h>
#include <linux/dcache.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/string.h>
#include <linux/buffer_head.h>
#include <linux/version.h>
#include <asm/atomic.h>

#define TINY_FS_MAGIC     0x4e4f43434553 // "SECCON"
#define TINY_FS_BLOCKSIZE (0x1000)
#define TINY_FS_MAX_NAME  (0x3f)
#define TINY_FS_MAX_OBJS  (0x8)

MODULE_LICENSE("GPL");
MODULE_AUTHOR("ShiftCrops");
MODULE_DESCRIPTION("Tiny Filesystem for SECCON 2025");
MODULE_VERSION("1.0");

/* Per-superblock filesystem information */
struct tiny_fs_sb_info {
	struct list_head obj_list;
	struct list_head node_list;
	struct mutex lock;
	atomic64_t next_ino;
	uint32_t n_objs;
};

/* File system metadata structure */
struct tiny_fs_object {
	char name[TINY_FS_MAX_NAME+1];
	uint64_t parent_ino;
	struct tiny_fs_node *node;
	struct list_head list;
};

struct tiny_fs_node {
	uint64_t ino;
	uint32_t refcnt;
	mode_t mode;
	kuid_t uid;
	kgid_t gid;
	size_t size;
	struct list_head list;
	char *data;
};

/* Helper macro to get sb_info from super_block */
#define SB_FS_INFO(sb) ((struct tiny_fs_sb_info *)(sb)->s_fs_info)

#define TINY_FS_TIME_ALL (S_ATIME | S_MTIME | S_CTIME)
#define TINY_FS_TIME_MOD (S_MTIME | S_CTIME)

static struct tiny_fs_object *tiny_fs_create_object(struct tiny_fs_sb_info *sbi, const char *name, struct tiny_fs_node *fs_node, uint64_t parent_ino) {
	struct tiny_fs_object *fs_object;

	if(!sbi || !fs_node || sbi->n_objs >= TINY_FS_MAX_OBJS)
		return NULL;

	fs_object = kmalloc(sizeof(struct tiny_fs_object), GFP_KERNEL);
	if (!fs_object) return NULL;
	pr_debug("tiny_fs_create_object: %p\n", fs_object);

	*fs_object = (struct tiny_fs_object){
		.parent_ino = parent_ino,
		.node       = fs_node,
	};
	strncat(fs_object->name, name, TINY_FS_MAX_NAME);

	mutex_lock(&sbi->lock);
	list_add_tail(&fs_object->list, &sbi->obj_list);
	fs_node->refcnt++;
	sbi->n_objs++;
	mutex_unlock(&sbi->lock);

	return fs_object;
}

static struct tiny_fs_node *tiny_fs_create_node(struct tiny_fs_sb_info *sbi, mode_t mode, kuid_t uid, kgid_t gid) {
	struct tiny_fs_node *fs_node;

	if(!sbi) return NULL;

	uint64_t ino = atomic64_inc_return(&sbi->next_ino);
	if(!ino) return NULL;

	fs_node = kmalloc(sizeof(struct tiny_fs_node), GFP_KERNEL);
	if (!fs_node) return NULL;
	pr_debug("tiny_fs_create_node: fs_node = %p\n", fs_node);

	*fs_node = (struct tiny_fs_node){
		.ino    = ino,
		.refcnt = 0,
		.mode   = mode,
		.size   = 0,
		.uid    = uid,
		.gid    = gid,
	};

	if (S_ISREG(mode)) {
		char *data;
		data = kzalloc(TINY_FS_BLOCKSIZE, GFP_KERNEL);
		if (!data) {
			kfree(fs_node);
			return NULL;
		}
		pr_debug("tiny_fs_create_node: data = %p\n", data);
		fs_node->data = data;
	}

	mutex_lock(&sbi->lock);
	list_add_tail(&fs_node->list, &sbi->node_list);
	mutex_unlock(&sbi->lock);

	return fs_node;
}

static int tiny_fs_remove_object_unsafe(struct tiny_fs_sb_info *sbi, struct tiny_fs_object *fs_object) {
	struct tiny_fs_node *fs_node;

	if(!sbi || !fs_object)
		return -1;

	list_del(&fs_object->list);
	sbi->n_objs--;

	fs_node = fs_object->node;
	if(!(--fs_node->refcnt)){
		pr_debug("tiny_fs_remove_object: freeing node for ino=%llu (last link)\n", fs_node->ino);

		/* Only free data when this is the last link */
		list_del(&fs_node->list);
		pr_debug("tiny_fs_remove_object: data = %p\n", fs_node->data);
		if (S_ISREG(fs_node->mode))
			kfree(fs_node->data);
		kfree(fs_node);
	}
	kfree(fs_object);

	return 0;
}

static struct tiny_fs_object *tiny_fs_find_object_by_name_unsafe(const struct inode *parent_dir, const char *name) {
	struct tiny_fs_object *fs_object;
	struct tiny_fs_sb_info *sbi = SB_FS_INFO(parent_dir->i_sb);
	uint64_t parent_ino = parent_dir->i_ino;

	list_for_each_entry(fs_object, &sbi->obj_list, list) {
		if (!strncmp(fs_object->name, name, TINY_FS_MAX_NAME) && fs_object->parent_ino == parent_ino)
			return fs_object;
	}
	return NULL;
}

static inline struct tiny_fs_object *tiny_fs_find_object_by_name(const struct inode *parent_dir, const char *name) {
	struct tiny_fs_object *fs_object;
	struct tiny_fs_sb_info *sbi = parent_dir ? SB_FS_INFO(parent_dir->i_sb) : NULL;

	if(!sbi) return NULL;

	mutex_lock(&sbi->lock);
	fs_object = tiny_fs_find_object_by_name_unsafe(parent_dir, name);
	mutex_unlock(&sbi->lock);

	return fs_object;
}

static struct tiny_fs_node *tiny_fs_find_node_by_ino_unsafe(struct tiny_fs_sb_info *sbi, uint64_t ino) {
	struct tiny_fs_node *fs_node;

	list_for_each_entry(fs_node, &sbi->node_list, list) {
		if (fs_node->ino == ino)
			return fs_node;
	}
	return NULL;
}

static inline struct tiny_fs_node *tiny_fs_find_node_by_ino(struct tiny_fs_sb_info *sbi, uint64_t ino) {
	struct tiny_fs_node *fs_node;

	if(!sbi) return NULL;

	mutex_lock(&sbi->lock);
	fs_node = tiny_fs_find_node_by_ino_unsafe(sbi, ino);
	mutex_unlock(&sbi->lock);

	return fs_node;
}

/* Forward declarations */
static const struct inode_operations tiny_fs_inode_ops;
static const struct file_operations tiny_fs_file_ops;

/* VFS operation: lookup */
static struct dentry *tiny_fs_lookup(struct inode *dir, struct dentry *dentry, unsigned int flags) {
	struct tiny_fs_object *fs_object;
	struct tiny_fs_node *fs_node;
	struct inode *inode = NULL;
	struct tiny_fs_sb_info *sbi = dir ? SB_FS_INFO(dir->i_sb) : NULL;
	struct dentry *ret = NULL;

	pr_info("tinyfs: lookup '%s' in ino=%lu\n", dentry->d_name.name, dir->i_ino);

	if(!sbi) return NULL;

	mutex_lock(&sbi->lock);

	fs_object = tiny_fs_find_object_by_name_unsafe(dir, dentry->d_name.name);
	if (!fs_object)
		goto OUT;

	fs_node = fs_object->node;
	inode = iget_locked(dir->i_sb, fs_node->ino);
	if (!inode){
		ret = ERR_PTR(-ENOMEM);
		goto ERR;
	}

	if (inode->i_state & I_NEW) {
		inode->i_mode = fs_node->mode;
		inode->i_size = fs_node->size;
		inode->i_uid  = fs_node->uid;
		inode->i_gid  = fs_node->gid;
		inode_update_timestamps(inode, TINY_FS_TIME_ALL);

		if (S_ISDIR(inode->i_mode)) {
			inode->i_op  = &tiny_fs_inode_ops;
			inode->i_fop = &simple_dir_operations;
			//inc_nlink(inode);
		}
		else if (S_ISREG(inode->i_mode)) {
			inode->i_op  = &tiny_fs_inode_ops;
			inode->i_fop = &tiny_fs_file_ops;
		}
	}

	unlock_new_inode(inode);

OUT:
	d_add(dentry, inode);
ERR:
	mutex_unlock(&sbi->lock);
	return ret;
}

/* VFS operation: create */
static int tiny_fs_create(struct mnt_idmap *idmap, struct inode *dir, struct dentry *dentry, umode_t mode, bool excl) {
	struct tiny_fs_object *fs_object;
	struct tiny_fs_node *fs_node;
	struct inode *inode;
	struct super_block *sb = dir ? dir->i_sb : NULL;
	struct tiny_fs_sb_info *sbi = sb ? SB_FS_INFO(sb) : NULL;

	kuid_t uid = current_fsuid();
	kgid_t gid = current_fsgid();

	pr_info("tinyfs: create '%s' in ino=%lu (uid=%u, gid=%u)\n",
		 dentry->d_name.name, dir->i_ino, from_kuid(&init_user_ns, uid), from_kgid(&init_user_ns, gid));

	if(!sbi) return -ENOMEM;

	if (strlen(dentry->d_name.name) > TINY_FS_MAX_NAME)
		return -ENAMETOOLONG;

	inode = new_inode(sb);
	if (!inode)
		return -ENOMEM;

	/* Create object */
	fs_node   = tiny_fs_create_node(sbi, S_IFREG | mode, uid, gid);
	if (!fs_node)   goto ERR1;
	fs_object = tiny_fs_create_object(sbi, dentry->d_name.name, fs_node, dir->i_ino);
	if (!fs_object) goto ERR2;

	inode->i_ino  = fs_object->node->ino;
	inode->i_mode = S_IFREG | mode;
	inode->i_uid  = uid;
	inode->i_gid  = gid;
	inode->i_op   = &tiny_fs_inode_ops;
	inode->i_fop  = &tiny_fs_file_ops;
	inode_update_timestamps(inode, TINY_FS_TIME_ALL);

	d_instantiate(dentry, inode);

	return 0;

ERR2:
	mutex_lock(&sbi->lock);
	list_del(&fs_node->list);
	mutex_unlock(&sbi->lock);
	kfree(fs_node->data);
	kfree(fs_node);
ERR1:
	iput(inode);
	return -ENOMEM;
}

/* VFS operation: link (hard link) */
static int tiny_fs_link(struct dentry *src_dentry, struct inode *dir, struct dentry *dst_dentry) {
	struct inode *inode = d_inode(src_dentry);
	struct tiny_fs_object *new_fs_object;
	struct tiny_fs_node *fs_node;
	struct super_block *sb = dir ? dir->i_sb : NULL;
	struct tiny_fs_sb_info *sbi = sb ? SB_FS_INFO(sb) : NULL;

	pr_info("tinyfs: link '%s' (ino=%lu) to '%s' in dir ino=%lu\n", 
		 src_dentry->d_name.name, inode ? inode->i_ino : 0, dst_dentry->d_name.name, dir->i_ino);

	if(!sbi || !inode)
		return -ENOENT;

	if (strlen(dst_dentry->d_name.name) > TINY_FS_MAX_NAME)
		return -ENAMETOOLONG;

	/* Hard links are only allowed for regular files */
	if (!S_ISREG(inode->i_mode)) {
		pr_err("tinyfs: hard links not supported for non-regular files\n");
		return -EPERM;
	}

	/* Find the original file system inode */
	fs_node = tiny_fs_find_node_by_ino(sbi, inode->i_ino);
	if (!fs_node) {
		pr_err("tinyfs: link failed - original inode %lu not found\n", inode->i_ino);
		return -ENOENT;
	}

	/* Create new directory entry pointing to the same inode */
	new_fs_object = tiny_fs_create_object(sbi, dst_dentry->d_name.name, fs_node, dir->i_ino);
	if (!new_fs_object)
		return -ENOMEM;

	/* Update directory timestamp */
	inode_update_timestamps(dir, TINY_FS_TIME_MOD);

	/* Increment link count */
	inc_nlink(inode);

	/* Associate the new dentry with the existing inode */
	ihold(inode);  /* Increment inode reference count */
	d_instantiate(dst_dentry, inode);

	return 0;
}

/* VFS operation: unlink */
static int tiny_fs_unlink(struct inode *dir, struct dentry *dentry) {
	struct tiny_fs_object *fs_object;
	struct inode *inode = d_inode(dentry);
	struct tiny_fs_sb_info *sbi = inode ? SB_FS_INFO(inode->i_sb) : NULL;
	int ret = 0;

	if (!sbi)
		return -ENOENT;

	mutex_lock(&sbi->lock);

	fs_object = tiny_fs_find_object_by_name_unsafe(dir, dentry->d_name.name);
	if (!fs_object){
		ret = -ENOENT;
		goto ERR;
	}

	uint64_t ino = inode->i_ino;
	if (S_ISDIR(inode->i_mode)) {
		struct tiny_fs_object *obj;
		list_for_each_entry(obj, &sbi->obj_list, list)
		if (obj->parent_ino == ino){
			ret = -ENOTEMPTY;
			goto ERR;
		}
	}

	pr_info("tinyfs: unlink '%s' (ino=%llu, nlink=%u)\n", dentry->d_name.name, ino, inode->i_nlink);
	pr_debug("tiny_fs_unlink: fs_node = %p\n", fs_object->node);

	tiny_fs_remove_object_unsafe(sbi, fs_object);

	drop_nlink(inode);
	inode_update_timestamps(dir, TINY_FS_TIME_MOD);
	mark_inode_dirty(inode);

ERR:
	mutex_unlock(&sbi->lock);
	return ret;
}

/* VFS operation: mkdir */
static struct dentry *tiny_fs_mkdir(struct mnt_idmap *idmap, struct inode *dir, struct dentry *dentry, umode_t mode) {
	struct tiny_fs_object *fs_object;
	struct tiny_fs_node *fs_node;
	struct inode *inode;
	struct super_block *sb = dir->i_sb;
	struct tiny_fs_sb_info *sbi = SB_FS_INFO(sb);

	kuid_t uid = current_fsuid();
	kgid_t gid = current_fsgid();

	pr_info("tinyfs: mkdir '%s' in ino=%lu (uid=%u, gid=%u)\n",
		 dentry->d_name.name, dir->i_ino, from_kuid(&init_user_ns, uid), from_kgid(&init_user_ns, gid));

	if(!sbi) return ERR_PTR(-ENOMEM);

	if (strlen(dentry->d_name.name) > TINY_FS_MAX_NAME)
		return ERR_PTR(-ENAMETOOLONG);

	inode = new_inode(sb);
	if (!inode)
		return ERR_PTR(-ENOMEM);

	fs_node   = tiny_fs_create_node(sbi, S_IFDIR | mode, uid, gid);
	if (!fs_node)   goto ERR1;
	fs_object = tiny_fs_create_object(sbi, dentry->d_name.name, fs_node, dir->i_ino);
	if (!fs_object) goto ERR2;

	inode->i_ino  = fs_object->node->ino;
	inode->i_mode = S_IFDIR | mode;
	inode->i_uid  = uid;
	inode->i_gid  = gid;
	inode->i_op   = &tiny_fs_inode_ops;
	inode->i_fop  = &simple_dir_operations;
	inode_update_timestamps(inode, TINY_FS_TIME_ALL);
	set_nlink(inode, 2);

	inc_nlink(dir);
	d_instantiate(dentry, inode);

	return NULL;

ERR2:
	mutex_lock(&sbi->lock);
	list_del(&fs_node->list);
	mutex_unlock(&sbi->lock);
	kfree(fs_node);
ERR1:
	iput(inode);
	return ERR_PTR(-ENOMEM);
}

/* VFS operation: rmdir */
static int tiny_fs_rmdir(struct inode *dir, struct dentry *dentry) {
	struct inode *inode = d_inode(dentry);

	pr_info("tinyfs: rmdir '%s'\n", dentry->d_name.name);

	if (!inode)
		return -ENOENT;

	drop_nlink(dir);
	drop_nlink(inode);

	return tiny_fs_unlink(dir, dentry);
}

static int tiny_fs_rename(struct mnt_idmap *idmap,
                          struct inode *src_dir, struct dentry *src_dentry,
                          struct inode *dst_dir, struct dentry *dst_dentry,
                          unsigned int flags) {
	struct tiny_fs_object *fs_object;
	struct inode *src_inode = d_inode(src_dentry);
	struct inode *dst_inode = d_inode(dst_dentry);
	struct tiny_fs_sb_info *sbi = SB_FS_INFO(src_dir->i_sb);
	int ret = 0;

	pr_info("tinyfs: rename '%s' (ino=%lu, parent=%lu) to '%s' (parent=%lu)\n", 
		 src_dentry->d_name.name, src_inode ? src_inode->i_ino : 0, src_dir->i_ino, dst_dentry->d_name.name, dst_dir->i_ino);

	if(!sbi) return -ENOENT;

	if (strlen(dst_dentry->d_name.name) > TINY_FS_MAX_NAME)
		return -ENAMETOOLONG;

	/* Don't support RENAME_EXCHANGE or RENAME_WHITEOUT */
	if (flags & ~RENAME_NOREPLACE)
		return -EINVAL;

	if (!src_inode)
		return -ENOENT;

	mutex_lock(&sbi->lock);

	/* Find the file system inode */
	fs_object = tiny_fs_find_object_by_name_unsafe(src_dir, src_dentry->d_name.name);
	if (!fs_object) {
		pr_err("tinyfs: rename failed - inode %lu not found\n", src_inode->i_ino);
		ret = -ENOENT;
		goto ERR;
	}

	/* If target exists and RENAME_NOREPLACE is set, fail */
	if ((flags & RENAME_NOREPLACE) && dst_inode){
		ret = -EEXIST;
		goto ERR;
	}

	/* If target exists, remove it first */
	if (dst_inode) {
		struct tiny_fs_object *target_object = tiny_fs_find_object_by_name_unsafe(dst_dir, dst_dentry->d_name.name);
		if (!target_object){
			ret = -EEXIST;
			goto ERR;
		}

		/* Check if target is a directory and not empty */
		if (S_ISDIR(dst_inode->i_mode)) {
			struct tiny_fs_object *child;
			list_for_each_entry(child, &sbi->obj_list, list)
			if (child->parent_ino == dst_inode->i_ino) {
				ret = -ENOTEMPTY;
				goto ERR;
			}
		}

		pr_debug("tiny_fs_rename: unlink exist inode (ino=%lu, nlink=%u) before rename\n", dst_inode->i_ino, dst_inode->i_nlink);

		/* Remove target inode */
		tiny_fs_remove_object_unsafe(sbi, target_object);

		drop_nlink(dst_inode);
		mark_inode_dirty(dst_inode);
	}

	fs_object->name[0] = '\0';
	strncat(fs_object->name, dst_dentry->d_name.name, TINY_FS_MAX_NAME);
	fs_object->parent_ino = dst_dir->i_ino;

	/* Update timestamps */
	inode_update_timestamps(src_dir, TINY_FS_TIME_MOD);
	inode_update_timestamps(dst_dir, TINY_FS_TIME_MOD);

ERR:
	mutex_unlock(&sbi->lock);
	return ret;
}

static const struct inode_operations tiny_fs_inode_ops = {
	.lookup = tiny_fs_lookup,
	.create = tiny_fs_create,
	.link   = tiny_fs_link,
	.unlink = tiny_fs_unlink,
	.mkdir  = tiny_fs_mkdir,
	.rmdir  = tiny_fs_rmdir,
	.rename = tiny_fs_rename,
};

/* File operations: read */
static ssize_t tiny_fs_file_read(struct file *filp, char __user *buf, size_t len, loff_t *ppos) {
	struct inode *inode = file_inode(filp);
	struct tiny_fs_node *fs_node;
	struct tiny_fs_sb_info *sbi = SB_FS_INFO(inode->i_sb);
	ssize_t ret = 0;

	pr_info("tinyfs: read ino=%lu, len=%zu, pos=%lld\n", inode->i_ino, len, *ppos);

	if(!sbi)
		return -ENOENT;
	if (*ppos < 0)
		return -EINVAL;

	fs_node = tiny_fs_find_node_by_ino(sbi, inode->i_ino);
	if (!fs_node) {
		ret = -ENOENT;
		goto ERR;
	}

	mutex_lock(&sbi->lock);
	size_t filesize = fs_node->size;

	if (*ppos >= filesize)
		goto ERR;

	len = min_t(size_t, len, filesize - *ppos);
	if (copy_to_user(buf, fs_node->data + *ppos, len)) {
		ret = -EFAULT;
		goto ERR;
	}
	*ppos += len;

	ret = len;
ERR:
	mutex_unlock(&sbi->lock);
	pr_debug("tiny_fs_file_read: read end ret=%ld\n", ret);
	return ret;
}

/* File operations: write */
static ssize_t tiny_fs_file_write(struct file *filp, const char __user *buf, size_t len, loff_t *ppos) {
	struct inode *inode = file_inode(filp);
	struct tiny_fs_node *fs_node;
	struct tiny_fs_sb_info *sbi = SB_FS_INFO(inode->i_sb);
	ssize_t ret = 0;

	pr_info("tinyfs: write ino=%lu, len=%zu, pos=%lld\n", inode->i_ino, len, *ppos);

	if(!sbi)
		return -ENOENT;
	if (*ppos < 0)
		return -EINVAL;

	fs_node = tiny_fs_find_node_by_ino(sbi, inode->i_ino);
	if (!fs_node) {
		ret = -ENOENT;
		goto ERR;
	}

	if (*ppos >= TINY_FS_BLOCKSIZE) {
		ret = -ENOMEM;
		goto ERR;
	}

	len = min_t(size_t, len, TINY_FS_BLOCKSIZE - *ppos);
	if (copy_from_user(fs_node->data + *ppos, buf, len)) {
		ret = -EFAULT;
		goto ERR;
	}
	*ppos += len;

	mutex_lock(&sbi->lock);
	if(*ppos > fs_node->size)
		fs_node->size = *ppos;
	inode->i_size = fs_node->size;
	mutex_unlock(&sbi->lock);

	inode_update_timestamps(inode, TINY_FS_TIME_MOD);
	ret = len;

ERR:
	pr_debug("tiny_fs_file_write: write end ret=%ld\n", ret);
	return ret;
}

static const struct file_operations tiny_fs_file_ops = {
	.read   = tiny_fs_file_read,
	.write  = tiny_fs_file_write,
	.llseek = generic_file_llseek,
};

/* Superblock operations */
static void tiny_fs_evict_inode(struct inode *inode) {
	pr_info("tinyfs: evict_inode called for ino=%lu\n", inode->i_ino);

	truncate_inode_pages_final(&inode->i_data);
	clear_inode(inode);
}

/* Superblock operations */
static void tiny_fs_put_super(struct super_block *sb) {
	struct tiny_fs_object *fs_object, *tmp;
	struct tiny_fs_sb_info *sbi = SB_FS_INFO(sb);

	pr_info("tinyfs: put_super called\n");

	if (!sbi) return;

	/* Delete all files */
	mutex_lock(&sbi->lock);
	list_for_each_entry_safe(fs_object, tmp, &sbi->obj_list, list) {
		pr_debug("tiny_fs_put_super: freeing fs_object '%s' (ino=%llu)\n", fs_object->name, fs_object->node->ino);
		tiny_fs_remove_object_unsafe(sbi, fs_object);
	}
	mutex_unlock(&sbi->lock);

	kfree(sbi);
	sb->s_fs_info = NULL;
}

static const struct super_operations tiny_fs_super_ops = {
	.statfs      = simple_statfs,
	.drop_inode  = generic_drop_inode,
	.evict_inode = tiny_fs_evict_inode,
	.put_super   = tiny_fs_put_super,
};

/* Fill superblock */
static int tiny_fs_fill_super(struct super_block *sb, void *data, int silent) {
	struct inode *root_inode;
	struct tiny_fs_object *root_fs_object;
	struct tiny_fs_node *root_fs_node;
	struct tiny_fs_sb_info *sbi;

	kuid_t uid = current_fsuid();
	kgid_t gid = current_fsgid();

	pr_info("tinyfs: mounting filesystem (uid=%u, gid=%u)\n",
		 from_kuid(&init_user_ns, uid), from_kgid(&init_user_ns, gid));

	/* Allocate per-superblock info */
	sbi = kzalloc(sizeof(struct tiny_fs_sb_info), GFP_KERNEL);
	if (!sbi)
		return -ENOMEM;

	INIT_LIST_HEAD(&sbi->obj_list);
	INIT_LIST_HEAD(&sbi->node_list);
	mutex_init(&sbi->lock);

	sb->s_magic          = TINY_FS_MAGIC;
	sb->s_op             = &tiny_fs_super_ops;
	sb->s_blocksize      = TINY_FS_BLOCKSIZE;
	sb->s_blocksize_bits = 12;
	sb->s_maxbytes       = MAX_LFS_FILESIZE;
	sb->s_fs_info        = sbi;

	/* Create root directory */
	atomic64_set(&sbi->next_ino, 0);  // 1 is reserved for root directory
	root_fs_node   = tiny_fs_create_node(sbi, S_IFDIR | 0755, uid, gid);
	if (!root_fs_node)   goto ERR1;
	root_fs_object = tiny_fs_create_object(sbi, "/", root_fs_node, 1);
	if (!root_fs_object) goto ERR2;

	root_inode = new_inode(sb);
	if (!root_inode) goto ERR3;

	root_inode->i_ino  = root_fs_object->node->ino; // must be 1
	root_inode->i_mode = S_IFDIR | 0777;
	root_inode->i_uid  = uid;
	root_inode->i_gid  = gid;
	root_inode->i_op   = &tiny_fs_inode_ops;
	root_inode->i_fop  = &simple_dir_operations;
	inode_update_timestamps(root_inode, TINY_FS_TIME_ALL);
	set_nlink(root_inode, 2);

	sb->s_root = d_make_root(root_inode);
	if (!sb->s_root){
		iput(root_inode);
		goto ERR3;
	}

	return 0;

ERR3:
	mutex_lock(&sbi->lock);
	list_del(&root_fs_object->list);
	mutex_unlock(&sbi->lock);
	kfree(root_fs_object);
ERR2:
	mutex_lock(&sbi->lock);
	list_del(&root_fs_node->list);
	mutex_unlock(&sbi->lock);
	kfree(root_fs_node);
ERR1:
	kfree(sbi);
	sb->s_fs_info = NULL;
	return -ENOMEM;
}

/* Mount filesystem */
static struct dentry *tiny_fs_mount(struct file_system_type *fs_type, int flags, const char *dev_name, void *data) {
	return mount_nodev(fs_type, flags, data, tiny_fs_fill_super);
}

/* Kill superblock */
static void tiny_fs_kill_sb(struct super_block *sb) {
	pr_info("tinyfs: unmounting filesystem\n");

	shrink_dcache_sb(sb);
	kill_litter_super(sb);
}

static struct file_system_type tiny_fs_type = {
	.owner    = THIS_MODULE,
	.name     = "tinyfs",
	.mount    = tiny_fs_mount,
	.kill_sb  = tiny_fs_kill_sb,
	.fs_flags = FS_USERNS_MOUNT,
};

/* Module initialization */
static int __init tiny_fs_init(void) {
	int ret;

	ret = register_filesystem(&tiny_fs_type);
	if (ret) {
		pr_err("tinyfs: failed to register filesystem (error %d)\n", ret);
		return ret;
	}

	pr_info("tinyfs: filesystem registered\n"
		 "tinyfs: kernel version %d.%d.%d\n",
		 LINUX_VERSION_CODE >> 16, (LINUX_VERSION_CODE >> 8) & 0xff, LINUX_VERSION_CODE & 0xff);

	return 0;
}

/* Module cleanup */
static void __exit tiny_fs_exit(void) {
	int ret;

	ret = unregister_filesystem(&tiny_fs_type);
	if (ret){
		pr_err("tinyfs: failed to unregister filesystem (error %d)\n", ret);
		return;
	}

	pr_info("tinyfs: filesystem unregistered\n");
}

module_init(tiny_fs_init);
module_exit(tiny_fs_exit); 
