#!/bin/bash

# `-serial stdio` is used on remote
qemu-system-x86_64 \
          -m 128M \
          -cpu kvm64,+smap,+smep \
          -smp 1 cores=1,threads=1\
          -net none \
          -serial mon:stdio \
          -display none \
          -monitor none \
          -vga none \
          -kernel bzImage \
          -initrd initramfs.cpio.gz \
          -append "console=ttyS0 kaslr kpti=1 quiet panic=0 root=/dev/sda rw" \
          2>&1
