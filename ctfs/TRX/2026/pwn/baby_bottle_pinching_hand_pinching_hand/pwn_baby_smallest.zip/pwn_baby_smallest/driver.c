#include <linux/miscdevice.h>

#define TOP_OF_STACK 0x2c658 			// https://elixir.bootlin.com/linux/v6.14.10/source/arch/x86/include/asm/current.h#L24

static long dev_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
	asm volatile (
		".intel_syntax noprefix\n"
		"mov qword ptr gs:%0, rdx\n"
		".att_syntax prefix\n"
		:
		: "m" (*(const void **)TOP_OF_STACK)
		: "rdx"
	);
	return 0;
}

static int dev_open(struct inode *inode, struct file *file) {
	file->private_data = NULL;
	return 0;
}

static int dev_release(struct inode *inode, struct file *file) {
	return 0;
}

static struct file_operations chall_fops = {
	.open = dev_open,
	.release = dev_release,
    .unlocked_ioctl = dev_ioctl
};

struct miscdevice chall_dev = {
    .minor = MISC_DYNAMIC_MINOR,
    .name = "stack",
    .fops = &chall_fops,
};

static int __init init_dev(void) {
    if (misc_register(&chall_dev) < 0) {
        printk(KERN_INFO "[CHALL] [ERR] Failed to register device\n");
		return -1;
	}

	return 0;
}

static void __exit exit_dev(void) {
	misc_deregister(&chall_dev);
}

module_init(init_dev);
module_exit(exit_dev);

MODULE_AUTHOR("leave");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("TRXCTF 2026");
