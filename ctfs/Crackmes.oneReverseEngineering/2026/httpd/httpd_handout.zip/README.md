This file was found on an infected host. Can you figure out what it does?
