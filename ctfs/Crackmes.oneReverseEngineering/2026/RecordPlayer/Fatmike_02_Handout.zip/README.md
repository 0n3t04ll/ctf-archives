# Description

Something’s wrong with this record player - the music doesn’t sound quite right.  
Your mission is to fix it. Don’t worry though, the technology here is pretty simple.  

**Right below the PLAY button**, you’ll find two switches:  

- One controls the direction the record spins  
- The other keeps the pitch steady  

Chances are, both of these switches are broken.  

Good luck!  

Fatmike  

# Supported OS

Tested on Windows 10.  

# Architecture

x86-64  

# Language

C/C++  