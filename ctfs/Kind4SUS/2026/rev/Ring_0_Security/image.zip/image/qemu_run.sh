#!/bin/sh

qemu-system-x86_64 \
    -m 128M \
    -kernel bzImage \
    -initrd initramfs.cpio.gz \
    -nographic \
    -monitor /dev/null \
    -append "console=ttyS0 quiet loglevel=3 oops=panic panic=-1" \
    -no-reboot \
    -cpu qemu64,+smep,+smap
