package db

import (
	"context"
	"fmt"
	"trading/config"
	"trading/ent"

	_ "github.com/go-sql-driver/mysql"
	_ "github.com/lib/pq"

	"entgo.io/ent/dialect"
	"github.com/sirupsen/logrus"
)

var Connection *ent.Client

func ConnectToDb() (*ent.Client, error) {
	logrus.Info("Connecting to database")
	var err error
	if config.Config.Database.Type == "mysql" {
		Connection, err = ent.Open(dialect.MySQL, fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?parseTime=True", config.Config.Database.User, config.Config.Database.Password, config.Config.Database.Host, config.Config.Database.Port, config.Config.Database.Database))
	} else {
		Connection, err = ent.Open(dialect.Postgres, fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s", config.Config.Database.Host, config.Config.Database.Port, config.Config.Database.User, config.Config.Database.Password, config.Config.Database.Database))
	}

	if err != nil {
		logrus.Error(err)
		return nil, err
	}

	if err := Connection.Schema.Create(context.Background()); err != nil {
		logrus.Error(err)
		return nil, err
	}

	logrus.Info("Successfully connected to database")
	return Connection, nil
}
