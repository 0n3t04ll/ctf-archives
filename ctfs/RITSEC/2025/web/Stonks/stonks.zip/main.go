package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"net/http"
	"sort"
	"strings"
	"sync"
	"time"
	"trading/config"
	"trading/db"
	"trading/ent"
	"trading/ent/user"

	log "github.com/sirupsen/logrus"
	"golang.org/x/crypto/argon2"
)

type APIHandler struct{}
type LoginHandler struct{}
type RegisterHandler struct{}

type OwnedSymbol struct {
	Name string `json:"name"`
	Qty  int    `json:"qty"`
}

type User struct {
	Username     string        `json:"username"`
	ID           int           `json:"id"`
	Portfolio    []OwnedSymbol `json:"portfolio"`
	Money        float64       `json:"money"`
	TotalValue   float64       `json:"total_value"`
	Mutex        sync.Mutex    `json:"-"`
	LastRequest  time.Time     `json:"-"`
	SessionToken string        `json:"-"`
	DBObj        *ent.User     `json:"-"`
}

type Symbol struct {
	Name        string  `json:"name"`
	Description string  `json:"description"`
	Price       float64 `json:"price"`
}

type Login struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type Transaction struct {
	Symbol string `json:"symbol"`
}

type params struct {
	memory      uint32
	iterations  uint32
	parallelism uint8
	keyLength   uint32
}

type ScoreboardUser struct {
	Username       string  `json:"username"`
	LiquidAssets   float64 `json:"liquid_assets"`
	PortfolioValue float64 `json:"portfolio_value"`
}

var Market []Symbol
var MarketLock sync.Mutex

var Users map[string]*User
var UsersLock sync.Mutex

type ErrorResponse struct {
	Error string `json:"error"`
}

type Response struct {
	Message string `json:"message"`
}

var letterRunes = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

func RandStringRunes(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.Intn(len(letterRunes))]
	}
	return string(b)
}

func enableCors(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Credentials", "true")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS")
}

func respondWithError(w http.ResponseWriter, err error) {
	w.WriteHeader(http.StatusBadRequest)
	w.Header().Set("Content-Type", "application/json")
	enableCors(w)
	json.NewEncoder(w).Encode(ErrorResponse{
		Error: err.Error(),
	})
}

func createMarket() {
	MarketLock.Lock()
	defer MarketLock.Unlock()

	for _, company := range config.Config.Companies {
		Market = append(Market, Symbol{
			Name:        company.Name,
			Description: company.Description,
			Price:       company.BasePrice,
		})
	}
}

func updateMarket() {
	for {
		MarketLock.Lock()
		for i := range Market {
			symbol := &Market[i]
			if symbol.Price > 5 {
				symbol.Price += (rand.Float64() - 0.5) / 10
			} else {
				symbol.Price += (rand.Float64()) / 10
			}
			symbol.Price = math.Round(float64(symbol.Price)*100) / 100
		}
		MarketLock.Unlock()
		time.Sleep(time.Second * 2)
	}
}

func getSymbol(name string) (*Symbol, error) {
	MarketLock.Lock()
	defer MarketLock.Unlock()
	for i := range Market {
		symbol := &Market[i]
		if symbol.Name == name {
			return symbol, nil
		}
	}
	return nil, fmt.Errorf("no symbol named \"%s\"", name)
}

func (u *User) getUserInfo(w http.ResponseWriter) {
	u.Mutex.Lock()
	defer u.Mutex.Unlock()
	json.NewEncoder(w).Encode(u)
}

func hashPassword(password string) string {
	p := &params{
		memory:      64 * 1024,
		iterations:  3,
		parallelism: 2,
		keyLength:   32,
	}
	salt := []byte("meowmeowmeowmeow")
	hash := argon2.IDKey([]byte(password), salt, p.iterations, p.memory, p.parallelism, p.keyLength)
	b64Salt := base64.RawStdEncoding.EncodeToString(salt)
	b64Hash := base64.RawStdEncoding.EncodeToString(hash)
	encodedHash := fmt.Sprintf("$argon2id$v=%d$m=%d,t=%d,p=%d$%s$%s", argon2.Version, p.memory, p.iterations, p.parallelism, b64Salt, b64Hash)
	return encodedHash
}

func makeUser(username, password string) (*ent.User, error) {
	check, err := db.Connection.User.Query().Where(user.Name(username)).All(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed creating user: %w", err)
	}
	if len(check) > 0 {
		return nil, fmt.Errorf("user with that name already exists")
	}
	u, err := db.Connection.User.Create().
		SetName(username).
		SetPassword(hashPassword(password)).
		SetPortfolio("[]").
		SetMoney(500.0).
		Save(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed creating user: %w", err)
	}
	return u, nil
}

func dbGetUser(username, password string) (*ent.User, error) {
	u, err := db.Connection.User.Query().Where(user.Name(username), user.Password(hashPassword(password))).First(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed querying user: %w", err)
	}
	return u, nil
}

func (u *User) getOwnedShares(symbol *Symbol) int {
	u.Mutex.Lock()
	defer u.Mutex.Unlock()

	for i := range u.Portfolio {
		sym := &u.Portfolio[i]
		if sym.Name == symbol.Name {
			return sym.Qty
		}
	}

	return 0
}

func (u *User) updateUser() error {
	u.Mutex.Lock()
	defer u.Mutex.Unlock()
	value, err := calcValueOfPortfolio(u.Portfolio)
	if err != nil {
		return err
	}
	u.TotalValue = math.Round(float64(value)*100) / 100
	u.Money = math.Round(float64(u.Money)*100) / 100
	jsonBytes, _ := json.MarshalIndent(u.Portfolio, "", " ")
	u.DBObj.Update().SetPortfolio(string(jsonBytes)).SetMoney(u.Money).Save(context.Background())
	return nil
}

func (u *User) addToPortfolio(symbol *Symbol) {
	u.Mutex.Lock()
	defer u.Mutex.Unlock()

	found := false
	for i := range u.Portfolio {
		sym := &u.Portfolio[i]
		if sym.Name == symbol.Name {
			sym.Qty += 1
			found = true
			break
		}
	}
	if !found {
		u.Portfolio = append(u.Portfolio, OwnedSymbol{
			Name: symbol.Name,
			Qty:  1,
		})
	}

	u.Money -= symbol.Price
}

func (u *User) removeFromPortfolio(symbol *Symbol) error {
	if u.Mutex.TryLock() {
		found := false
		for i := range u.Portfolio {
			sym := &u.Portfolio[i]
			if sym.Name == symbol.Name {
				if sym.Qty < 1 {
					u.Mutex.Unlock()
					return fmt.Errorf("you dont own enough of this stock")
				}
				sym.Qty -= 1
				found = true
				break
			}
		}
		if !found {
			u.Mutex.Unlock()
			return fmt.Errorf("stock not found in portfolio")
		}
		u.Mutex.Unlock()
	}
	u.Money += symbol.Price
	return nil
}

func (u *User) buyStock(stock string) error {
	symbol, err := getSymbol(stock)
	if err != nil {
		return err
	}
	u.Mutex.Lock()
	if u.Money < symbol.Price {
		u.Mutex.Unlock()
		return fmt.Errorf("insufficient funds")
	}
	u.Mutex.Unlock()

	u.addToPortfolio(symbol)
	u.updateUser()
	return nil
}

func (u *User) sellStock(stock string) error {
	symbol, err := getSymbol(stock)
	if err != nil {
		return err
	}
	err = u.removeFromPortfolio(symbol)
	if err != nil {
		return err
	}
	u.updateUser()
	return nil
}

func (u *User) getFlag(w http.ResponseWriter) error {
	flagSymbol, err := getSymbol("$FLAG")
	if err != nil {
		return err
	}
	numShares := u.getOwnedShares(flagSymbol)
	if numShares < 10 {
		return fmt.Errorf("you need to own at least 10 shares of $FLAG for that")
	}

	json.NewEncoder(w).Encode(Response{
		Message: config.Config.Settings.Flag,
	})

	return nil
}

func getScoreboard(w http.ResponseWriter) error {
	UsersLock.Lock()
	defer UsersLock.Unlock()

	var scoreboard []ScoreboardUser
	scoreboard = make([]ScoreboardUser, 0)

	for i := range Users {
		u := Users[i]
		u.updateUser()
		value, err := calcValueOfPortfolio(u.Portfolio)
		if err != nil {
			continue
		}
		var name string
		if len(u.Username) < 20 {
			name = u.Username
		} else {
			name = u.Username[:20]
		}
		scoreboard = append(scoreboard, ScoreboardUser{
			Username:       name,
			LiquidAssets:   u.Money,
			PortfolioValue: value,
		})
	}

	sort.Slice(scoreboard, func(i, j int) bool {
		return scoreboard[i].LiquidAssets+scoreboard[i].PortfolioValue > scoreboard[j].LiquidAssets+scoreboard[j].PortfolioValue
	})

	json.NewEncoder(w).Encode(scoreboard)
	return nil
}

func (api *APIHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	enableCors(w)

	sessionCookie, err := r.Cookie("session")
	if err != nil {
		respondWithError(w, err)
		return
	}
	UsersLock.Lock()
	user, ok := Users[sessionCookie.Value]
	UsersLock.Unlock()

	if !ok {
		respondWithError(w, fmt.Errorf("invalid session"))
		return
	}

	if time.Since(user.LastRequest) < 1*time.Second {
		respondWithError(w, fmt.Errorf("slow down"))
		return
	}
	user.LastRequest = time.Now()

	path := r.URL.Path
	if strings.HasPrefix(path, "/api/me") {
		user.updateUser()
		user.getUserInfo(w)
	} else if strings.HasPrefix(path, "/api/scoreboard") {
		err := getScoreboard(w)
		if err != nil {
			respondWithError(w, err)
			return
		}
	} else if strings.HasPrefix(path, "/api/market") {
		json.NewEncoder(w).Encode(Market)
		return
	} else if strings.HasPrefix(path, "/api/buy") {
		var transaction Transaction
		err := json.NewDecoder(r.Body).Decode(&transaction)
		if err != nil {
			respondWithError(w, err)
			return
		}
		err = user.buyStock(transaction.Symbol)
		if err != nil {
			respondWithError(w, err)
			return
		}
		json.NewEncoder(w).Encode(Response{
			Message: "success",
		})
		return
	} else if strings.HasPrefix(path, "/api/sell") {
		var transaction Transaction
		err := json.NewDecoder(r.Body).Decode(&transaction)
		if err != nil {
			respondWithError(w, err)
			return
		}
		err = user.sellStock(transaction.Symbol)
		if err != nil {
			respondWithError(w, err)
			return
		}
		json.NewEncoder(w).Encode(Response{
			Message: "success",
		})
	} else if strings.HasPrefix(path, "/api/flag") {
		err := user.getFlag(w)
		if err != nil {
			respondWithError(w, err)
			return
		}
	}
	if !ok {
		respondWithError(w, fmt.Errorf("not found"))
	}
}

func calcValueOfPortfolio(symbols []OwnedSymbol) (float64, error) {
	totalValue := 0.0
	for _, sym := range symbols {
		s, err := getSymbol(sym.Name)
		if err != nil {
			return 0, err
		}
		totalValue += s.Price * float64(sym.Qty)
	}
	return math.Round(float64(totalValue)*100) / 100, nil
}

func getOrCreateUser(u *ent.User) (*User, error) {
	UsersLock.Lock()
	defer UsersLock.Unlock()
	for _, user := range Users {
		if user.ID == u.ID {
			return user, nil
		}
	}
	newSessionToken := RandStringRunes(64)

	var ownedSymbols []OwnedSymbol
	err := json.Unmarshal([]byte(u.Portfolio), &ownedSymbols)
	if err != nil {
		return nil, err
	}
	value, err := calcValueOfPortfolio(ownedSymbols)
	if err != nil {
		return nil, err
	}
	newUser := &User{
		Username:     u.Name,
		ID:           u.ID,
		Portfolio:    ownedSymbols,
		TotalValue:   value,
		SessionToken: newSessionToken,
		Money:        u.Money,
		DBObj:        u,
	}
	Users[newSessionToken] = newUser
	return newUser, nil
}

func loadAllUsers() {
	u, err := db.Connection.User.Query().All(context.Background())
	if err != nil {
		log.Error(err)
		return
	}
	for _, user := range u {
		_, err = getOrCreateUser(user)
		if err != nil {
			log.Error(err)
		}
	}
}

func (api *LoginHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	var login Login
	err := json.NewDecoder(r.Body).Decode(&login)
	if err != nil {
		respondWithError(w, err)
		return
	}
	u, err := dbGetUser(login.Username, login.Password)
	if err != nil {
		respondWithError(w, err)
		return
	}
	user, err := getOrCreateUser(u)
	if err != nil {
		respondWithError(w, err)
		return
	}
	http.SetCookie(w, &http.Cookie{
		Name:     "session",
		Value:    user.SessionToken,
		HttpOnly: true,
		Path:     "/",
	})
}

func (api *RegisterHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	var login Login
	err := json.NewDecoder(r.Body).Decode(&login)
	if err != nil {
		respondWithError(w, err)
		return
	}
	if len(login.Username) < 4 || len(login.Password) < 4 {
		respondWithError(w, fmt.Errorf("username or password too short"))
		return
	}
	_, err = makeUser(login.Username, login.Password)
	if err != nil {
		respondWithError(w, err)
		return
	}
	w.WriteHeader(http.StatusCreated)
}

func main() {
	config.ReadConfig()
	createMarket()
	db.ConnectToDb()
	go updateMarket()

	Users = make(map[string]*User)

	apiHandler := APIHandler{}
	loginHandler := LoginHandler{}
	registerHandler := RegisterHandler{}

	loadAllUsers()

	http.Handle("/api/", &apiHandler)
	http.Handle("/login", &loginHandler)
	http.Handle("/register", &registerHandler)

	log.Fatal(http.ListenAndServe("0.0.0.0:"+fmt.Sprint(config.Config.Settings.HttpPort), nil))
}
