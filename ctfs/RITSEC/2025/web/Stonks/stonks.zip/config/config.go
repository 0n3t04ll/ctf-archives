package config

type configDefinition struct {
	Settings  settings
	Database  database
	Companies []company `toml:"company"`
}

type company struct {
	Name        string  `toml:"name"`
	Description string  `toml:"description"`
	BasePrice   float64 `toml:"price"`
}

type settings struct {
	HttpPort int    `toml:"http_port"`
	Flag     string `toml:"flag"`
}

type database struct {
	Type     string `toml:"type"`
	Host     string `toml:"host"`
	Port     int    `toml:"port"`
	User     string `toml:"user"`
	Password string `toml:"password"`
	Database string `toml:"database"`
}

var Config = configDefinition{
	Settings: settings{
		HttpPort: 3621,
	},
	Database: database{},
}
