# create databases
# Give the user dbuser all privileges on the databases

CREATE DATABASE IF NOT EXISTS `challenge`;
GRANT ALL ON `challenge`.* TO 'dbuser'@'%';