You need to provide a statically linked ELF file that interacts with chall, where stdin is the output of chall and stdout is the input to chall. Exploit the vulnerability in chall to execute /pwned, and you will win this round. You need to win a total of 30 rounds to obtain the final flag.
time limit/cooldown: 240s
allowed syscalls: read,write,nanosleep,exit
ELF size limit: 96K
