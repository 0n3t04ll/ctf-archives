#!/bin/bash
echo $FLAG > /flag
export FLAG=not_flag
FLAG=not_flag
cd /app
java -jar sofa-server.jar