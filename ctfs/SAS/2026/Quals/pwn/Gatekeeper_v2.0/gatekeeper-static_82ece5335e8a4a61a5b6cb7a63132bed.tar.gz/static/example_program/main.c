#include "ministd.h"
#include "trusted_lib_api.h"
#include <stdint.h>

#define MARK_X 1u
#define MARK_O 2u

static uint32_t square(uint32_t board, int s) { return (board >> (s * 2)) & 3u; }

static char glyph(uint32_t v)
{
    uint32_t is_x = (v == MARK_X);
    uint32_t is_o = (v == MARK_O);
    return (char)('.' + is_x * ('X' - '.') + is_o * ('O' - '.'));
}

static const uint8_t LINES[8][3] = {
    {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6},
    {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6},
};

static void draw(uint32_t board)
{
    for (int r = 0; r < 3; r++) {
        TRUSTED_CALL_VOID(mini_printf, "   %c | %c | %c\n", glyph(square(board, r * 3 + 0)),
                          glyph(square(board, r * 3 + 1)), glyph(square(board, r * 3 + 2)));
        if (r < 2) {
            TRUSTED_CALL_VOID(mini_printf, "  ---+---+---\n");
        }
    }
}

static char winner(uint32_t board)
{
    uint32_t x = 0, o = 0;
    for (int l = 0; l < 8; l++) {
        uint32_t a = square(board, LINES[l][0]);
        uint32_t b = square(board, LINES[l][1]);
        uint32_t c = square(board, LINES[l][2]);
        x |= (a == MARK_X) & (b == MARK_X) & (c == MARK_X);
        o |= (a == MARK_O) & (b == MARK_O) & (c == MARK_O);
    }
    uint32_t wx = x & 1u, wo = (o & ~x) & 1u;
    return (char)('-' + wx * ('X' - '-') + wo * ('O' - '-'));
}

static uint32_t g_board;
static uint32_t g_replay;
static uint32_t g_len = sizeof(uint32_t);

ENTRY_POINT_ATTR void start(void)
{
    TRUSTED_CALL_VOID(mini_printf, "\n  TIC-TAC-TOE\n");
    TRUSTED_CALL_VOID(mini_printf, "  submit a game as nine squares 0-8 (X and O alternate, X first)\n");
    TRUSTED_CALL_VOID(mini_printf, "  e.g.  012345678\n  > ");

    for (int i = 0; i < 9; i++) {
        uint32_t s = (uint32_t)(TRUSTED_CALL(readc) - '0') & 0xfu;
        uint32_t mark = (i & 1) ? MARK_O : MARK_X;
        uint32_t sh = s * 2;
        g_board = (g_board & ~(3u << sh)) | (mark << sh);
    }

    TRUSTED_CALL_VOID(mini_printf, "\n");
    draw(g_board);
    TRUSTED_CALL_VOID(mini_printf, "  winner: %c\n\n", winner(g_board));

    uint64_t token = TRUSTED_CALL(create_file_plain, (uint8_t *)&g_board, sizeof(g_board));
    char hex[17];
    u64_to_hex(token, hex, 16, 0);
    hex[16] = 0;
    TRUSTED_CALL_VOID(mini_printf, "  archived -- replay token 0x%s\n  replay:\n", hex);

    TRUSTED_CALL(read_file_plain, token, (uint8_t *)&g_replay, &g_len);
    draw(g_replay);

    TRUSTED_CALL_VOID(mini_printf, "\n  the flag is archived in the vault too -- find its token.\n\n");
    ENTRY_POINT_END();
}
