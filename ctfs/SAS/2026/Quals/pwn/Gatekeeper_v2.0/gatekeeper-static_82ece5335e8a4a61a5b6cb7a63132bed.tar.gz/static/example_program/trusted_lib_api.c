#include "trusted_lib_api.h"
#include <stdint.h>

__attribute__((noreturn, noinline)) void halt(void)
{
    __asm__ __volatile__("ebreak\n\tj .");
    __builtin_unreachable();
}

__attribute__((optimize("O0"), optnone, noipa, noinline)) uint32_t verifier_ranged_u32(uint32_t v,
                                                                                       uint32_t lo,
                                                                                       uint32_t hi)
{
    v ^= (v ^ lo) & (uint32_t) - (v < lo);
    v ^= (v ^ hi) & (uint32_t) - (v > hi);
    return v;
}