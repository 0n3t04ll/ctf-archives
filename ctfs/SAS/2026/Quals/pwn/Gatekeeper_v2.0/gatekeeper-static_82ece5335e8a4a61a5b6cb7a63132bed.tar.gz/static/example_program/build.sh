#!/usr/bin/env bash
# Build this RV64 program inside a Docker container (no local toolchain needed).
#
#   ./build.sh           -> build/example.bin
#   ./build.sh encode    -> base64 of the program image, ready to submit
#   ./build.sh disasm    -> disassemble the image
#   ./build.sh clean

set -euo pipefail

IMAGE="gatekeeper-progbuilder"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

docker build -q -t "$IMAGE" "$HERE" >/dev/null

exec docker run --rm \
    -u "$(id -u):$(id -g)" \
    -v "$HERE":/src \
    "$IMAGE" "$@"
