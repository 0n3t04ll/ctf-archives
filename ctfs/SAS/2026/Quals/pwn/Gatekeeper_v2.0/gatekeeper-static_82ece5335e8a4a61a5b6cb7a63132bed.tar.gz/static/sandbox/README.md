# Gatekeeper

`gatekeeper.py` runs the same pipeline as the live service: it statically verifies an RV64 program with the exact verifier the server uses, and on pass boots it on the custom QEMU machine. Use it to develop and test your programs without burning proof-of-work or network round-trips.

A dummy flag is planted fresh for every run in the same way the server plants the real one.

## Setup

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
```

## Usage

```bash
python gatekeeper.py path/to/program.bin
python gatekeeper.py prog.bin -v
python gatekeeper.py prog.bin --skip-run
```
