from typing import Final

from .address_space import SPACE

_CODE_BYTES: Final = SPACE.by_name("user-code").length
_DATA_BYTES: Final = SPACE.by_name("user-data").length


class Limits:
    # Largest accepted submission = the code window plus the data window.
    code_bytes: Final = _CODE_BYTES
    data_bytes: Final = _DATA_BYTES
    program_bytes: Final = _CODE_BYTES + _DATA_BYTES

    # Per-file ceiling enforced by the file shims.
    file_bytes: Final = 2 * 1024

    # Hard caps on the symbolic walk.
    step_budget: Final = 25000
    wall_clock_s: Final = 25

    # SMT ceilings.
    solver_ms: Final = 5000
    solver_bytes: Final = 1024 * 1024 * 1024

    # Largest element span a single symbolic load may range over.
    symbolic_window: Final = 0x100

    # A U-mode wrapper builds a stack frame below the caller's sp and leaves
    # residue there; the engine re-taints this many bytes below sp after each
    # trusted call so the guest cannot rely on anything it stored below sp across
    # the call.
    trusted_frame_window: Final = 0x200
