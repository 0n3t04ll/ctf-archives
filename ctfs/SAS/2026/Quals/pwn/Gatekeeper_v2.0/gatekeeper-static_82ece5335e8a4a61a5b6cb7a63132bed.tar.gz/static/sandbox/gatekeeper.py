#!/usr/bin/env python3

import argparse
import logging
import os
import secrets
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from verifier.engine import Verifier  # noqa: E402

DEFAULT_QEMU = os.environ.get("QEMU_BIN") or str(HERE / "qemu-system-riscv64")
DUMMY_FLAG = b"SAS{local_test_flag}"


def _flag_gk_bytes(flag: bytes) -> bytes:
    """Device file payload: "PLA\\0" signature + the flag padded to a word."""
    if len(flag) % 4:
        flag += b"\x00" * (4 - len(flag) % 4)  # device reads 4-byte words
    return b"PLA\x00" + flag


def run_qemu(qemu: str, program: bytes, flag: bytes, timeout: float | None) -> int:
    run_dir = tempfile.mkdtemp(prefix="gk-local-")
    try:
        files_dir = os.path.join(run_dir, "files")
        os.makedirs(files_dir)
        # filename: <16-hex private handle><16-hex public handle>.gk
        name = secrets.token_bytes(8).hex() + secrets.token_bytes(8).hex() + ".gk"
        with open(os.path.join(files_dir, name), "wb") as fh:
            fh.write(_flag_gk_bytes(flag))

        bios = os.path.join(run_dir, "program.bin")
        with open(bios, "wb") as fh:
            fh.write(program)

        cmd = [
            qemu,
            "-machine",
            "gatekeeper",
            "-bios",
            bios,
            "-display",
            "none",
            "-serial",
            "none",
            "-monitor",
            "none",
        ]
        env = {**os.environ, "GATEKEEPER_FILES": files_dir}
        try:
            return subprocess.call(cmd, env=env, timeout=timeout)
        except subprocess.TimeoutExpired:
            sys.stderr.write("\n[!] QEMU timed out\n")
            return 124
    finally:
        shutil.rmtree(run_dir, ignore_errors=True)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="verify an RV64 image and run it in the local Gatekeeper sandbox"
    )
    ap.add_argument("program", type=Path, help="raw RV64 program image (.bin)")
    ap.add_argument(
        "--qemu",
        default=DEFAULT_QEMU,
        help="path to the gatekeeper QEMU binary (default: ./qemu-system-riscv64)",
    )
    ap.add_argument(
        "--timeout",
        type=float,
        default=None,
        help="kill QEMU after N seconds (default: no limit)",
    )
    ap.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="show the verifier's full instruction-by-instruction trace",
    )
    ap.add_argument(
        "--skip-run",
        action="store_true",
        help="only verify; do not launch QEMU even on pass",
    )
    args = ap.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(asctime)s | %(message)s",
        datefmt="%H:%M:%S",
    )

    try:
        blob = args.program.read_bytes()
    except OSError as exc:
        sys.stderr.write(f"[!] cannot read program: {exc}\n")
        return 2

    # Stage 1 - static verification (identical to the server's gate).
    verdict = Verifier().verify(blob)
    print(verdict, file=sys.stderr)
    if not verdict.passed:
        return 1
    if args.skip_run:
        return 0

    # Stage 2 - execute the accepted image in the sandbox.
    if not os.path.exists(args.qemu):
        sys.stderr.write(
            f"[!] QEMU binary not found at {args.qemu}\n"
            f"    set --qemu / QEMU_BIN, or build it (see ../../BUILDING.md)\n"
        )
        return 2
    sys.stderr.write(f"[*] launching QEMU (dummy flag: {DUMMY_FLAG.decode()})\n")
    return run_qemu(args.qemu, blob, DUMMY_FLAG, args.timeout)


if __name__ == "__main__":
    sys.exit(main())
