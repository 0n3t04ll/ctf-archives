#include "ministd.h"
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>

void* memset(void* s, int c, size_t n)
{
    uint8_t* p = (uint8_t*)s;
    while (n--) {
        *p++ = (uint8_t)c;
    }
    return s;
}

void* memcpy(void* restrict dst, const void* restrict src, size_t n)
{
    uint8_t* d = (uint8_t*)dst;
    const uint8_t* s = (const uint8_t*)src;
    while (n--)
        *d++ = *s++;
    return dst;
}

int memcmp(const void* a, const void* b, size_t n)
{
    const uint8_t* p = (const uint8_t*)a;
    const uint8_t* q = (const uint8_t*)b;
    for (; n; --n, ++p, ++q) {
        if (*p != *q)
            return (int)*p - (int)*q;
    }
    return 0;
}

void* memchr(const void* s, int c, size_t n)
{
    const uint8_t* p = (const uint8_t*)s;
    uint8_t target = (uint8_t)c;
    for (; n; --n, ++p) {
        if (*p == target)
            return (void*)p;
    }
    return NULL;
}

void* memxor(void* dst, const void* src, size_t n)
{
    uint8_t* d = (uint8_t*)dst;
    const uint8_t* s = (const uint8_t*)src;
    while (n--)
        *d++ ^= *s++;
    return dst;
}

size_t strlen(const char* s)
{
    const char* p = s;
    while (*p)
        ++p;
    return (size_t)(p - s);
}

size_t strnlen(const char* s, size_t maxlen)
{
    size_t i = 0;
    while (i < maxlen && s[i])
        ++i;
    return i;
}

int strcmp(const char* a, const char* b)
{
    while (*a && (*a == *b)) {
        ++a;
        ++b;
    }
    return (int)(uint8_t)*a - (int)(uint8_t)*b;
}

int strncmp(const char* a, const char* b, size_t n)
{
    for (size_t i = 0; i < n; ++i) {
        uint8_t ac = (uint8_t)a[i];
        uint8_t bc = (uint8_t)b[i];
        if (ac != bc)
            return (int32_t)ac - (int32_t)bc;
        if (ac == 0)
            return 0;
    }
    return 0;
}

char* strcpy(char* dst, const char* src)
{
    char* r = dst;
    while ((*dst++ = *src++)) {
    }
    return r;
}

char* strncpy(char* dst, const char* src, size_t n)
{
    size_t i = 0;
    for (; i < n && src[i]; ++i)
        dst[i] = src[i];
    for (; i < n; ++i)
        dst[i] = '\0';
    return dst;
}

static inline int hex_nibble(int c)
{
    uint32_t x = (uint32_t)(uint8_t)c;

    uint32_t dec = x - (uint32_t)'0';
    uint32_t mdec = 0u - (dec <= 9u);

    uint32_t lo = (x | 0x20u) - (uint32_t)'a';
    uint32_t malp = 0u - (lo <= 5u);

    uint32_t val = (dec & mdec) | ((lo + 10u) & malp);

    uint32_t many = mdec | malp;
    return (int)((val & many) | ~many);
}

size_t hex_encode(const void* src, size_t n, char* dst, int uppercase)
{
    const unsigned char* s = (const unsigned char*)src;
    const char* digits = uppercase ? "0123456789ABCDEF" : "0123456789abcdef";
    for (size_t i = 0; i < n; ++i) {
        unsigned char b = s[i];
        dst[2 * i] = digits[(b >> 4) & 0xF];
        dst[2 * i + 1] = digits[b & 0xF];
    }
    dst[2 * n] = '\0';
    return 2 * n;
}

int hex_decode(const char* hex, size_t hex_len, void* dst, size_t dst_cap)
{
    if (hex_len % 2 != 0)
        return -1;

    size_t out_n = hex_len / 2;
    if (out_n > dst_cap)
        return -2;

    uint8_t* d = (uint8_t*)dst;
    for (size_t i = 0; i < out_n; ++i) {
        int32_t hi = hex_nibble(hex[2 * i]);
        int32_t lo = hex_nibble(hex[2 * i + 1]);
        d[i] = (uint8_t)((hi << 4) | lo);
    }
    return (int32_t)out_n;
}

char* u64_to_hex(uint64_t v, char* buf, unsigned width, int uppercase)
{
    if (width == 0)
        width = 1;
    if (width > 16)
        width = 16;
    const char* digits = uppercase ? "0123456789ABCDEF" : "0123456789abcdef";

    buf[width] = '\0';
    for (uint32_t i = 0; i < width; ++i) {
        buf[width - 1 - i] = digits[(uint32_t)(v & 0xF)];
        v >>= 4;
    }
    return buf;
}
