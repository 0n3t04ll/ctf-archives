# Gatekeeper - example program

`main.c` is tic-tac-toe. Use it as a template for your own programs.

It's a straight-line program on purpose: the verifier rejects input-dependent control flow, so the board is a packed integer placed with shifts and drawn/scored with branchless arithmetic - the moves are pure data, never branched on.

The flag is archived in the vault the same way, under a token you probably don't know.

## Build

```bash
./build.sh                                # -> build/example.bin   (raw image, loaded at 0x300000)
./build.sh disasm
./build.sh encode 2>/dev/null | tail -1   # base64 of the image, ready to submit
./build.sh clean
```

## Build (local toolchain)

If you'd rather use a host toolchain (`riscv64-linux-gnu-gcc` / `riscv64-unknown-elf-gcc`):

```bash
make all
make all CROSS_COMPILE=riscv64-unknown-elf-
```
