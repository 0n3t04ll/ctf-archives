from .references import resolve_descriptor

__all__ = ["resolve_descriptor"]
