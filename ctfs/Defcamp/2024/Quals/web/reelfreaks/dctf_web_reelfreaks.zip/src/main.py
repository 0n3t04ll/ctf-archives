from flask import Blueprint, request,render_template, abort
from flask_login import login_required, current_user
from .models import Movie, User
from . import db
import re
import threading
from .bot import visit

main = Blueprint('main', __name__)

@main.route('/')
def index():
    query= request.args.get('q', '').lower()
    if query:
        movies = db.session.query(Movie).filter(Movie.title.ilike(f'%{query}%'), Movie.banned == False).group_by(Movie.title).order_by((Movie.id).desc()).all()
    else:
        movies=db.session.query(Movie).filter(Movie.banned == False).all()
    

    return render_template('movies.html', movies=movies)

@main.route('/login')
def login():
    return render_template('login.html')

@main.route('/register')
def register():
    return render_template('register.html')

@main.route('/watchlist')
@login_required
def watchlist():
    movie_ids = current_user.get_watched()
    query= request.args.get('q', '').lower()
    if query:
        movies = db.session.query(Movie).filter(Movie.id.in_(movie_ids),Movie.title.ilike(f'%{query}%')).all()
    else:
        movies = db.session.query(Movie).filter(Movie.id.in_(movie_ids)).all()
    for i,movie in enumerate(movies):       
        if movie.banned != False and current_user.role != 'real_freak':
            movies.pop(i)
            continue
        watched_by = movie.get_watched()
        if watched_by:
            movie.users = []
            users = db.session.query(User).filter(User.id.in_(watched_by))
            if users:
                for user in users:
                    if not user.id == current_user.id:
                        movie.users.append(user.username)
    
    return render_template('watchlist.html',movies=movies)

@main.route('/add_movie', methods=['POST'])
@login_required
def add_movie():
    movie_id = request.form.get('movie_id')
    if movie_id:
        movie = db.session.query(Movie).get(movie_id)
    if movie:
            user = db.session.query(User).get(current_user.id)
            watchlist = user.get_watched() 

            if movie.id not in watchlist:
                watchlist.append(int(movie_id))
                user.set_watched(watchlist)
                watched_by = movie.get_watched()
                watched_by.append(int(current_user.id))
                movie.set_watched(watched_by)
                db.session.commit()
                return "Movie added successfully :)"

    return "Something went wrong :("

@main.route('/report', methods=['POST'])
@login_required
def report():
    url = "https://127.0.0.1" + request.form.get('movie')
    thread = threading.Thread(target=visit,args=(url,))
    thread.start()
    return 'OK'

@main.route('/movie/<int:id>', methods = ['GET'])
def movie(id):
    movie = db.session.query(Movie).get(id)
    if movie and movie.banned == False:
        return render_template("movie.html", movie=movie)
    abort(404)
