from . import db
import json

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True) 
    username = db.Column(db.String(1000), unique=True)
    password = db.Column(db.String(50))
    role = db.Column(db.String(50))
    watchlist = db.Column(db.String(1000),default='[]')

    def is_active(self):
        return True

    def get_id(self):
        return self.id
    
    def is_authenticated(self):
        return self.authenticated
    
    def is_anonymous(self):
        return False
    
    def get_watched(self):
        return json.loads(self.watchlist)
    
    def set_watched(self, list):
        self.watchlist = json.dumps(list)
        return self.watchlist
    

class Movie(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    poster = db.Column(db.String(250), nullable=True)
    banned = db.Column(db.Boolean, nullable=False)
    watched_by = db.Column(db.String(10000),default='[]')

    def get_watched(self):
        return json.loads(self.watched_by)
    
    def set_watched(self, list):
        self.watched_by = json.dumps(list)
        return self.watched_by