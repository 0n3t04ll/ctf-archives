# Uniswap Labs Security

## Vulnerability Disclosure and Bug Bounty

Bug bounty details can be found in https://uniswap.org/bug-bounty

## Careers

See our available job openings in https://boards.greenhouse.io/uniswaplabs

## Security Team Contact Details

Please contact us through the bug bounty https://uniswap.org/bug-bounty or directly via [security@uniswap.org](mailto:security@uniswap.org)
