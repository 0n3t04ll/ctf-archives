A dragon never forgets the order of its scales.
The map is not the treasure.
The first fold turns RIGHT.
