#ifndef TYPES_H
#define TYPES_H


struct Point {
  float x;
  float y;
};

#endif /* TYPES_H */
