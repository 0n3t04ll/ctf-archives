# ToH-Synth

It's not just about knowing keys... you also need to have an ear for choosing the right sound for the synthesizer to play!

## Credits
- [WASM-Synth (@TimDaub)](https://github.com/TimDaub/wasm-synth/)

## How to Run
In order to test locally, just run the service via docker, by using: 

```shell 
docker compose up
```

All things you need will be available at http://localhost:3000, including the bot (http://localhost:3000/bot).