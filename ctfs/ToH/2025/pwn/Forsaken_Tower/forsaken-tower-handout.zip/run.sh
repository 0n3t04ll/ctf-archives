#!/bin/bash
nohup Xvfb :99 -screen 0 1024x768x24 &
export DISPLAY=:99
export XDG_RUNTIME_DIR=/tmp/runtime-ubuntu
timeout --signal=SIGKILL 60s /usr/local/bin/dolphin-emu -e /forsaken_tower.elf -v=OGL --config=Dolphin.General.WiiSDCardPath=/tmp/SDCARDExample --config=Dolphin.General.NANDRootPath=/home/ubuntu/.local/share/dolphin-emu/Wii/ -m tas_path