#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h> // For directory operations
#include <unistd.h> // For fork, pipe, read, write, close, getpid
#include <fcntl.h>  // For file control options (O_RDONLY, etc.)
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>        // For errno and error handling
#include <netinet/in.h>   // For sockaddr_in, INADDR_ANY, htons
#include <arpa/inet.h>    // For inet_ntop, inet_pton
#include <netdb.h>        // For gethostbyname, getprotobyname
#include <sys/socket.h>   // For socket, bind, listen, accept
#include <sys/wait.h>     // For waitpid
#include <signal.h>       // For sigaction, SIGCHLD, signal handling
#include <netinet/tcp.h>  // For TCP_NODELAY
#include <sys/ioctl.h>    // For ioctl
#include <string.h>       // For memset
#include <errno.h>        // For errno
#include <stdbool.h>     // For bool type
#include <stdint.h>       // For uint8_t
#include <sys/sendfile.h> // For sendfile

#define MAX_CARDS 10
#define PORT 5000
#define CARDS_DIR "cards/"
#define MAX_FILENAME_LEN 256 // Max length for filenames within cards directory
#define MAX_FILEPATH_LEN 512 // Max length for full file path (CARDS_DIR + filename)

int card_numbers[MAX_CARDS];
int card_FDs[MAX_CARDS]; // File descriptors for card files
int card_count = 0;
uint8_t* card_buffer;

// Function to handle individual client connections
// This is where you'll put your logic for each client.
void handle_client(int client_fd)
{
    printf("[Child PID: %d] Handling client on socket %d\n", getpid(), client_fd);

    // --- BEGIN USER LOGIC ---

    // The user sends commands that can be 'list' or 'get <card_number>'
    char buffer[1024];
    ssize_t bytes_received = read(client_fd, buffer, sizeof(buffer) - 1);

    if (bytes_received < 0)
    {
        perror("[Child] Failed to read from client");
    }
    else 
    {
        buffer[bytes_received] = '\0'; // Null-terminate the string
        printf("[Child PID: %d] Received command: %s\n", getpid(), buffer);

        // Example logic: If the command is 'list', send the card numbers
        if (strncmp(buffer, "list", 4) == 0)
        {
            char response[1024];
            response[0] = '['; // Initialize response buffer
            response[1] = '\0'; // Null-terminate the string
            int len = 1; // Start with the opening bracket
            
            for (int i = 0; i < card_count; i++) {
                len += snprintf(response + len, sizeof(response) - len, "%d,", card_numbers[i]);
            }
            if (len > 1) {
                response[len - 1] = ']'; // Replace last comma with closing bracket
                len++; // Adjust length for closing bracket
            }

            if (write(client_fd, response, len) < 0) {
                perror("[Child] Failed to write card list");
            }
        }
        else if (strncmp(buffer, "get", 3) == 0)
        {
            // Example logic: Send a specific card file
            int card_num = atoi(buffer + 4); // Assuming format is 'get <card_number>'

            bool found = false;
            int index = -1;

            for (int i = 0; i < card_count; i++) {
                if (card_numbers[i] == card_num) {
                    found = true;
                    index = i;
                    break;
                }
            }

            if (!found) {
                char error_msg[] = "Card not found.\n";
                write(client_fd, error_msg, strlen(error_msg));
                return;
            }

            long file_size = lseek(card_FDs[index], 0, SEEK_END);

            if (file_size < 0) {
                perror("[Child] Failed to seek to end of card file");
                return;
            }
            
            // Reset file position to beginning
            if (lseek(card_FDs[index], 0, SEEK_SET) < 0) {
                perror("[Child] Failed to seek to beginning of card file");
                return;
            }
            
            off_t offset = 0; // Must be initialized, will be updated by sendfile
            ssize_t sent = sendfile(client_fd, card_FDs[index], &offset, file_size); // Send the file to the client
            if (sent < 0) {
                perror("[Child] Failed to send file");
                return;
            }
            printf("[Child] Sent %zd bytes of card %d to client\n", sent, card_num);
            
        } 
        else
        {
            char error_msg[] = "Unknown command.\n";
            write(client_fd, error_msg, strlen(error_msg));
        }
    }

    printf("[Child PID: %d] Client handling complete. Closing connection.\n", getpid());
    if (close(client_fd) < 0) {
        perror("[Child] Failed to close client socket");
    }
}

// Signal handler for SIGCHLD to reap zombie processes
void sigchld_handler(int s) {
    (void)s; // Unused parameter
    int saved_errno = errno; // waitpid() might change errno

    // Reap all terminated children
    while (waitpid(-1, NULL, WNOHANG) > 0);

    errno = saved_errno;
}

int main(int argc, char *argv[]) {
    DIR *directory;
    struct dirent *entry;
    char card_filepaths[MAX_CARDS][MAX_FILEPATH_LEN]; // Store full paths to card files

    // --- Load Card Information ---
    printf("[Server] Loading card information from directory: %s\n", CARDS_DIR);
    directory = opendir(CARDS_DIR);

    if (directory == NULL) {
        perror("[Server] Failed to open cards directory");
        // Depending on requirements, you might want to exit or continue without cards.
        // For this example, we'll continue, but card_count will be 0.
    } else {
        while ((entry = readdir(directory)) != NULL && card_count < MAX_CARDS) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
                continue;
            }

            char *extension = strrchr(entry->d_name, '.');
            if (extension != NULL && strcmp(extension, ".bin") == 0) {
                int card_num = atoi(entry->d_name); // Assumes filename is like "123.bin"
                if (card_num > 0) { // Basic validation
                    card_numbers[card_count] = card_num;
                    
                    // Construct the full path
                    int path_len = snprintf(card_filepaths[card_count], MAX_FILEPATH_LEN, "%s%s", CARDS_DIR, entry->d_name);
                    if (path_len < 0 || path_len >= MAX_FILEPATH_LEN) {
                        fprintf(stderr, "[Server] Error: Filepath for %s is too long or encoding error.\n", entry->d_name);
                        // Skip this card
                        continue;
                    }
                    
                    printf("[Server] Found card: Number %d, Path: %s\n", card_numbers[card_count], card_filepaths[card_count]);
                    card_count++;
                } else {
                     fprintf(stderr, "[Server] Warning: Could not parse card number from filename: %s\n", entry->d_name);
                }
            }
        }
        closedir(directory);
    }
    printf("[Server] Loaded %d card(s).\n", card_count);

    // --- Open Card Files ---
    for (int i = 0; i < card_count; i++) {
        card_FDs[i] = open(card_filepaths[i], O_RDONLY, 0);
        if (card_FDs[i] < 0) {
            perror("[Server] Failed to open card file");
            // Handle error: maybe skip this card or exit
            continue; // For this example, we'll just skip the file
        }
    }

    // --- Server Setup ---
    int listen_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len;
    struct sigaction sa;

    // Create listening socket
    listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        perror("[Server] Failed to create socket");
        return EXIT_FAILURE;
    }

    // Set SO_REUSEADDR to allow quick restarts
    int optval = 1;
    if (setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0) {
        perror("[Server] Failed to set SO_REUSEADDR");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY; // Listen on all available interfaces
    server_addr.sin_port = htons(PORT);       // Port number

    // Bind the socket to the address and port
    if (bind(listen_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("[Server] Failed to bind socket");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    // Listen for incoming connections
    if (listen(listen_fd, 10) < 0) { // Backlog of 10 connections
        perror("[Server] Failed to listen on socket");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    // Setup SIGCHLD handler to reap zombie processes
    sa.sa_handler = sigchld_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0; // Some systems may not define SA_RESTART
    if (sigaction(SIGCHLD, &sa, NULL) == -1) {
        perror("[Server] Failed to set up SIGCHLD handler (sigaction)");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    printf("[Server PID: %d] Server listening on port %d...\n", getpid(), PORT);

    // --- Main Accept Loop ---
    while (1) {
        client_addr_len = sizeof(client_addr);
        client_fd = accept(listen_fd, (struct sockaddr *)&client_addr, &client_addr_len);

        if (client_fd < 0) {
            if (errno == EINTR) { // Interrupted by a signal (e.g., SIGCHLD if SA_RESTART wasn't fully effective or another signal)
                perror("[Server] accept interrupted, retrying");
                continue; // Retry accept
            }
            perror("[Server] Failed to accept connection");
            // Depending on the error, you might want to continue or exit.
            // For persistent errors, exiting might be necessary.
            // For transient errors, continuing is often preferred.
            continue; 
        }

        // Log client connection
        char client_ip_str[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &client_addr.sin_addr, client_ip_str, sizeof(client_ip_str));
        printf("[Server PID: %d] Accepted connection from %s:%d on socket %d\n",
               getpid(), client_ip_str, ntohs(client_addr.sin_port), client_fd);

        // Fork a child process to handle the client
        pid_t pid = fork();

        if (pid < 0) { // Fork failed
            perror("[Server] Failed to fork child process");
            close(client_fd); // Close the client socket as we can't handle it
            // Log error, maybe pause briefly to avoid overwhelming system if fork keeps failing
            sleep(1); // Simple way to throttle if fork fails repeatedly
        } else if (pid == 0) { // Child process
            // Child doesn't need the listening socket
            if (close(listen_fd) < 0) {
                 perror("[Child] Failed to close listening socket");
                 // This is an issue, but child should still try to handle client and then exit.
            }

            // Handle the client connection
            handle_client(client_fd);
            
            // Child process exits after handling the client
            exit(EXIT_SUCCESS);
        } else { // Parent process
            // Parent doesn't need the connected client socket (child handles it)
            if (close(client_fd) < 0) {
                perror("[Parent] Failed to close client socket after fork");
            }
            printf("[Server PID: %d] Forked child process %d to handle client %s:%d\n",
                   getpid(), pid, client_ip_str, ntohs(client_addr.sin_port));
        }
    }

    // --- Cleanup (normally not reached in a while(1) server) ---
    printf("[Server] Shutting down...\n");
    if (close(listen_fd) < 0) {
        perror("[Server] Failed to close listening socket on shutdown");
    }

    return EXIT_SUCCESS;
}
