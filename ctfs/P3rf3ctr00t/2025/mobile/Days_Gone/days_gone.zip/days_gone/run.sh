qemu-system-aarch64 \
    -machine virt \
    -cpu cortex-a57 \
    -nographic \
    -smp 1 \
    -m 512M \
    -kernel Image \
    -hda rootfs.ext2 \
    -append "console=ttyAMA0 root=/dev/vda rw" \
    -net user,hostfwd=tcp::10021-:22 -net nic \
    -no-reboot

