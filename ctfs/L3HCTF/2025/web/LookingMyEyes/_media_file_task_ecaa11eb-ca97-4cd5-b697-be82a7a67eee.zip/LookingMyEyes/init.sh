#!/bin/sh
rm -f /tmp/init.sh

# 替换数据库的 flag
# sed -i 's/flag{kfccrazythursdayvme50}/'"$GZCTF_FLAG"'/' /root/database.sql
# Check the environment variables for the flag and assign to INSERT_FLAG
# 需要注意，以下语句会将FLAG相关传递变量进行覆盖，如果需要，请注意修改相关操作
if [ "$DASFLAG" ]; then
    INSERT_FLAG="$DASFLAG"
    export DASFLAG=no_FLAG
    DASFLAG=no_FLAG
elif [ "$FLAG" ]; then
    INSERT_FLAG="$FLAG"
    export FLAG=no_FLAG
    FLAG=no_FLAG
elif [ "$GZCTF_FLAG" ]; then
    INSERT_FLAG="$GZCTF_FLAG"
    export GZCTF_FLAG=no_FLAG
    GZCTF_FLAG=no_FLAG
else
    INSERT_FLAG="L3HCTF{12312123}"
fi

# 将FLAG写入文件 请根据需要修改
echo $INSERT_FLAG | tee /flag

export INSERT_FLAG=no_FLAG
INSERT_FLAG=no_FLAG

echo "" > /etc/resolv.conf
su - dotnet -c "cd /app && dotnet netdot2025.dll urls='http://*:80' &"
# tail -f /dev/null
while true; do
    echo "change my eyes!"
    cp /tmp/Eyes.cshtml /app/Looking/My/Eyes.cshtml
    sleep 10
done

