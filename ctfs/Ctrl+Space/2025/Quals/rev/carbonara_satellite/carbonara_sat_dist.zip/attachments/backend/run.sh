#!/bin/bash

cd /chall
LD_LIBRARY_PATH=/root/lib ./chall