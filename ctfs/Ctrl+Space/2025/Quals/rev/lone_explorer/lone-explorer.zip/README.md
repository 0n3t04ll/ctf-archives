>Wandering through the endless deep space, you feel the cold realization strike — your elbow brushed the console, and the instruction manual for your vessel was flung into the void, spinning away like a discarded prayer.
<br><br>
“Why would anyone design such a curse of a button?!” your voice cracks against the silence, swallowed by the infinite dark. The words linger, useless, as regret coils tighter around you. You should have studied the manual long before launch.
<br><br>
This ship, **your ship**, is infamous across the stars for a labyrinth of controls no sane mind can master. Every switch whispers confusion. Every dial mocks you. Returning home will demand more than luck.

---

Reach the moon called `Dan` to claim your reward.

Read `controls.txt` to know how to play.

After reaching the destination, the game will give you a token to claim the flag on the remote. Remote requires a hashcash PoW to prevent spam.
