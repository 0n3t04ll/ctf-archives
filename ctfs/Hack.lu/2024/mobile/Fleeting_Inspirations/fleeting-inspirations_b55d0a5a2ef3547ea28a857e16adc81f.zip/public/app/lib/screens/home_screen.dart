import 'dart:io';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../platform/share.dart' as share;
import '../store/store.dart' as store;
import '../store/inspiration_image.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.title});

  final String title;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, InspirationImage> images = {};

  void _updateImages() {
    store.getImages().then((newImages) {
      setState(() => images = newImages);
    });
  }

  @override
  void initState() {
    super.initState();
    _updateImages();
    store.imagesChangedBroadcast.stream.listen((_) => _updateImages());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
        actions: [
          IconButton(onPressed: _onDownloadPressed, icon: const Icon(Icons.download)),
          PopupMenuButton(
            onSelected: (_) => context.push('/webview?url=file:///android_asset/info.html'),
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 0,
                child: Text('Info'),
              ),
            ],
          ),
        ],
      ),
      body: GridView.count(
        crossAxisCount: 3,
        children: images.entries
            .map(
              (entry) => InkWell(
                onTap: () => context.push('/image?id=${entry.key}'),
                child: Image.file(File(entry.value.path)),
              ),
            )
            .toList(),
      ),
    );
  }

  void _onDownloadPressed() {
    final textController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Import image'),
        content: IntrinsicHeight(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'You can download and import an inspirational image. Also try sharing a URL or image and select  to import it.',
              ),
              TextField(
                controller: textController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'https://example.com/image.jpg',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => context.pop(), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              share.handleDownload(textController.text);
              context.pop();
            },
            child: const Text('Import'),
          ),
        ],
      ),
    );
  }
}
