import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';

import 'platform/provider.dart';
import 'screens/home_screen.dart';
import 'screens/webview_screen.dart';
import 'screens/image_screen.dart';
import 'screens/error_screen.dart';
import 'platform/share.dart';

const _title = 'Fleeting Inspirations';

final _router = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const HomeScreen(title: _title),
    ),
    GoRoute(
      path: '/error',
      builder: (context, state) => const ErrorScreen(title: _title),
    ),
    GoRoute(
      path: '/webview',
      builder: (context, state) => WebViewScreen(url: state.uri.queryParameters['url'] ?? '', title: _title),
    ),
    GoRoute(
      path: '/image',
      builder: (context, state) => ImageScreen(id: state.uri.queryParameters['id'] ?? ''),
    ),
  ],
);

void main() {
  print('initial route: ' + PlatformDispatcher.instance.defaultRouteName);
  runApp(const App());
}

@pragma('vm:entry-point')
void providerEntryPoint() {
  Provider();
}

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<StatefulWidget> createState() => _AppState();
}

class _AppState extends State<App> {
  late StreamSubscription _intentSub;

  @override
  void initState() {
    super.initState();
    ReceiveSharingIntent.instance.getInitialMedia().then((sharedFiles) => sharedFiles.forEach(handleShare));
    _intentSub = ReceiveSharingIntent.instance.getMediaStream().listen(
          (sharedFiles) => sharedFiles.forEach(handleShare),
          onError: (err) => print("getIntentDataStream error: $err"),
        );
  }

  @override
  void dispose() {
    _intentSub.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: _title,
      routerConfig: _router,
    );
  }
}
