import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'package:path/path.dart' as path_lib;

import 'inspiration_image.dart';

final SharedPreferencesAsync _sharedPrefs = SharedPreferencesAsync();
final StreamController imagesChangedBroadcast = StreamController.broadcast();
const _storeKey = 'inspirational_images';
const _idKey = 'inspirational_id';

Future<void> _initStore() async {
  if (!(await _sharedPrefs.getKeys()).contains(_storeKey)) {
    await _sharedPrefs.setString(_storeKey, json.encode({}));
    await _sharedPrefs.setInt(_idKey, 0);
    final bytes = await rootBundle.load('assets/example-image.jpg');
    final path = await copyImageToFiles(bytes.buffer.asInt8List());
    await saveImageDataToStore(path, 'example image', 'image/jpg');
  }
}

Future<String> copyImageToFiles(List<int> bytes) async {
  var uuid = const Uuid().v4();
  var filesDir = (await getApplicationSupportDirectory()).path;
  var path = path_lib.join(filesDir, uuid);
  await File(path).writeAsBytes(bytes);
  return path;
}

Future<void> saveImageDataToStore(String path, String name, String type) async {
  var currentId = await _getCurrentId();

  var images = await getImages();
  images[currentId.toString()] = InspirationImage(path, name, type);
  await _setImages(images);

  currentId += 1;
  await _sharedPrefs.setInt(_idKey, currentId);

  imagesChangedBroadcast.add('image added');
}

Future<int> _getCurrentId() async {
  await _initStore();
  return (await _sharedPrefs.getInt(_idKey)) as int;
}

Future<Map<String, InspirationImage>> getImages() async {
  await _initStore();
  Map<String, dynamic> jsonMap = json.decode(await _sharedPrefs.getString(_storeKey) as String);
  return jsonMap.map((key, val) => MapEntry(key, InspirationImage.fromJson(val)));
}

Future<InspirationImage?> getImage(String id) async {
  var images = await getImages();
  return images[id];
}

Future<void> deleteImage(String id) async {
  var images = await getImages();
  images.remove(id);
  await File(images[id]!.path).delete();
  await _setImages(images);
  imagesChangedBroadcast.add('image deleted');
}

Future<void> _setImages(Map<String, InspirationImage> images) async {
  var json = jsonEncode(images.map((key, val) => MapEntry(key, val.toJson())));
  await _sharedPrefs.setString(_storeKey, json);
}
