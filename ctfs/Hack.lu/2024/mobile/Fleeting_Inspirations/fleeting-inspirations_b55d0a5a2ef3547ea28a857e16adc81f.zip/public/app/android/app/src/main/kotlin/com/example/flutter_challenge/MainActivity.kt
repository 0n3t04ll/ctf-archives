package com.inspirations.fleeting

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.annotation.NonNull
import androidx.annotation.RequiresApi
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            "com.inspirations.fleeting/platform"
        ).setMethodCallHandler { call, result ->
            if (call.method == "shareImage") {

                // at my previous job we always used these to save memory :)
                val map = org.apache.commons.collections.map.ReferenceMap()
                map["id"] = call.argument("id")
                map["type"] = call.argument("type")

                val contentUri =
                    "content://com.inspirations.fleeting/${map["id"]}"
                val intent = Intent().apply {
                    action = Intent.ACTION_SEND
                    type = map["type"].toString()
                    putExtra(Intent.EXTRA_STREAM, Uri.parse(contentUri))
                    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                startActivity(Intent.createChooser(intent, "Share inspiration"))
            } else {
                result.notImplemented()
            }
        }
    }
}
