import 'dart:io';

import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:path/path.dart' as path_lib;
import 'package:http/http.dart' as http;

import '../store/store.dart' as store;

void handleShare(SharedMediaFile file) {
  print('received share, ${file.path}, ${file.mimeType}');
  switch (file.mimeType) {
    case 'text/plain':
      handleDownload(file.path);
    case 'image/jpg' || 'image/jpeg' || 'image/png':
      _handleImageShare(file.path, file.mimeType!);
  }
}

Future<void> _handleImageShare(String path, String type) async {
  var imageBytes = await File(path).readAsBytes();
  var newPath = await store.copyImageToFiles(imageBytes);
  await store.saveImageDataToStore(newPath, path_lib.basename(path), type);
}

Future<void> handleDownload(String url) async {
  try {
    var parsedUrl = Uri.parse(url);
    var response = await http.get(parsedUrl);
    if (response.statusCode != 200) return;
    var type = response.headers['content-type'];
    if (!['image/jpg', 'image/jpeg', 'image/png'].contains(type)) return;

    var contentDisposition = response.headers['content-disposition'] ?? '';
    var match = RegExp(r'filename=(.+?)(;|$)').firstMatch(contentDisposition);
    var name = match?.group(1) ?? path_lib.basename(parsedUrl.path);
    if (name == '') {
      name = 'image.jpg';
    }

    var path = await store.copyImageToFiles(response.bodyBytes);
    await store.saveImageDataToStore(path, name, type!);
  } catch (e) {
    print(e);
  }
}
