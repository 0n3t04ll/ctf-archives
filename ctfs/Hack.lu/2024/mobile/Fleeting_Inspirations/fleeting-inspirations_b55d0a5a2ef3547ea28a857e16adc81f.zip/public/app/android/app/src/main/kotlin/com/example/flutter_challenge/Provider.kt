package com.inspirations.fleeting

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import io.flutter.FlutterInjector
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineGroup
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMethodCodec
import java.io.File
import java.io.IOException
import SynchronousMethodChannel
import android.app.Activity
import android.app.Application
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlin.system.exitProcess

// adapted from https://github.com/nt4f04uNd/android_content_provider/blob/master/android/src/main/kotlin/com/nt4f04und/android_content_provider/AndroidContentProvider.kt

class Provider : ContentProvider() {
    companion object {
        private var engineGroup: FlutterEngineGroup? = null
        fun getFlutterEngineGroup(context: Context): FlutterEngineGroup {
            if (engineGroup == null) {
                engineGroup = FlutterEngineGroup(context.applicationContext)
            }
            return engineGroup!!
        }
    }

    private lateinit var engine: FlutterEngine
    private lateinit var methodChannel: SynchronousMethodChannel
    private val authority = "com.inspirations.fleeting"
    private val entrypointName = "providerEntryPoint"

    override fun onCreate(): Boolean {
        val flutterLoader = FlutterInjector.instance().flutterLoader()
        flutterLoader.startInitialization(context!!.applicationContext)
        val entrypoint =
            DartExecutor.DartEntrypoint(flutterLoader.findAppBundlePath(), entrypointName)
        val engineGroup = getFlutterEngineGroup(context!!)
        engine = engineGroup.createAndRunEngine(context!!, entrypoint)
        methodChannel = SynchronousMethodChannel(
            MethodChannel(
                engine.dartExecutor.binaryMessenger,
                "$authority/provider",
                StandardMethodCodec.INSTANCE,
                engine.dartExecutor.binaryMessenger.makeBackgroundTaskQueue(
                    BinaryMessenger.TaskQueueOptions().setIsSerial(false)
                )
            )
        )
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val result = getImage(uri) ?: return null
        Log.v("provider", "requested ${result["name"]}")
        val cursor = MatrixCursor(
            if (projection.isNullOrEmpty()) arrayOf("_display_name", "mime_type") else projection
        )
        cursor.newRow().apply {
            add("_display_name", result["name"])
            add("mime_type", result["type"])
        }
        return cursor
    }

    override fun getType(uri: Uri): String? {
        val result = getImage(uri) ?: return null
        return result["type"]
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        if (mode != "r") {
            throw IOException()
        }
        val result = getImage(uri) ?: return null
        // free up system resources after fulfilling content request
        Handler(Looper.getMainLooper()).postDelayed( {
            exitProcess(0)
        }, 1000)
        return ParcelFileDescriptor.open(File(result["path"]!!), ParcelFileDescriptor.parseMode("r"))
    }

    override fun getStreamTypes(uri: Uri, mimeTypeFilter: String): Array<String>? {
        val result = getImage(uri) ?: return null
        return arrayOf(result["type"]!!)
    }

    override fun insert(p0: Uri, p1: ContentValues?): Uri? {
        throw NotImplementedError()
    }

    override fun delete(p0: Uri, p1: String?, p2: Array<out String>?): Int {
        throw NotImplementedError()
    }

    override fun update(p0: Uri, p1: ContentValues?, p2: String?, p3: Array<out String>?): Int {
        throw NotImplementedError()
    }

    private fun getImage(uri: Uri): Map<String, String>? {
        return methodChannel.invokeMethod(
            "getImage", mapOf("id" to uri.lastPathSegment)
        ) as Map<String, String>?
    }
}

