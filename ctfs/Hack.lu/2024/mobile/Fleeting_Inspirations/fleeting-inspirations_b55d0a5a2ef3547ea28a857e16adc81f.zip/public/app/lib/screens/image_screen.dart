import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../store/inspiration_image.dart';
import '../store/store.dart' as store;

class ImageScreen extends StatefulWidget {
  const ImageScreen({super.key, required this.id});

  final String id;

  @override
  State<ImageScreen> createState() => _ImageScreenState();
}

class _ImageScreenState extends State<ImageScreen> {
  InspirationImage? image;
  static const _platform = MethodChannel('com.inspirations.fleeting/platform');

  @override
  void initState() {
    super.initState();
    store.getImage(widget.id).then((maybeImage) {
      if (maybeImage == null) {
        context.go('/error');
      } else {
        setState(() => image = maybeImage);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(image?.name ?? ''),
      ),
      body: image != null ? Center(child: Image.file(File(image!.path), fit: BoxFit.cover)) : null,
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(onPressed: _sharePressed, heroTag: null, child: const Icon(Icons.share)),
          const SizedBox(width: 10),
          FloatingActionButton(onPressed: _deletePressed, heroTag: null, child: const Icon(Icons.delete)),
        ],
      ),
    );
  }

  void _sharePressed() async {
    await _platform.invokeMethod('shareImage', {'id': widget.id, 'type': image?.type});
  }

  void _deletePressed() async {
    await store.deleteImage(widget.id);
    context.pop();
  }
}
