class InspirationImage {
  final String path;
  final String name;
  final String type;

  InspirationImage(this.path, this.name, this.type);

  InspirationImage.fromJson(Map<String, dynamic> json)
      : path = json['path'] as String,
        name = json['name'] as String,
        type = json['type'] as String;

  Map<String, dynamic> toJson() => {
        'path': path,
        'name': name,
        'type': type,
      };
}
