import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../store/store.dart' as store;

class Provider {
  final MethodChannel _methodChannel = const MethodChannel('com.inspirations.fleeting/provider');
  Provider() {
    WidgetsFlutterBinding.ensureInitialized();
    _methodChannel.setMethodCallHandler(_handleMethodCall);
  }

  Future<dynamic> _handleMethodCall(MethodCall call) async {
    if (call.method != 'getImage') throw UnimplementedError();
    var id = call.arguments['id'];
    if (id == null) return null;
    var image = await store.getImage(id);
    return image?.toJson();
  }
}
