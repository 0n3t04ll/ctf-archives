# Local testing
- Install Android Studio and an Android Emulator
- Install app in the emulator
- Install Flutter SDK for debugging the source
- If you want to test the remote setup:
  - please note that this exposes the `/dev/kvm` device for nested virtualization
  - the build will take a long time!
  - `sudo ./build-docker.sh`
  - `sudo docker compose up`
