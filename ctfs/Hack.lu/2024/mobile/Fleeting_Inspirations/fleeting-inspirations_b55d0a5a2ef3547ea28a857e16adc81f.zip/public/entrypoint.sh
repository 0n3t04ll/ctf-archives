#!/bin/bash

echo 'enter a URL that the android bot should visit (http://* or https://*):'
read -r url
if [[ "$url" !=  https://* && "$url" !=  http://* ]]; then
  echo url has to start with http:// or https://
  exit 1
fi

options="-avd emulator  -snapshot booted -force-snapshot-load  -no-window -memory 4096 -accel on -no-audio -no-boot-anim -camera-back none -gpu off"

# start emulator from snapshot for faster boottime
rm ~/.android/avd/emulator.avd/*.lock
adb start-server
echo "emulator ${options}"
emulator $options 2>/dev/null 1>/dev/null &
emulator_pid=$!

# wait until Android has fully booted
start_time=$(date +%s)
timeout=120
while true; do
  result=$(adb shell getprop sys.boot_completed 2>&1)
  if [ "$result" == "1" ]; then
    echo "Emulator booted"
    break
  fi
  if ! ps -p $emulator_pid > /dev/null; then
    echo "Emulator crashed. Retry or create a ticket in Discord."
    exit 1
  fi
  echo "Waiting for emulator to boot..."
  current_time=$(date +%s)
  elapsed_time=$((current_time - start_time))
  if [ $elapsed_time -gt $timeout ]; then
    echo "Emulator boot timeout"
    exit 1
  fi
  sleep 4
done

# fix wrong date from snapshot so HTTPS still works
adb shell date -s $(printf '%(%m%d%H%M%Y.%S)T' -2)
adb shell am broadcast -a android.intent.action.TIME_SET

# open submitted url
adb shell am start -n com.android.chrome/com.google.android.apps.chrome.Main -a android.intent.action.VIEW -d "$url"

# let website load
sleep 10

# one-click attack :)
echo tapping the screen
adb shell input tap 160 160

# do your thing in 30 seconds
sleep 30
echo time is up
