#!/bin/bash

options="-avd emulator  -no-snapshot  -no-window -memory 4096 -accel on -no-audio -no-boot-anim -camera-back none -gpu off"

# start emulator from scratch
adb start-server
echo "emulator ${options} "
emulator $options 2>/dev/null 1>/dev/null &
emulator_pid=$!

# wait until Android has fully booted
start_time=$(date +%s)
timeout=180
while true; do
  result=$(adb shell getprop sys.boot_completed 2>&1)
  if [ "$result" == "1" ]; then
    echo "Emulator booted"
    break
  fi
  if ! ps -p $emulator_pid > /dev/null; then
    echo "Emulator crashed. Retry."
    exit 1
  fi
  echo "Waiting for emulator to boot..."
  current_time=$(date +%s)
  elapsed_time=$((current_time - start_time))
  if [ $elapsed_time -gt $timeout ]; then
    echo "Emulator boot timeout"
    exit 1
  fi
  sleep 4
done

# install app
adb install /app.apk

# place flag in app's private folder
flag_name="flag_$(openssl rand -hex 12)"
adb root
adb shell "echo $FLAG > /data/data/com.inspirations.fleeting/$flag_name"

# prevent first run popups in Chrome
adb shell 'echo chrome --disable-fre --no-default-browser-check --no-first-run --ash-no-nudges > /data/local/tmp/chrome-command-line'
adb shell am set-debug-app --persistent com.android.chrome
adb shell pm grant com.android.chrome android.permission.POST_NOTIFICATIONS

# prevent random system popups (why is the emulator like this ;_;)
adb shell pm disable com.android.systemui

# open Chrome
adb shell am start -n com.android.chrome/com.google.android.apps.chrome.Main -a android.intent.action.VIEW -d "https://example.com"

# let Chrome start and website load
sleep 20

# save snapshot with emulator booted and Chrome already open
adb emu avd snapshot save booted
kill $emulator_pid

# tell host that we're done and wait for docker container commit
echo snapshot saved
sleep 500
