#!/bin/bash

mkfifo /tmp/fleetingpipe
docker build -t fleeting-inspirations-snapshot .
docker run --env-file .env --rm --name fleeting-inspirations-snapshot-container --device /dev/kvm fleeting-inspirations-snapshot > /tmp/fleetingpipe &
# wait until emulator snapshot made inside container
while true
do
    if read line </tmp/fleetingpipe; then
        if [[ "$line" == 'snapshot saved' ]]; then
            break
        fi
        echo $line
    fi
done
# save docker image with snapshot inside
docker commit --change "ENTRYPOINT /entrypoint.sh" fleeting-inspirations-snapshot-container fleeting-inspirations:latest
docker kill fleeting-inspirations-snapshot-container
rm /tmp/fleetingpipe
