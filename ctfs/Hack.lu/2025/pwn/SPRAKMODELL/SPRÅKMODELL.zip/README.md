# SPRÅKMODELL

I was looking at the [Ollama](https://github.com/ollama/ollama/tree/v0.6.8) code base and their `mllama` model handling seemed sus, especially the key-value stuff...

For a leaner DIY experience, I copied things from the [`ggml`](https://github.com/ollama/ollama/tree/v0.6.8/ml/backend/ggml/ggml) and [`llama`](https://github.com/ollama/ollama/tree/v0.6.8/llama) dirs of Ollama `v0.6.8`, and sprinkled a `challenge.cpp` on top.

You can find some tools in `gguf/` that will help with assembling your very own LLM! Try `python3 gguf/craft.py > model.gguf` for a start.
