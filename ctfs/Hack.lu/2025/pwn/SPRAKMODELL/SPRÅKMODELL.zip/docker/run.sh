#!/bin/sh

# periodic cleanup
sh -c 'while true; do sudo -u nobody find /tmp/ -name "model*" -type f -mmin +10 -delete; sleep 60; done' &

exec socat -d tcp-listen:1337,fork,reuseaddr exec:'timeout 600 env LD_LIBRARY_PATH=/app /app/challenge',su=nobody,stderr
