#!/bin/sh
# Start a cleanup loop for removing old PDFs
(
  while true; do
    find ./uploads -type f -mmin +15 -delete
    sleep 300
    echo "Deleted files older than 15 minutes at $(date)"
  done
) &

# Start the application
exec npm start
