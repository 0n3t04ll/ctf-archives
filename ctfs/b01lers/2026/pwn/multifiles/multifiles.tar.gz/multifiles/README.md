# multifiles

build artifacts in `build_out/`

rebuild with `pwn_build.sh`

run challenge with `dev.sh`
