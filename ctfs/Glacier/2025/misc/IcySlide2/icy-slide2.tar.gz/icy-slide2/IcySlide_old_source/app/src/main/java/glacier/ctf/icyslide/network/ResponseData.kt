package glacier.ctf.icyslide.network

data class ResponseData(
    val processedData: String
)

data class TestResponse(
    val message: String,
    val somethingElse: String
)
