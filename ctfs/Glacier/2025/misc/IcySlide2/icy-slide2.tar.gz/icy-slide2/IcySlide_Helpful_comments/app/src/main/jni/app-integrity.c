// Include JNI header to allow interaction with Java/Kotlin code
#include <jni.h>

// Include standard C libraries for string manipulation, file access, directories, input/output, and character checks
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <ctype.h>

/**
 * JNI function init2
 * This function is used to check for root indicators on the device.
 * Returns JNI_TRUE if the environment appears safe (no root detected), JNI_FALSE otherwise.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          //  [[p.draw.rect(sc,tuple(min(S[y][j]+40,255)for j in range(3))if(r,c)in v and y!="#"else S[y],(c*48,r*48,48,48))for c,y in enumerate(x)]for r,x in enumerate(l)];p.draw.rect(sc,(0,0,200),(P[1]*48,P[0]*48,48,48));w*(not gc)and sc.blit(f.render("Press any Key to get to next level",1,(0,0,0),(255,255,0)),(20,20));gc and(sc.fill((0,0,0)),sc.blit(f.render("Where gctf flag?",1,(255,255,0)),(50,100)),sc.blit(f.render("Press ENTER or ESC to quit.",1,(200,200,200)),(50,150)));p.display.flip()
 */
JNIEXPORT jboolean JNICALL
Java_glacier_ctf_icyslide_utils_IcySlideUtils_init2(JNIEnv *env, jobject obj) {

    // Array of common paths where 'su' binary might exist (indicates root)
    const char *su_paths[] = {"/system/bin/su", "/system/xbin/su", "/sbin/su"};

    // Iterate through all potential 'su' paths
    for (int i = 0; i < sizeof(su_paths) / sizeof(su_paths[0]); i++) {
        // Check if the 'su' file exists at this path
        if (access(su_paths[i], F_OK) == 0) {
            return JNI_FALSE; // Root detected, return false
        }
    }

    // Optional: check for debugger using ptrace
    // Disabled here, but could prevent tracing on i386 devices
    //#ifdef __i386__
    //    if (ptrace(PTRACE_TRACEME, 0, 1, 0) == -1) {
    //        return JNI_FALSE;
    //    }
    //#endif

    return JNI_TRUE; // No root indicators found, environment seems safe
}

/**
 * Function to check if Frida is listening on default TCP ports.
 * Frida is a common dynamic instrumentation tool used for reverse engineering.
 */
int checkFridaPorts() {
    // Open the system file that lists TCP connections
    FILE *f = fopen("/proc/net/tcp", "r");
    if (f == NULL) {
        return 0; // Cannot open the file, assume no Frida
    }

    char line[256]; // Buffer for each line in the file
    while (fgets(line, sizeof(line), f)) {
        // Check if the line contains Frida's default ports in hexadecimal (0x6A6A or 0x6A6B)
        if (strstr(line, "00006A6A") || strstr(line, "00006A6B")) {
            fclose(f);
            return 1; // Frida detected
        }
    }

    fclose(f); // Close file handle
    return 0;   // Frida not detected
}

/**
 * Function to scan /proc for running processes that may indicate Frida usage.
 * It iterates over all process directories and inspects their cmdline.
 */
int checkFridaProcesses() {
    // Open /proc directory
    DIR *dir = opendir("/proc");
    if (dir == NULL) {
        return 0; // Cannot open /proc, assume no Frida
    }

    struct dirent *entry; // Structure to hold directory entries
    while ((entry = readdir(dir)) != NULL) {
        // Skip non-directory entries and directories whose names are not numeric
        if (entry->d_type != DT_DIR || !isdigit(entry->d_name[0])) {
            continue;
        }

        // Build path to the cmdline file for this process
        char cmdlinePath[256];
        snprintf(cmdlinePath, sizeof(cmdlinePath), "/proc/%s/cmdline", entry->d_name);

        // Open the cmdline file
        FILE *cmdline = fopen(cmdlinePath, "r");
        if (cmdline) {
            char cmdlineContent[256]; // Buffer to read cmdline
            fread(cmdlineContent, sizeof(char), sizeof(cmdlineContent) - 1, cmdline); // Read content
            fclose(cmdline); // Close file

            // Ensure null-termination
            cmdlineContent[sizeof(cmdlineContent) - 1] = '\0';

            // Check for known Frida-related keywords
            if (strstr(cmdlineContent, "frida") || strstr(cmdlineContent, "gum") ||
                strstr(cmdlineContent, "gvfs")) {
                closedir(dir);
                return 1; // Frida detected
            }
        }
    }

    closedir(dir); // Close /proc directory
    return 0;      // Frida not detected
}

/**
 * JNI function init1
 * Checks for Frida by inspecting ports and processes.
 * Returns JNI_TRUE if Frida is detected, JNI_FALSE otherwise.
 */
JNIEXPORT jboolean JNICALL
Java_glacier_ctf_icyslide_utils_IcySlideUtils_init1(JNIEnv *env, jobject obj) {
    if (checkFridaPorts() || checkFridaProcesses()) {
        return JNI_TRUE; // Frida detected
    }
    return JNI_FALSE;    // Frida not detected
}

/**
 * JNI function to check the validity of a provided hash (signature).
 * This could be used to verify the integrity of resources or configurations.
 */
JNIEXPORT jboolean JNICALL
Java_glacier_ctf_icyslide_utils_IcySlideUtils_isSignatureValid(JNIEnv *env, jobject obj,
                                                               jstring hash) {
    // Convert the Java string to a C-style string
    const char *providedHash = (*env)->GetStringUTFChars(env, hash, 0);

    // Known SHA-256 hash value for comparison
    const char *knownHash = "";  // Replace with actual hash

    // Compare the provided hash with the known hash
    // Note: The comment indicates this doesn't fully work
    if (strcmp(providedHash, knownHash) != 0) {
        (*env)->ReleaseStringUTFChars(env, hash, providedHash); // Release memory
        return JNI_TRUE; // Currently returns true even if hashes mismatch
    }

    // Release memory for the provided string
    (*env)->ReleaseStringUTFChars(env, hash, providedHash);
    return JNI_TRUE; // Hash matches or function defaults to true
}
