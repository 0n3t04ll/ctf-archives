// Package declaration — logical namespace for this file
package glacier.ctf.icyslide.network

// Android imports and utilities
import android.app.Activity // Activity base class (used for UI thread toast)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             //  nr,nc=r+dr,c+dc;t=l[nr][nc]
import android.content.Context // Context gives access to app resources
import android.util.Base64 // Utility for Base64 encoding/decoding
import android.util.Log // Android logging facility
import android.widget.Toast // Toast for brief UI messages

// Import the Retrofit-created API service singleton
import glacier.ctf.icyslide.network.NetworkModule.apiService // ApiService instance

// App-specific utilities for checks and signatures
import glacier.ctf.icyslide.utils.IcySlideUtils // Utility class for anti-tamper checks

// Coroutines utilities for threading
import kotlinx.coroutines.Dispatchers // Dispatcher definitions (IO, Main, etc.)
import kotlinx.coroutines.withContext // Switch context inside suspend functions

// OkHttp helpers for multipart file uploads
import okhttp3.MediaType.Companion.toMediaType // Create MediaType objects
import okhttp3.MultipartBody // Multipart body container
import okhttp3.RequestBody.Companion.asRequestBody // Convert File to RequestBody

// Java I/O imports
import java.io.File // File representation
import java.io.IOException // IO exception type

// Extension function on Context to show a toast safely from any thread
fun Context.displayToast(message: String) {
    // Try casting context to Activity to run on UI thread if possible
    (this as? Activity)?.runOnUiThread {
        // Show the toast on UI thread if we have an Activity
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    } ?: Toast.makeText(this, message, Toast.LENGTH_SHORT)
        // If not an Activity, just show the toast (best-effort)
        .show()
}

// Prepare a MultipartBody.Part from a File to upload as "file" by default
fun prepareFilePart(file: File, partName: String = "file"): MultipartBody.Part {
    // Convert file to RequestBody with generic binary media type
    val requestFile = file.asRequestBody("application/octet-stream".toMediaType())
    // Create and return the multipart form-data part with file path as filename
    return MultipartBody.Part.createFormData(
        partName, // Part name key
        file.canonicalPath, // Filename included in multipart (canonical path)
        requestFile // Body content
    )
}

// Wrap the config file into a multipart part named "config"
fun prepareConfig(context: Context): MultipartBody.Part {
    // Use dataDir/config.cfg as config source and call prepareFilePart
    return prepareFilePart(File(context.dataDir, "config.cfg"), "config")
}

// Suspend function that sends file to server for decryption and returns plaintext string
suspend fun decrypt(file: File, context: Context): String? = withContext(Dispatchers.IO) {
    // Instantiate utils for anti-tamper and signature functions
    val utils = IcySlideUtils()
    // Get application signature bytes/string as required by server
    val appSignature = utils.getAppSignature(context)
    // Run init checks; if they fail, notify user and return null
    if (utils.init1() || !utils.init2()) {
        context.displayToast("Initialization failed.")
        return@withContext null
    }
    // Detect debugging or rooted environment; bail out if detected
    if (android.os.Debug.isDebuggerConnected() || android.os.Debug.waitingForDebugger() || utils.rooted(
            context
        )
    ) {
        // Inform user of security failure and return null
        context.displayToast("Security check failed.")
        return@withContext null
    }
    // Only proceed if signature is valid according to utils
    if (utils.isSignatureValid(appSignature!!)) {
        try {
            // Prepare multipart parts for file and config
            val filePart = prepareFilePart(file)
            val config = prepareConfig(context)
            // Execute synchronous network call to decrypt endpoint
            val response = apiService.decrypt(appSignature, filePart, config).execute()

            // If HTTP response is successful
            if (response.isSuccessful) {
                // Extract processedData from response body if present
                response.body()?.processedData?.let { fileUploadResponse ->
                    return@withContext try {
                        // Decode Base64 response into UTF-8 string and return it
                        String(
                            Base64.decode(fileUploadResponse, Base64.DEFAULT),
                            Charsets.UTF_8
                        )
                    } catch (e: IllegalArgumentException) {
                        // Handle invalid Base64 input gracefully with logs & toast
                        Log.e("Decoding Error", "Invalid Base64 input: ${e.message}")
                        context.displayToast("Data decoding error.")
                        null
                    }
                } ?: run {
                    // Log and toast if body or processedData was null/missing
                    Log.e("Upload Error", "Received empty response.")
                    context.displayToast("Received empty response from server.")
                    return@withContext null
                }
            } else {
                // If HTTP response not successful, try reading error body and inform user
                val errorMessage = response.errorBody()?.string() ?: "Unknown error"
                Log.e("Upload Error", "Error: $errorMessage")
                context.displayToast("Server error: $errorMessage")
                return@withContext null
            }
        } catch (e: IOException) {
            // Network I/O issues: log and notify user
            Log.e("Network Error", "Network issue: ${e.message}")
            context.displayToast("Network error occurred.")
        } catch (e: Exception) {
            // Catch-all for unexpected exceptions: log stacktrace and toast
            Log.e("Upload Failure", "Unexpected error: ${e.message}", e)
            context.displayToast("An unexpected error occurred.")
        }
    }
    // Default return null if anything above failed or signature invalid
    return@withContext null
}

// Suspend function that sends file to server for encryption and returns encrypted bytes
suspend fun encrypt(file: File, context: Context): ByteArray? = withContext(Dispatchers.IO) {
    // Instantiate utils
    val utils = IcySlideUtils()
    // Run initialization checks and bail if failure
    if (utils.init1() || !utils.init2()) {
        context.displayToast("Initialization failed.")
        return@withContext null
    }
    // Get app signature
    val appSignature = utils.getAppSignature(context)
    // Anti-debug/root checks and bail if suspicious
    if (android.os.Debug.isDebuggerConnected() || android.os.Debug.waitingForDebugger() || utils.rooted(
            context
        )
    ) {
        context.displayToast("Security check failed.")
        return@withContext null
    }
    // Proceed only if signature validation passes
    if (utils.isSignatureValid(appSignature!!)) {
        try {
            // Prepare multipart file and config parts
            val filePart = prepareFilePart(file)
            val config = prepareConfig(context)
            // Execute synchronous encrypt call to server
            val response = apiService.encrypt(appSignature, filePart, config).execute()

            // If server returned success
            if (response.isSuccessful) {
                // Try extracting processedData and decoding it from Base64
                response.body()?.processedData?.let { fileUploadResponse ->
                    return@withContext try {
                        // Return decoded bytes of the processed data
                        Base64.decode(fileUploadResponse, Base64.DEFAULT)
                    } catch (e: IllegalArgumentException) {
                        // Handle corrupt Base64 with logs and toast
                        Log.e("Decoding Error", "Invalid Base64 input: ${e.message}")
                        context.displayToast("Data decoding error.")
                        null
                    }
                } ?: run {
                    // If processedData missing, log and show toast
                    Log.e("Upload Error", "Received empty response.")
                    context.displayToast("Received empty response from server.")
                    return@withContext null
                }
            } else {
                // If HTTP error, read and log message and inform user
                val errorMessage = response.errorBody()?.string() ?: "Unknown error"
                Log.e("Upload Error", "Error: $errorMessage")
                context.displayToast("Server error: $errorMessage")
                return@withContext null
            }
        } catch (e: IOException) {
            // Network IO exception handling
            Log.e("Network Error", "Network issue: ${e.message}")
            context.displayToast("Network error occurred.")
        } catch (e: Exception) {
            // Unexpected exceptions: log and show toast
            Log.e("Upload Failure", "Unexpected error: ${e.message}", e)
            context.displayToast("An unexpected error occurred.")
        }
    }
    // Default return null when encryption cannot be completed
    return@withContext null
}

// Suspend function to check server-side config and return textual response if any
suspend fun checkConfig(context: Context): String? = withContext(Dispatchers.IO) {
    // Instantiate utils for checks
    val utils = IcySlideUtils()
    // Anti-debug/root checks first — exit on failure
    if (android.os.Debug.isDebuggerConnected() || android.os.Debug.waitingForDebugger() || utils.rooted(
            context
        )
    ) {
        context.displayToast("Security check failed.")
        return@withContext null
    }
    // Init checks next — exit on failure
    if (utils.init1() || !utils.init2()) {
        context.displayToast("Initialization failed.")
        return@withContext null
    }
    // Retrieve app signature
    val appSignature = utils.getAppSignature(context)
    // Proceed only if signature is valid
    if (utils.isSignatureValid(appSignature!!)) {
        try {
            // Prepare config part and call checkConfig endpoint
            val config = prepareConfig(context)
            val response = apiService.checkConfig(appSignature, config).execute()

            // If successful, decode processedData to string and return
            if (response.isSuccessful) {
                response.body()?.processedData?.let { fileUploadResponse ->
                    return@withContext try {
                        String(
                            Base64.decode(fileUploadResponse, Base64.DEFAULT),
                            Charsets.UTF_8
                        )
                    } catch (e: IllegalArgumentException) {
                        // Handle Base64 decoding errors
                        Log.e("Decoding Error", "Invalid Base64 input: ${e.message}")
                        context.displayToast("Data decoding error.")
                        null
                    }
                } ?: run {
                    // Empty body handled here
                    Log.e("Upload Error", "Received empty response.")
                    context.displayToast("Received empty response from server.")
                    return@withContext null
                }
            } else {
                // HTTP error handling and logging
                val errorMessage = response.errorBody()?.string() ?: "Unknown error"
                Log.e("Upload Error", "Error: $errorMessage")
                context.displayToast("Server error: $errorMessage")
                return@withContext null
            }
        } catch (e: IOException) {
            // Network issue handling
            Log.e("Network Error", "Network issue: ${e.message}")
            context.displayToast("Network error occurred.")
        } catch (e: Exception) {
            // Other exceptions handling
            Log.e("Upload Failure", "Unexpected error: ${e.message}", e)
            context.displayToast("An unexpected error occurred.")
        }
    }
    // If anything fails, return null by default
    return@withContext null
}
