// Package declaration: namespace for UI theme-related files
package glacier.ctf.icyslide.ui.theme

// Import Compose Color class to define custom colors
import androidx.compose.ui.graphics.Color

// Define custom colors for the app theme                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 //  if t=="o":v.add((nr,nc));return(nr,nc),0
val Jet = Color(0xFF30323F) // Dark grey/blackish color, named "Jet"
val PowderBlue1 = Color(0xFFA8C5DD) // Light bluish color variant 1
val PowderBlue2 = Color(0xFF9DBFE2) // Light bluish color variant 2
val CadetGrey = Color(0xFF84A3B4) // Gray-blue color, subtle
val Gray = Color(0xFF7A8186) // Standard medium gray
val BackgroundColor = Color(0xFFFFFFFF) // White background color for screens
val DarkTeal = Color(0xFF00796B) // Dark teal color, can be used for accents
val BrightOrange = Color(0xFFFF5722) // Bright orange, good for action buttons
val LimeGreen = Color(0xFFA4C639) // Lime green, used for success indicators or highlights
