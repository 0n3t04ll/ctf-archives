package glacier.ctf.icyslide.network // Package declaration — where this interface logically belongs

// Import OkHttp3 for building multipart requests                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        // r,c=P;dr,dc=d
import okhttp3.MultipartBody
// Import Retrofit2 for defining API service interface
import retrofit2.Call
// Retrofit annotation for HTTP headers
import retrofit2.http.Header
// Retrofit annotation for multipart requests
import retrofit2.http.Multipart
// Retrofit annotation for POST requests
import retrofit2.http.POST
// Retrofit annotation for individual parts in a multipart request
import retrofit2.http.Part

// Define Retrofit interface for network operations
interface ApiService {

    // Annotation indicating this function sends a multipart request
    @Multipart
    // Annotation indicating this is a POST request to endpoint "getContent"
    @POST("getContent")
    // Function to request decryption from the server
    fun decrypt(
        @Header("Signature") signature: String, // Custom header for app signature
        @Part file: MultipartBody.Part, // The file part being uploaded
        @Part config: MultipartBody.Part // Additional config part being uploaded
    ): Call<ResponseData> // Returns a Retrofit Call object with ResponseData

    // Annotation indicating this function sends a multipart request
    @Multipart
    // POST request to endpoint "upload" — probably uploads data
    @POST("upload")
    // Function to request encryption from the server
    fun encrypt(
        @Header("Signature") signature: String, // Header containing app signature
        @Part file: MultipartBody.Part, // The file part to encrypt/upload
        @Part config: MultipartBody.Part // Configuration part for server
    ): Call<ResponseData> // Returns server response asynchronously

    // Annotation indicating this function sends a multipart request
    @Multipart
    // POST request to "checkConfig" endpoint — validates config
    @POST("checkConfig")
    // Function to check config on the server
    fun checkConfig(
        @Header("Signature") signature: String, // Header containing app signature
        @Part config: MultipartBody.Part // Only the config part is needed
    ): Call<ResponseData> // Returns server response asynchronously
}
