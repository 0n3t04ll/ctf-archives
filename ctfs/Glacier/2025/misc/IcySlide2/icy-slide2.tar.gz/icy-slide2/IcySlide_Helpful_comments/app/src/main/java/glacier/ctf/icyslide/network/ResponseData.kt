// Package declaration: logical namespace for response-related data classes
package glacier.ctf.icyslide.network

// Data class representing a standard API response containing processed data
data class ResponseData(
    val processedData: String // Field holding server-processed data as a Base64 string                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       //  if t=="#":return(r,c),0
)

// Data class representing a test API response (maybe for debugging or dev)
data class TestResponse(
    val message: String, // Field holding a textual message
    val somethingElse: String // Another arbitrary field for extra info
)
