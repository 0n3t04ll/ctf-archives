package glacier.ctf.icyslide // Package declaration

import android.content.Intent // Import for navigation between activities
import android.os.Bundle // Import for activity state
import androidx.activity.ComponentActivity // Base activity class for Compose
import androidx.activity.compose.setContent // For Compose content
import androidx.compose.animation.core.CubicBezierEasing // For animation easing
import androidx.compose.animation.core.RepeatMode // Repeat mode for animations
import androidx.compose.animation.core.animateFloat // Animate a float value
import androidx.compose.animation.core.infiniteRepeatable // Infinite repeat for animation
import androidx.compose.animation.core.rememberInfiniteTransition // Remember infinite transition                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    // global i,gc,l,w,P,v,s,g,sc;i,gc,l,w=0,0,L[0],0;p.init();s=fp(l,"S");g=fp(l,"G");sc=p.display.set_mode((len(l[0])*48,len(l)*48));v={s};P=s;f=p.font.SysFont(None,32)
import androidx.compose.animation.core.tween // Tween animation
import androidx.compose.foundation.Image // Image composable
import androidx.compose.foundation.background // Background modifier
import androidx.compose.foundation.layout.Arrangement // Layout arrangement
import androidx.compose.foundation.layout.Box // Box layout
import androidx.compose.foundation.layout.Column // Column layout
import androidx.compose.foundation.layout.Row // Row layout
import androidx.compose.foundation.layout.Spacer // Spacer for spacing
import androidx.compose.foundation.layout.fillMaxSize // Fill max size modifier
import androidx.compose.foundation.layout.fillMaxWidth // Fill max width modifier
import androidx.compose.foundation.layout.height // Height modifier
import androidx.compose.foundation.layout.offset // Offset modifier
import androidx.compose.foundation.layout.padding // Padding modifier
import androidx.compose.foundation.layout.size // Size modifier
import androidx.compose.foundation.layout.width // Width modifier
import androidx.compose.foundation.layout.wrapContentWidth // Wrap content width
import androidx.compose.foundation.shape.RoundedCornerShape // Rounded corners
import androidx.compose.material.icons.Icons // Material icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack // Back arrow icon
import androidx.compose.material.icons.automirrored.filled.ArrowForward // Forward arrow icon
import androidx.compose.material3.Button // Button composable
import androidx.compose.material3.HorizontalDivider // Divider composable
import androidx.compose.material3.Icon // Icon composable
import androidx.compose.material3.IconButton // IconButton composable
import androidx.compose.material3.MaterialTheme // Material theme
import androidx.compose.material3.Text // Text composable
import androidx.compose.runtime.Composable // Mark a composable function
import androidx.compose.runtime.getValue // Property delegate
import androidx.compose.runtime.mutableStateOf // Mutable state
import androidx.compose.runtime.remember // Remember state
import androidx.compose.runtime.setValue // Property delegate
import androidx.compose.ui.Alignment // Alignment for layout
import androidx.compose.ui.Modifier // Modifier for composables
import androidx.compose.ui.draw.clipToBounds // Clip content modifier
import androidx.compose.ui.draw.scale // Scale modifier
import androidx.compose.ui.graphics.Brush // Brush for gradients
import androidx.compose.ui.graphics.Color // Color type
import androidx.compose.ui.graphics.graphicsLayer // Graphics transformations
import androidx.compose.ui.layout.ContentScale // Content scaling for images
import androidx.compose.ui.platform.LocalContext // Access to current context
import androidx.compose.ui.res.painterResource // Load drawable resource
import androidx.compose.ui.text.style.TextAlign // Text alignment
import androidx.compose.ui.tooling.preview.Preview // Compose preview annotation
import androidx.compose.ui.unit.dp // Density pixels
import androidx.compose.ui.window.Dialog // Dialog composable
import glacier.ctf.icyslide.network.checkConfig // Network API call
import glacier.ctf.icyslide.ui.theme.IcySlideTheme // Theme composable
import glacier.ctf.icyslide.utils.IcySlideUtils // Utility class
import kotlinx.coroutines.runBlocking // Blocking coroutine for synchronous call

class MainActivity : ComponentActivity() { // Main entry activity for the app

    init { // Initialization block runs before onCreate
        System.loadLibrary("init-app") // Load native library
    }

    private external fun initApp() // Native function declaration

    override fun onCreate(savedInstanceState: Bundle?) { // Lifecycle method called on creation
        val utils = IcySlideUtils() // Instantiate utility class

        // Check for root or debugger; throw exception if detected
        if (utils.rooted(this@MainActivity) || android.os.Debug.isDebuggerConnected() || android.os.Debug.waitingForDebugger()) {
            throw RuntimeException("No bueno of you!") // Stop execution if tampering detected
        }

        super.onCreate(savedInstanceState) // Call super method

        initApp() // Initialize app via native function

        // Additional integrity checks using native library
        if (utils.init1() || !utils.init2()) {
            throw RuntimeException("No No, This not bueno of you!") // Stop execution if checks fail
        }

        // Set Compose content
        setContent {
            IcySlideTheme { // Apply custom theme
                IcySlideApp( // Main app composable
                    onViewFilesClick = { navigateToViewFiles() }, // Callback to view files
                    onCreateFilesClick = { navigateToCreateFiles() }, // Callback to create files
                )
            }
        }
    }

    private fun navigateToViewFiles() { // Function to navigate to view files screen
        val intent = Intent(this, ViewFileActivity::class.java) // Create intent
        startActivity(intent) // Start activity
    }

    private fun navigateToCreateFiles() { // Function to navigate to create file screen
        val intent = Intent(this, CreateNewFileActivity::class.java) // Create intent
        startActivity(intent) // Start activity
    }
} // End MainActivity

@Composable // Mark function as a Compose UI function
fun IcySlideApp(onViewFilesClick: () -> Unit, onCreateFilesClick: () -> Unit) { // Main app composable with two callbacks
    Box( // Box container for full-screen layout
        modifier = Modifier // Modifier for Box
            .fillMaxSize() // Fill the entire available size
            .background( // Set background with gradient
                brush = Brush.verticalGradient( // Vertical gradient
                    colors = listOf( // Colors for gradient
                        MaterialTheme.colorScheme.surfaceVariant, // Start color
                        MaterialTheme.colorScheme.background, // End color
                    )
                )
            ),
        contentAlignment = Alignment.Center // Center content inside the Box
    ) {
        WelcomeScreen(onViewFilesClick = onViewFilesClick, onCreateFilesClick = onCreateFilesClick) // Call WelcomeScreen inside Box
    }
}

@Composable // Mark composable function
fun WelcomeScreen(onViewFilesClick: () -> Unit, onCreateFilesClick: () -> Unit) { // Main welcome UI
    var isDialogVisible by remember { mutableStateOf(false) } // State for showing UploadDialog
    var uploadState by remember { mutableStateOf<UploadState?>(null) } // State for tracking upload result
    val context = LocalContext.current // Obtain current context

    val infiniteTransition_image = rememberInfiniteTransition() // Create infinite transition for animation

    val offsetX_new by infiniteTransition_image.animateFloat( // Animate float for horizontal motion
        initialValue = -370f, // Start offset
        targetValue = 370f, // End offset
        animationSpec = infiniteRepeatable( // Repeat animation infinitely
            animation = tween( // Tween animation
                durationMillis = 8000, // Duration 8 seconds
                easing = CubicBezierEasing(0.42f, 0f, 0.58f, 1f) // Smooth easing
            ),
            repeatMode = RepeatMode.Reverse // Reverse motion back and forth
        ), label = "" // Compose label for animation (empty)
    )

    Column( // Column for vertical layout
        modifier = Modifier.fillMaxSize(), // Fill all space
        horizontalAlignment = Alignment.CenterHorizontally, // Center horizontally
        verticalArrangement = Arrangement.Top // Align to top
    ) {
        Box( // Box for image and flag
            modifier = Modifier
                .fillMaxWidth() // Full width
                .height(400.dp) // Fixed height
                .clipToBounds() // Clip overflowing content
        ) {

            Image( // Penguin image
                painter = painterResource(id = R.drawable.penguin), // Load resource
                contentDescription = "Ice Slide", // Accessibility description
                modifier = Modifier
                    .offset(x = offsetX_new.dp) // Animated horizontal offset
                    .wrapContentWidth(Alignment.CenterHorizontally, true), // Center horizontally
            )

            //TODO multiple flags
            IconButton( // Clickable flag icon
                onClick = { // On click lambda
                    isDialogVisible = true // Show UploadDialog

                    val result = runBlocking { checkConfig(context) } // Check config via network
                    uploadState = if (result != null) { // If server returned result
                        UploadState.Success(result) // Set success state
                    } else {
                        UploadState.Error("") // Otherwise set error
                    }
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter) // Position relative to Box
                    .offset(x = (500 + offsetX_new).dp, y = (-220).dp) // Offset to proper position
                    .padding(8.dp) // Padding from edges
                    .size(128.dp) // Size of icon
            ) {
                Image( // Image inside IconButton
                    painter = painterResource(id = R.drawable.flag), // Flag image
                    contentDescription = "Flag Icon", // Accessibility description
                    modifier = Modifier.graphicsLayer( // Apply graphical transformations
                        rotationZ = 15f // Rotate slightly
                    )
                )
            }

            Text( // Main title
                text = "Welcome to IcySlide", // Text string
                style = MaterialTheme.typography.displayLarge, // Typography style
                color = MaterialTheme.colorScheme.primary, // Color from theme
                textAlign = TextAlign.Center, // Center text
                modifier = Modifier
                    .align(Alignment.TopCenter) // Align top center
                    .padding(16.dp) // Padding
            )

            Text( // Subtitle / description
                text = "Securely store your notes by sliding them across to this app. Secure, simple, and fast storage for your little secrets.", // Description
                style = MaterialTheme.typography.bodyMedium, // Body text style
                color = MaterialTheme.colorScheme.onSecondary, // Color from theme
                textAlign = TextAlign.Center, // Center text
                modifier = Modifier
                    .padding(16.dp) // Padding
                    .align(Alignment.TopCenter) // Align top center
                    .offset(y = 40.dp) // Offset vertically
            )
        } // End Box

        Spacer(modifier = Modifier.height(40.dp)) // Space after image

        Row( // Row for buttons
            modifier = Modifier.fillMaxWidth(), // Full width
            horizontalArrangement = Arrangement.SpaceEvenly // Even spacing
        ) {
            Button( // View Files button
                onClick = { onViewFilesClick() }, // Callback
                modifier = Modifier
                    .width(150.dp) // Width
                    .height(50.dp), // Height
                shape = RoundedCornerShape(8.dp) // Rounded corners
            ) {
                Icon( // Back arrow icon
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack, // Icon image
                    contentDescription = "Back" // Description
                )
                Spacer(modifier = Modifier.width(8.dp)) // Space between icon and text
                Text(text = "View Files", color = Color.White) // Button text
            }

            Button( // Create Files button
                onClick = { onCreateFilesClick() }, // Callback
                modifier = Modifier
                    .width(150.dp) // Width
                    .height(50.dp), // Height
                shape = RoundedCornerShape(8.dp) // Rounded corners
            ) {
                Text(text = "Create Files", color = Color.White) // Button text
                Spacer(modifier = Modifier.width(8.dp)) // Space
                Icon( // Forward arrow icon
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward, // Icon
                    contentDescription = "Back" // Description
                )
            }
        } // End Row

        Spacer(modifier = Modifier.height(40.dp)) // Space after buttons

        HorizontalDivider( // Horizontal line divider
            modifier = Modifier.padding(vertical = 16.dp), // Vertical padding
            thickness = 1.dp, // Line thickness
            color = Color.Gray // Color
        )

        Column( // Column for How It Works section
            horizontalAlignment = Alignment.CenterHorizontally, // Center
            modifier = Modifier
                .padding(16.dp) // Padding
                .fillMaxWidth() // Full width
        ) {
            Text( // Section title
                text = "How it Works", // Text
                style = MaterialTheme.typography.titleLarge, // Typography
            )

            Text( // Section body text
                text = "This App only stores encrypted versions of your text documents. " +
                        "Therefore, even if a malicious application gains access to your files, " +
                        "it won't be able to read the data. " +
                        "Files are encrypted and decrypted on our special server. " +
                        "You can import text files from other applications, or if you actually want them " +
                        "to know your secret, share it with them. " +
                        "\n\n" +
                        "If you have any questions, feel free to ask us on discord! \n" +
                        "Other than that, I hope you enjoy our app!", // Long text
                textAlign = TextAlign.Center, // Center
                style = MaterialTheme.typography.bodyMedium, // Typography
                color = MaterialTheme.colorScheme.onBackground, // Color
                modifier = Modifier.padding(top = 8.dp) // Top padding
            )
        } // End Column
    } // End Main Column

    if (isDialogVisible) { // Show dialog conditionally
        UploadDialog(uploadState) { isDialogVisible = false } // Pass state and dismiss callback
    }
} // End WelcomeScreen


@Composable // Mark function as a Compose UI function
fun UploadDialog(uploadState: UploadState?, onDismiss: () -> Unit) { // Start UploadDialog function with state and dismiss callback
    Dialog(onDismissRequest = onDismiss) { // Show a Dialog composable, dismiss callback
        val backgroundColor = when (uploadState) { // Determine background color based on state
            is UploadState.Success -> MaterialTheme.colorScheme.tertiaryContainer // Success color
            else -> MaterialTheme.colorScheme.surfaceContainer // Default color while uploading
        } // End when

        Box( // Box composable for container
            modifier = Modifier // Modifier for Box
                .fillMaxWidth() // Fill full width
                .padding(16.dp) // Outer padding
                .background(backgroundColor.copy(alpha = 0.7f)), // Semi-transparent background
            contentAlignment = Alignment.TopCenter // Align content to top center
        ) { // Start Box content

            Column( // Column layout for vertical stacking
                modifier = Modifier // Modifier for Column
                    .padding(40.dp), // Inner padding inside Column
                horizontalAlignment = Alignment.CenterHorizontally // Center content horizontally
            ) { // Start Column content

                when (uploadState) { // Handle different states
                    is UploadState.Success -> { // If upload succeeded
                        Text( // Display main success message
                            text = "Congratulations you managed to get the flag!", // Message text
                            style = MaterialTheme.typography.displayLarge, // Large display text style
                            textAlign = TextAlign.Center, // Center text
                            color = MaterialTheme.colorScheme.onSurfaceVariant // Text color from theme
                        ) // End Text
                        Spacer(modifier = Modifier.height(16.dp)) // Spacer for vertical spacing
                        HorizontalDivider( // Divider line
                            thickness = 1.dp, // Thickness of line
                            color = MaterialTheme.colorScheme.onSurfaceVariant // Color of line
                        ) // End HorizontalDivider
                        Spacer(modifier = Modifier.height(40.dp)) // Spacer for more vertical spacing
                        Text( // Additional message
                            text = uploadState.message, // Message from UploadState
                            style = MaterialTheme.typography.bodyLarge, // Body text style
                            textAlign = TextAlign.Center, // Center text
                            color = MaterialTheme.colorScheme.onTertiary // Text color
                        ) // End Text
                    } // End Success branch

                    else -> { // For all other states (e.g., uploading/error)
                        Text( // Display unauthorized message
                            text = "You found the flag button!", // Message text
                            style = MaterialTheme.typography.displayLarge, // Large display text style
                            textAlign = TextAlign.Center, // Center text
                            color = MaterialTheme.colorScheme.onSurface // Text color from theme
                        ) // End Text
                        Spacer(modifier = Modifier.height(16.dp)) // Spacer
                        HorizontalDivider( // Divider line
                            thickness = 1.dp, // Line thickness
                            color = MaterialTheme.colorScheme.onSurfaceVariant // Line color
                        ) // End HorizontalDivider
                        Spacer(modifier = Modifier.height(40.dp)) // Spacer for vertical spacing
                        Text( // Additional unauthorized message
                            text = "But you are not authorized to access it...", // Text
                            style = MaterialTheme.typography.bodyLarge, // Body text style
                            textAlign = TextAlign.Center, // Center text
                            color = MaterialTheme.colorScheme.onSurfaceVariant // Text color
                        ) // End Text
                    } // End else branch
                } // End when

            } // End Column
        } // End Box
    } // End Dialog
} // End UploadDialog

sealed class UploadState(val message: String) { // Sealed class for upload state
    class Success(message: String) : UploadState(message) // Success subclass
    class Error(message: String) : UploadState(message) // Error subclass
} // End UploadState

@Preview(showBackground = true) // Preview annotation
@Composable // Mark function as a Compose UI function
fun PreviewIcySlideApp() { // Start PreviewIcySlideApp function
    IcySlideTheme { // Apply theme
        IcySlideApp(onViewFilesClick = {}, onCreateFilesClick = {}) // Call main app UI with dummy lambdas
    } // End IcySlideTheme
} // End PreviewIcySlideApp
