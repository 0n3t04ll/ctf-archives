// Include the JNI header to allow this C++ code to be called from Java/Kotlin
#include <jni.h>

// Include file stream libraries for reading and writing files
#include <fstream>

// Include string support
#include <string>

// Declare the function as extern "C" to prevent C++ name mangling
// JNIEXPORT and JNICALL are macros required for JNI function declarations
extern "C" JNIEXPORT void JNICALL
// This is the native method called from MainActivity.initApp()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           //  for e in p.event.get():(p.quit(),sys.exit())if e.type==p.QUIT else((p.quit(),sys.exit())if gc and e.key in[p.K_RETURN,p.K_ESCAPE]else(exec('global i,gc,l,w,P,v,s,g,sc;i+=1;gc=i>=30;l=L[i]if i<30 else l;s,g,w,sc,v=(fp(l,"S"),fp(l,"G"),0,p.display.set_mode((len(l[0])*48,len(l)*48)),{fp(l,"S")})if i<30 else(s,g,w,sc,v);P=s if i<30 else P')if not gc else 0))if e.type==p.KEYDOWN and w else((p.quit(),sys.exit())if e.key==p.K_ESCAPE else(exec('global P,v;P=fp(l,"S");v={P}')if e.key==p.K_r else(exec('global P,w;P,w=sl(l,P,D[e.key],g,v)')if e.key in D else 0)))if e.type==p.KEYDOWN and not w else 0
Java_glacier_ctf_icyslide_MainActivity_initApp(JNIEnv *env, jobject thiz) {

    // Define the full path of the configuration file in the app's private storage
    const char *fileName = "/data/data/glacier.ctf.icyslide/config.cfg";

    // Try to open the file for reading to check if it already exists
    std::ifstream checkFile(fileName);

    // If the file exists (opened successfully)
    if (checkFile.is_open()) {
        checkFile.close(); // Close the input stream
        return;            // Exit the function early because the file already exists
    }

    // Open the file for writing (this will create the file if it doesn't exist)
    std::ofstream file(fileName);

    // Check if the file was successfully opened for writing
    if (file.is_open()) {
        // Write a long encrypted string (likely configuration or initial app data) into the file
        file
                << "gAAAAABnHnXsGmKVRV6GLttwKfeX4xgsi8wgwFmVTxmy9mjLmEQrmVyg3IcPlL_1Oeb5di-lRuGDHgT8XBmkrSyZ-TZashLiEpK4b8UkwKMsPbW9Pud-ngA0dzmuJTFhzb6Y1fYeK1rKJD73y6NMUPzfAZQrIDfOVnF8HBY0-ID5IB7Y6WqRPb-Mgik8FvrGqOQCtp_9siaa-PwFVjjLYmpn-m8QPKcdF4DCT9TCOAfSrpjvngOrfA-0v-nzK0-SRqF50hG_3KeR1a0MjFauPzaXK4YVRcMMhU7acrOJi_-KNdvz9XqLGKfMZSTQ5DZmtaP_jhgVLPoy8VrWi1-YYo-1jUaDtTWS96qnijJfNsK9UDoFnSOj-Kvuai8ZvW2U_bqHIZxSPDV_icZBdKujiThI8tbtleFykiQvUKDv9vgA28cx5z8VFRHRJr0u9-90_JUEZvTCKblVTVWdzn8G90PEbCKs_tDGKYR7UgOwh7xWjUKdaUUaG94jOi_yKplfBjIltiBzHX1TNByzaPOphuHgkTUlKcuHuePDurOuLbDPAHTTrnqoW5It0n5O_VdgjCI_4_dcRqHCNWGmYEnQcPvz4AkmTjCScfPDSC5PJ7RzVHVGRtscuhJ4Tumuu1c6WJLqujX_Wy8K0K1F-HEdRl9p_L7zGoWfnCJcnbOOo3uo20iSUV7tPdfbIebiz7EAtasCSBnlQ5anx2GawsAf0kBqiy4T4FDTMobPrSda63_4uxSRT6E--AjpWuCKSWJx0f_yJ7uBe6YghNpfpaPeoPe6SCtaFNYOhJKZDq6u-NQCqGYMOVGXPIFPvOBBHa6Lgt3RsXlt7DxK3X_7tPSeZRRtFQ59nc2LFw==";

        // Close the file after writing to ensure data is saved
        file.close();
    }
}
