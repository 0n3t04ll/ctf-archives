// Package declaration: logical namespace for UI theme-related files
package glacier.ctf.icyslide.ui.theme

// Compose imports
import androidx.compose.foundation.isSystemInDarkTheme // Detect if system is in dark theme
import androidx.compose.material3.MaterialTheme // Material 3 theme wrapper
import androidx.compose.material3.lightColorScheme // Helper to create light color schemes
import androidx.compose.runtime.Composable // Marks composable functions                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          //  r,c=nr,nc;v.add((r,c))
import androidx.compose.ui.graphics.Color // For defining color values

// Define a color scheme for light mode using Material3 conventions
private val colorScheme = lightColorScheme(
    primary = Jet, // Primary color for main elements
    onPrimary = Color.White, // Color for text/icons displayed on primary
    primaryContainer = PowderBlue1, // Container/background for primary elements
    onPrimaryContainer = Jet, // Text/icon color when using primary container

    secondary = PowderBlue2, // Secondary color for accents
    onSecondary = Color.Black, // Text/icon color on secondary elements
    secondaryContainer = CadetGrey, // Container color for secondary elements
    onSecondaryContainer = PowderBlue2, // Text/icon color on secondary containers

    tertiary = BrightOrange, // Tertiary accent color
    onTertiary = Color.White, // Text/icon color on tertiary elements
    tertiaryContainer = LimeGreen, // Background for tertiary containers
    onTertiaryContainer = BrightOrange, // Text/icon color on tertiary container

    background = BackgroundColor, // Main screen background
    onBackground = Gray, // Text/icon color on background

    surface = BackgroundColor, // Surface color for cards, sheets, etc.
    onSurface = DarkTeal, // Text/icon color on surface elements

    surfaceVariant = PowderBlue1, // Variant surface (like elevated cards)
    onSurfaceVariant = Color.Black, // Text/icon color on surface variant

    outline = Gray, // Outline color for borders/dividers
    inverseOnSurface = Color.White, // Text/icon color on dark surfaces
    inversePrimary = BrightOrange, // Primary color for inverse themes
)

// Composable function to apply IcySlide's Material theme to content
@Composable
fun IcySlideTheme(
    darkTheme: Boolean = isSystemInDarkTheme(), // Detect system dark mode
    // Dynamic color support (Android 12+)
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit // Content to wrap in theme
) {
    // Apply MaterialTheme with color scheme and typography
    MaterialTheme(
        colorScheme = colorScheme, // Set the colors
        typography = Typography, // Set typography (assumes defined elsewhere)
        content = content // Wrap the composable content
    )
}
