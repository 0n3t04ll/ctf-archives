package glacier.ctf.icyslide.externalaccess // Define package name (where this file logically belongs)
// Import Android and Compose essentials                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        //def sl(l,P,d,g,v):
import android.content.Intent // For handling intents
import android.database.Cursor // To navigate query results
import android.net.Uri // For handling URIs
import android.os.Bundle // To access saved instance state
import android.provider.OpenableColumns // Constants for querying file names
import androidx.activity.ComponentActivity // Base activity for Compose
import androidx.activity.compose.setContent // For setting the Compose UI content
import androidx.compose.foundation.layout.Box // Container for layout
import androidx.compose.foundation.layout.Column // Vertical layout
import androidx.compose.foundation.layout.Spacer // Adds vertical space
import androidx.compose.foundation.layout.fillMaxSize // Modifier to fill entire screen
import androidx.compose.foundation.layout.height // Modifier for fixed height
import androidx.compose.foundation.layout.padding // Modifier for padding
import androidx.compose.material3.Button // Material 3 Button
import androidx.compose.material3.Text // Material 3 Text
import androidx.compose.runtime.Composable // Marks a composable function
import androidx.compose.ui.Alignment // For aligning child elements
import androidx.compose.ui.Modifier // Used to modify composable layout
import androidx.compose.ui.unit.dp // For defining density-independent pixels
import androidx.compose.ui.unit.sp // For font sizes
import glacier.ctf.icyslide.network.encrypt // Custom encryption method
import glacier.ctf.icyslide.ui.theme.IcySlideTheme // App's theme styling
import glacier.ctf.icyslide.utils.IcySlideUtils // Utility class with anti-debug/root checks
import kotlinx.coroutines.runBlocking // Runs suspend functions in a blocking way
import java.io.File // For file handling
import java.io.IOException // For catching IO exceptions

// Define an Activity that acts as a target for file sharing
class SlideShareTarget : ComponentActivity() {

    // Called when the activity is created
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Always call superclass method
        handleIncomingIntent(intent) // Process whatever intent started the activity
    }

    // Function to handle the incoming share intent
    private fun handleIncomingIntent(intent: Intent) {
        // Check if the intent action is ACTION_SEND and has a valid type
        if (Intent.ACTION_SEND == intent.action && intent.type != null) {
            // Handle plain text type (could also be file paths depending on sender)
            if ("text/plain" == intent.type) {
                // Try to extract URI from the intent
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { uri ->
                    saveFileToInternalStorage(uri) // Process the received URI
                } ?: run {
                    // If no URI provided, show an error
                    showError("No file URI provided.")
                }
            } else {
                // Unsupported MIME type (anything not plain text)
                showError("Unsupported file type.")
            }
        } else {
            // If intent action doesn’t match expected one
            showError("Invalid intent action.")
        }
    }

    // Helper function to show an error message using Compose UI
    private fun showError(message: String) {
        // Replace content with an error screen
        setContent {
            FileReceivedScreen(success = false, errorMessage = message)
        }
    }

    // Main function to copy, validate, encrypt, and save received file
    private fun saveFileToInternalStorage(uri: Uri) {
        try {
            // Try opening an input stream from the received URI
            contentResolver.openInputStream(uri)?.use { inputStream ->
                var fileName: String? = null // Placeholder for file name

                // Try querying metadata for the file name
                val cursor: Cursor? = contentResolver.query(uri, null, null, null, null)

                // Use the cursor safely
                cursor?.use {
                    if (it.moveToFirst()) { // Move to first (and only) result
                        val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME) // Get index of DISPLAY_NAME
                        if (nameIndex != -1) {
                            fileName = it.getString(nameIndex) // Extract actual file name
                        }
                    }
                }

                // If we couldn’t get a name, show an error
                if (fileName.isNullOrEmpty()) {
                    showError("Unable to retrieve file name.")
                    return // Abort early
                }

                // Create utility instance for security checks
                val utils = IcySlideUtils()
                // Perform anti-debugging and anti-rooting checks
                if (android.os.Debug.isDebuggerConnected() || android.os.Debug.waitingForDebugger() || utils.rooted(
                        this@SlideShareTarget
                    )
                ) {
                    showError("Please don't debug") // Warn and stop
                    return
                }

                // Run mysterious init checks (maybe anti-tamper)
                if (utils.init1() || !utils.init2()) {
                    showError("Unable to initialize") // Abort if failed
                    return
                }

                // Validate app signature (ensures code integrity)
                val appSignature = utils.getAppSignature(this@SlideShareTarget)
                if (!utils.isSignatureValid(appSignature!!)) {
                    return // Stop silently if invalid
                }

                // Prepare output file location in app's internal directory
                val outputFile = File(filesDir, fileName)
                var data: ByteArray? = null // Placeholder for encrypted data

                // Special handling if the file name matches config.cfg path
                if ("/data/data/glacier.ctf.icyslide/config.cfg".equals(outputFile.canonicalPath)) {
                    // Create a temporary file for this case
                    val tmpFile = File.createTempFile("receive_data", "tmp")
                    tmpFile.writeBytes(inputStream.readAllBytes()) // Copy input data to temp
                    data = runBlocking { encrypt(tmpFile, this@SlideShareTarget) } // Encrypt temp file
                    tmpFile.delete() // Clean up temp
                } else {
                    // Normal path — just write to destination first
                    outputFile.writeBytes(inputStream.readAllBytes()) // Write original data
                    data = runBlocking { encrypt(outputFile, this@SlideShareTarget) } // Encrypt file
                    if (data == null) {
                        outputFile.delete() // Delete file if encryption failed
                    }
                }

                // If encryption returned something valid, overwrite with encrypted data
                if (data != null)
                    outputFile.writeBytes(data)
                else {
                    showError("Received empty response from server!") // Encryption failed
                    return
                }

                // Finally, display success screen
                setContent {
                    FileReceivedScreen(success = true)
                }
            } ?: run {
                // If input stream couldn’t be opened at all
                showError("Unable to open input stream.")
            }
        } catch (e: IOException) {
            // Catch all file-related errors
            e.printStackTrace()
            showError("Error saving file: ${e.message}") // Display exception message
        }
    }

    // Composable function that renders a success or error screen
    @Composable
    fun FileReceivedScreen(success: Boolean, errorMessage: String? = null) {
        // Wrap everything inside the app's theme
        IcySlideTheme {
            // Create a full-screen box with padding
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center // Center content in the box
            ) {
                // Stack UI vertically
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // Display either success or error message
                    Text(
                        text = if (success) "File Saved Successfully!" else errorMessage
                            ?: "Error Saving File.",
                        fontSize = 24.sp // Large text
                    )
                    // Add vertical space
                    Spacer(modifier = Modifier.height(16.dp))
                    // Add a close button to finish the activity
                    Button(onClick = { finish() }) {
                        Text(text = "Close")
                    }
                }
            }
        }
    }
}
