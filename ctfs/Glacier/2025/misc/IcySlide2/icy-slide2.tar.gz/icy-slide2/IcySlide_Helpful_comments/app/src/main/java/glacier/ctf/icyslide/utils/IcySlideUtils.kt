// Package declaration: logical namespace for utility classes
package glacier.ctf.icyslide.utils

// Import Android Context class for app context usage
import android.content.Context
// Import PackageInfo to read package signing info
import android.content.pm.PackageInfo // Import PackageManager for flags like GET_SIGNING_CERTIFICATES
import android.content.pm.PackageManager
// Import Base64 utility for encoding binary signatures to text
import android.util.Base64
// Import RootBeer library for root detection
import com.scottyab.rootbeer.RootBeer
// Import MessageDigest for computing SHA digests
import java.security.MessageDigest

// Define a utility class used across the app for integrity / anti-tamper checks
class IcySlideUtils {
    // init block runs when an instance of IcySlideUtils is created
    init {
        // Load the native library named "integrity-app" (JNI/C native code expected)
        System.loadLibrary("integrity-app")
    }

    // Declare an external (native) function init1 which returns a Boolean
    external fun init1(): Boolean
    // Declare an external (native) function init2 which returns a Boolean
    external fun init2(): Boolean
    // Declare an external (native) function isSignatureValid which takes a hash and returns Boolean
    external fun isSignatureValid(hash: String): Boolean

    // Compute and return the app signature as a Base64-encoded SHA digest, or null on error
    fun getAppSignature(context: Context): String? {
        return try {
            // Retrieve PackageInfo including signing certificates for this package
            val packageInfo: PackageInfo = context.packageManager.getPackageInfo(
                context.packageName, // The package name of the current app
                PackageManager.GET_SIGNING_CERTIFICATES // Flag to include signing certs
            )
            // Extract the APK signing contents signers (array of signatures)
            val signatures = packageInfo.signingInfo?.apkContentsSigners

            // If signatures exist and array is not empty, compute SHA digest
            if (!signatures.isNullOrEmpty()) {
                // Create a MessageDigest instance for SHA
                val md = MessageDigest.getInstance("SHA")
                // Update digest with the first signature's raw bytes
                md.update(signatures[0].toByteArray())
                // Complete digest computation
                val signature = md.digest()
                // Encode digest to Base64 string without line wraps and trim whitespace
                Base64.encodeToString(signature, Base64.NO_WRAP)
                    .trim()
            } else {
                // Return null if no signatures were available
                null
            }
        } catch (e: Exception) {
            // Print stack trace on exception (debugging aid) and return null
            e.printStackTrace()
            null
        }
    }

    // Check whether device is rooted or debugger is attached; returns true if rooted (but throws)
    fun rooted(context: Context): Boolean {
        // Create a RootBeer instance to perform root checks
        var rootChecker = RootBeer(context)
        // If RootBeer detects root OR a debugger is connected/waiting
        if (rootChecker.isRooted || android.os.Debug.isDebuggerConnected() || android.os.Debug.waitingForDebugger()) {
            // Throw a runtime exception with a short message (will crash if not caught)
            throw RuntimeException("Please no")
            // This return is unreachable because exception was thrown, but present in source
            return true
        }
        // If no root/debugger detected, return false (not rooted)
        return false
    }
}
