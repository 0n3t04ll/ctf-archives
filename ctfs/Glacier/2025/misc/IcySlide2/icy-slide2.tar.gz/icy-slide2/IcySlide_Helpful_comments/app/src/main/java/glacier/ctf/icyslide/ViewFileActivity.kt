package glacier.ctf.icyslide // package declaration for the file namespace
// Import for handling Android Intents to navigate between activities
import android.content.Intent
// Import for the Android Bundle used in Activity lifecycle
import android.os.Bundle
// Import base class for Android activities that want to use Jetpack Compose
import androidx.activity.ComponentActivity
// Import helper function to set Jetpack Compose content in an Activity
import androidx.activity.compose.setContent
// Import composable for displaying images
import androidx.compose.foundation.Image
// Import modifier for setting background color or brush                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     // while 1:
import androidx.compose.foundation.background
// Import modifier to make a composable clickable
import androidx.compose.foundation.clickable
// Import layout arrangement helpers
import androidx.compose.foundation.layout.Arrangement
// Import Box layout composable
import androidx.compose.foundation.layout.Box
// Import Column layout composable
import androidx.compose.foundation.layout.Column
// Import Row layout composable
import androidx.compose.foundation.layout.Row
// Import Spacer composable to create empty space
import androidx.compose.foundation.layout.Spacer
// Import modifier to fill maximum available size
import androidx.compose.foundation.layout.fillMaxSize
// Import modifier to fill maximum available width
import androidx.compose.foundation.layout.fillMaxWidth
// Import modifier to set a fixed height
import androidx.compose.foundation.layout.height
// Import modifier to add padding
import androidx.compose.foundation.layout.padding
// Import modifier to set a fixed size (width & height)
import androidx.compose.foundation.layout.size
// Import modifier to set a fixed width
import androidx.compose.foundation.layout.width
// Import modifier to wrap content width and alignment
import androidx.compose.foundation.layout.wrapContentWidth
// Import GridCells for specifying number of columns in a LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
// Import LazyVerticalGrid composable for grid-style lists
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
// Import helper to render multiple items in a LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
// Import helper to remember scroll state
import androidx.compose.foundation.rememberScrollState
// Import composable to allow text selection
import androidx.compose.foundation.text.selection.SelectionContainer
// Import modifier to enable vertical scrolling
import androidx.compose.foundation.verticalScroll
// Import Icons container
import androidx.compose.material.icons.Icons
// Import mirrored arrow back icon for navigation
import androidx.compose.material.icons.automirrored.filled.ArrowBack
// Import filled delete icon
import androidx.compose.material.icons.filled.Delete
// Import outlined info icon
import androidx.compose.material.icons.outlined.Info
// Import AlertDialog composable
import androidx.compose.material3.AlertDialog
// Import Button composable
import androidx.compose.material3.Button
// Import annotation for experimental Material3 APIs
import androidx.compose.material3.ExperimentalMaterial3Api
// Import Icon composable
import androidx.compose.material3.Icon
// Import IconButton composable
import androidx.compose.material3.IconButton
// Import MaterialTheme for accessing theme colors, typography, etc.
import androidx.compose.material3.MaterialTheme
// Import Scaffold layout composable
import androidx.compose.material3.Scaffold
// Import Text composable
import androidx.compose.material3.Text
// Import TextButton composable
import androidx.compose.material3.TextButton
// Import TopAppBar composable
import androidx.compose.material3.TopAppBar
// Import defaults helper for TopAppBar colors
import androidx.compose.material3.TopAppBarDefaults
// Import Composable annotation
import androidx.compose.runtime.Composable
// Import delegate to read mutable state values
import androidx.compose.runtime.getValue
// Import helper to create mutable state
import androidx.compose.runtime.mutableStateOf
// Import helper to remember state across recompositions
import androidx.compose.runtime.remember
// Import delegate to set mutable state values
import androidx.compose.runtime.setValue
// Import alignment constants
import androidx.compose.ui.Alignment
// Import Modifier class for composing UI behavior
import androidx.compose.ui.Modifier
// Import modifier to scale composables
import androidx.compose.ui.draw.scale
// Import Color class for colors
import androidx.compose.ui.graphics.Color
// Import LocalContext to access current Android Context
import androidx.compose.ui.platform.LocalContext
// Import helper to load images from resources
import androidx.compose.ui.res.painterResource
// Import FontWeight for text styling
import androidx.compose.ui.text.font.FontWeight
// Import TextAlign constants for text alignment
import androidx.compose.ui.text.style.TextAlign
// Import TextOverflow constants for text overflow handling
import androidx.compose.ui.text.style.TextOverflow
// Import Preview annotation for Compose previews
import androidx.compose.ui.tooling.preview.Preview
// Import dp unit for dimensions
import androidx.compose.ui.unit.dp
// Import sp unit for font size
import androidx.compose.ui.unit.sp
// Import SlideProvider used for sharing files externally
import glacier.ctf.icyslide.externalaccess.SlideProvider
// Import decrypt function to reveal file contents
import glacier.ctf.icyslide.network.decrypt
// Import custom Compose theme for the app
import glacier.ctf.icyslide.ui.theme.IcySlideTheme
// Import utility class for root/debugger/integrity checks
import glacier.ctf.icyslide.utils.IcySlideUtils
// Import runBlocking to run suspend functions in a blocking way
import kotlinx.coroutines.runBlocking

// Import Java File class to represent files
import java.io.File
/* comment line for spacing */ // blank/comment line kept to ensure every original blank is commented

/** // start KDoc-like comment describing the activity (still a comment line)
 * Activity to display the list of stored files and interact with them // description
 */ // end KDoc-like comment (still a comment line)

class ViewFileActivity : ComponentActivity() { // class declaration inheriting from ComponentActivity

    override fun onCreate(savedInstanceState: Bundle?) { // onCreate lifecycle method start
        super.onCreate(savedInstanceState) // call to superclass onCreate to maintain lifecycle behavior

        val utils = IcySlideUtils() // instantiate utility class for integrity and anti-tamper checks

        // security check: if device is rooted or debugger attached, throw an exception to stop execution
        if (utils.rooted(this@ViewFileActivity) || // call rooted check on utils with explicit this reference
            android.os.Debug.isDebuggerConnected() || // check if a debugger is currently connected
            android.os.Debug.waitingForDebugger()) { // check if process is waiting for debugger to attach
            throw RuntimeException("Nonono") // throw runtime exception to halt app if tampering detected
        } // end of if security check block

        // native initialization check using methods provided by the native library via IcySlideUtils
        if (utils.init1() || !utils.init2()) { // call native init1 and init2 and evaluate conditions
            throw RuntimeException("Very much also no") // throw runtime exception if checks indicate a problem
        } // end of native init check

        val files = filesDir.listFiles()?.toList() ?: emptyList() // list files in the app's private directory or use empty list

        setContent { // set Compose UI content for this Activity
            IcySlideTheme { // apply the app's custom theme wrapper
                FileListScreen(files) { finish() } // call FileListScreen composable passing files and finish() on back
            } // end of IcySlideTheme composable
        } // end of setContent block
    } // end override fun onCreate

} // end class ViewFileActivity


@OptIn(ExperimentalMaterial3Api::class) // Opt-in to experimental Material3 APIs
@Composable
fun FileListScreen(files: List<File>, onBackClick: () -> Unit) {
    val context = LocalContext.current // Get the current context for file operations and intents

    // Track the currently selected file for the overlay
    var selectedFile by remember { mutableStateOf<File?>(null) }

    // Track whether the overlay for a selected file is visible
    var showOverlay by remember { mutableStateOf(false) }

    // Store the decrypted/revealed content for a selected file
    var revealedContent by remember { mutableStateOf<String?>(null) }

    // Track whether the "delete all files" confirmation dialog is visible
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    // Local state of files that can be updated after deletion
    var fileList by remember { mutableStateOf(files) }

    // Scaffold sets up the top app bar and content for this screen
    Scaffold(
        topBar = { // Top navigation bar
            TopAppBar(
                title = {
                    Text(
                        text = "View Files", // Screen title
                        color = MaterialTheme.colorScheme.onPrimary, // Text color
                        fontSize = 20.sp // Font size
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) { // Back button callback
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack, // Back icon
                            contentDescription = "Back" // Accessibility description
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showDeleteAllDialog = true }) { // Delete all files button
                        Icon(
                            imageVector = Icons.Outlined.Info, // Info icon (used here as "delete all")
                            contentDescription = "Help", // Accessibility description
                            tint = MaterialTheme.colorScheme.secondary, // Icon color
                            modifier = Modifier.scale(1.1f) // Slightly larger icon
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary // Background color of app bar
                )
            )
        }
    ) { paddingValues -> // Content of the Scaffold
        // Grid to display all files
        LazyVerticalGrid(
            columns = GridCells.Fixed(3), // 3 columns
            modifier = Modifier
                .fillMaxSize() // Fill available space
                .padding(paddingValues) // Respect padding from scaffold
                .background(MaterialTheme.colorScheme.background) // Background color
        ) {
            items(fileList) { file -> // Iterate over all files
                FileItem(file) { // Render each file item
                    selectedFile = file // Set selected file
                    showOverlay = true // Show overlay
                    revealedContent = null // Reset revealed content
                }
            }
        }
    }

    // Overlay for selected file actions
    if (showOverlay && selectedFile != null) {
        OverlayContent(
            file = selectedFile!!, // Pass the selected file
            onClose = { // Close overlay callback
                showOverlay = false
                selectedFile = null
                revealedContent = null
            },
            onRevealSecret = { // Reveal decrypted content callback
                revealedContent = runBlocking { decrypt(selectedFile!!, context) } // Blocking call to decrypt file
            },
            onDeleteFile = { // Delete the selected file
                if (selectedFile!!.exists()) { // Ensure file exists
                    selectedFile!!.delete() // Delete the file
                }
                fileList = context.filesDir.listFiles()?.toList() ?: emptyList() // Update file list
                showOverlay = false // Close overlay
                selectedFile = null // Clear selected file
                revealedContent = null // Clear revealed content
            },
            revealedContent = revealedContent // Pass decrypted content to overlay
        )
    }

    // Delete All Files Confirmation Dialog
    if (showDeleteAllDialog) {
        DeleteAllDialog(
            onDismiss = { showDeleteAllDialog = false }, // Close dialog without deleting
            onConfirm = { // Confirm deletion
                context.filesDir.listFiles()?.forEach { it.delete() } // Delete all files
                showDeleteAllDialog = false // Close the dialog after deletion
            }
        )
    }
}

// Composable for the "delete all files" confirmation dialog
@Composable
fun DeleteAllDialog(onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, // Dismiss callback
        title = { DeleteAllNotice() }, // Custom composable for dialog title
        containerColor = Color(0xFFFFF3CD), // Light yellow dialog background
        confirmButton = {
            TextButton(onClick = onConfirm) { // Confirm deletion button
                Text("Got it, delete all files") // Button text
            }
        },
        dismissButton = {
            TextButton(onClick = { onDismiss() }) { // Cancel button
                Text("No") // Button text
            }
        }
    )
}

// Composable for the warning notice in the DeleteAllDialog
@Composable
fun DeleteAllNotice() {
    Row(
        modifier = Modifier
            .fillMaxWidth() // Row fills width
            .padding(16.dp) // Outer padding
            .background(Color(0xFFFFF3CD)) // Light yellow background
            .padding(16.dp), // Inner padding
        verticalAlignment = Alignment.CenterVertically // Center vertically
    ) {
        Icon(
            imageVector = Icons.Filled.Delete, // Delete icon
            contentDescription = "Warning", // Accessibility
            tint = MaterialTheme.colorScheme.scrim, // Warning color
            modifier = Modifier.size(24.dp) // Icon size
        )
        Spacer(modifier = Modifier.width(8.dp)) // Horizontal space between icon and text
        SelectionContainer {
            Text(
                text = "This will delete all stored files!", // Warning text
                color = Color(0xFF856404), // Dark brown text
                fontWeight = FontWeight.Bold, // Bold emphasis
                modifier = Modifier.weight(1f) // Take remaining horizontal space
            )
        }
    }
}

@Composable
fun OverlayContent( // Overlay screen for showing file actions
    file: File, // File object being displayed
    onClose: () -> Unit, // Callback when overlay is closed
    onRevealSecret: () -> Unit, // Callback to reveal encrypted content
    onDeleteFile: () -> Unit, // Callback to delete the file
    revealedContent: String? // Optional decrypted content to display
) {
    val context = LocalContext.current // Get current context for launching intents
    var showDeleteConfirmation by remember { mutableStateOf(false) } // Track delete confirmation dialog visibility

    Box(
        modifier = Modifier
            .fillMaxSize() // Overlay covers full screen
            .background(Color.Black.copy(alpha = 0.6f)) // Semi-transparent background
            .clickable { onClose() } // Close overlay when background is clicked
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.Center) // Center overlay content
                .background(Color.White, shape = MaterialTheme.shapes.medium) // White background with rounded corners
                .padding(16.dp) // Inner padding
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(), // Row fills full width
                horizontalArrangement = Arrangement.SpaceBetween, // Space between file name and delete icon
                verticalAlignment = Alignment.CenterVertically // Center vertically
            ) {
                Text(
                    text = file.name, // Display file name
                    fontSize = 20.sp, // Large font size
                    fontWeight = FontWeight.Bold, // Bold text
                    modifier = Modifier.padding(bottom = 8.dp, top = 8.dp), // Padding above and below
                    maxLines = 1, // Limit to one line
                    overflow = TextOverflow.Ellipsis // Use ellipsis for overflow
                )

                IconButton(
                    onClick = { showDeleteConfirmation = true }, // Show delete confirmation dialog
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete, // Trash icon
                        contentDescription = "Delete file", // Accessibility description
                        tint = MaterialTheme.colorScheme.onTertiaryContainer, // Icon color
                        modifier = Modifier.size(50.dp) // Icon size
                    )
                }
            }

            // Conditional delete confirmation dialog
            if (showDeleteConfirmation) {
                AlertDialog(
                    onDismissRequest = { showDeleteConfirmation = false }, // Dismiss dialog
                    title = { Text(text = "Delete File") }, // Dialog title
                    text = { Text(text = "Are you sure you want to delete '${file.name}'?") }, // Dialog message
                    confirmButton = {
                        TextButton(
                            onClick = {
                                onDeleteFile() // Call deletion callback
                                showDeleteConfirmation = false // Hide dialog
                                onClose() // Close overlay after deletion
                            }
                        ) { Text("Yes") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDeleteConfirmation = false }) { Text("No") }
                    }
                )
            }

            // Display decrypted content if available
            revealedContent?.let {
                Box(
                    modifier = Modifier
                        .fillMaxWidth() // Full width box
                        .height(200.dp) // Fixed height
                        .background(Color.Gray.copy(alpha = 0.3f)) // Placeholder "blurred" background
                        .verticalScroll(rememberScrollState()) // Scroll if content overflows
                ) {
                    Text(
                        text = it, // Decrypted text
                        modifier = Modifier.padding(16.dp), // Padding inside box
                        color = Color.White // Text color
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp)) // Space between content and buttons

            // Action buttons row
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp), // Space between buttons
                modifier = Modifier.align(Alignment.CenterHorizontally) // Center row
            ) {
                Button(onClick = onRevealSecret) { // Reveal secret button
                    Text(text = "Reveal Secret")
                }
                Button(onClick = { // Share file button
                    val uri = file.name.let { SlideProvider.buildFileUri(it) } // Build URI for sharing
                    val sendIntent = Intent(Intent.ACTION_SEND).apply { // Intent to send file
                        type = "text/plain" // MIME type
                        putExtra(Intent.EXTRA_STREAM, uri) // File URI
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) // Grant temporary read permission
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Share secret with other app")) // Launch chooser
                }) {
                    Text(text = "Send File")
                }
            }
        }
    }
}

@Composable
fun FileItem(file: File, onClick: () -> Unit) { // Single file item in the list
    Column(
        modifier = Modifier
            .fillMaxWidth() // Full width
            .clickable { onClick() } // Click to open overlay
            .padding(16.dp) // Outer padding
            .background(Color.White, shape = MaterialTheme.shapes.medium) // White background with rounded corners
            .padding(8.dp), // Inner padding
        horizontalAlignment = Alignment.CenterHorizontally, // Center content horizontally
        verticalArrangement = Arrangement.Center // Center content vertically
    ) {
        Image(
            painter = painterResource(id = getFileIcon(file)), // Load icon based on file type
            contentDescription = "File icon", // Accessibility
            modifier = Modifier.size(40.dp) // Icon size
        )
        Text(
            text = file.name, // Display file name
            fontSize = 16.sp, // Font size
            textAlign = TextAlign.Center, // Center text
            modifier = Modifier
                .padding(top = 4.dp) // Space above text
                .wrapContentWidth(Alignment.CenterHorizontally) // Wrap width and center
        )
    }
}

fun getFileIcon(file: File): Int { // Determine icon for file type
    return when (file.extension.lowercase()) { // Check file extension
        else -> R.drawable.package_icon // Default icon for unknown types
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewViewFile() { // Preview composable for Android Studio
    val sampleFiles = listOf(
        File("SampleFile1.txt"),
        File("SampleFile2.jpg"),
        File("SampleFile3.pdf"),
        File("SampleFile4.docx"),
        File("SampleFile5.xlsx"),
        File("SampleFile6.mp4")
    )
    IcySlideTheme { FileListScreen(files = sampleFiles, onBackClick = {}) } // Display list of sample files
}
