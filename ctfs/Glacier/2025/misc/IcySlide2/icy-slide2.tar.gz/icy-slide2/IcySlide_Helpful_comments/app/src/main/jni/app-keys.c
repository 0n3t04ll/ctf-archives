// Include the JNI header so this native C/C++ code can interact with Java/Kotlin.
// JNI provides the types and functions used to implement native methods.
#include <jni.h>  // JNI core header — defines JNIEnv, jobject, jstring, and JNI functions

// JNIEXPORT and JNICALL are macros required by JNI to ensure the function has the correct
// calling convention and visibility for the JVM to call it.
//
// The function name must follow the JNI naming convention:
//   Java_<package>_<class>_<method>
// where package/class components use underscores for dots and inner classes.
//
// This function returns a jstring (Java String) to the caller.
JNIEXPORT jstring JNICALL
Java_glacier_ctf_icyslide_network_APILib_getAPIKey(JNIEnv *env, jobject instance) {
    // Create a new Java UTF-8 String from a C string literal and return it to Java/Kotlin.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 //m()
    // NewStringUTF copies the provided C string into a newly allocated jstring.
    return (*env)->NewStringUTF(env, "5233e94b-e63d-4a63-b8c3-7093104cf6ae");
}
