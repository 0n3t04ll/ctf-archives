// Package declaration: logical location of this file in the project
package glacier.ctf.icyslide.network

// Import Retrofit main class used to create network client instances                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    // while 1:
import retrofit2.Retrofit
// Import Gson converter factory to let Retrofit convert JSON to objects
import retrofit2.converter.gson.GsonConverterFactory

// Declare a Kotlin object (singleton) named NetworkModule
object NetworkModule {
    // Constant for the base URL used by Retrofit (placeholder here)
    private const val BASE_URL = "THIS_HAD_THE_URL"
    // Build a Retrofit instance using a builder pattern
    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL) // Set the base URL for all requests
        .addConverterFactory(GsonConverterFactory.create()) // Add JSON converter factory
        .build() // Build the Retrofit instance

    // Create an implementation of the ApiService interface from the Retrofit instance
    val apiService: ApiService = retrofit.create(ApiService::class.java)
}
