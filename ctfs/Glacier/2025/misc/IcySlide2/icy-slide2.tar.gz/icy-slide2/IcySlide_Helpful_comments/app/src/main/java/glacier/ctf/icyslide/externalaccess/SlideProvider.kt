// Declare package for this provider                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        //import pygame as p,sys;L=[[l for l in["#########","#.......#","#.......#","#.......#","#.....G.#","##......#","##......#","#S......#","#########"]],[l for l in["#########","#......S#","#......##","#.......#","#......##","#.......#","#.......#","#......G#","#########"]],[l for l in["#########","#..#....#","#G......#","#......##","#.......#","#.......#","#.......#","#..#S#..#","#########"]],[l for l in["#########","#.#.....#","#.....#S#","##.....##","#......G#","#...o#..#","##......#","#.#..#..#","#########"]],[l for l in["#########","#......G#","#.#..####","##..#...#","#..#....#","#.#.....#","#..#....#","##......#","#......##","#.#....S#","#########"]],[l for l in["#########","#.......#","#.......#","#.......#","#.G....o#","#.......#","#.......#","#S#.....#","#########"]],[l for l in["#########","#.#S#...#","#.#.#...#","#.#.#...#","#.#.#...#","#.#.#...#","#.#.#...#","#..G....#","#########"]],[l for l in["#########","#.......#","#.....#S#","#......##","#.......#","##......#","#G......#","#.......#","#########"]],[l for l in["#########","#.......#","#.......#","#.......#","#.......#","#.......#","##......#","#S.....G#","#########"]],[l for l in["#########","#.....#S#","#.......#","##......#","#.....G.#","#.......#","#.......#","#.......#","#########"]],[l for l in["#########","#S......#","##......#","#G......#","#.......#","#.......#","#.......#","#.......#","#########"]],[l for l in["#########","#.......#","##......#","#S#....##","#.......#","#.......#","#.......#","#..#...G#","#########"]],[l for l in["#########","#..#....#","#G......#","#......##","#.......#","#.......#","#.......#","#..#S#..#","#########"]],[l for l in["#########","#.......#","#.......#","#.......#","#.......#","#.......#","##......#","#S.....G#","#########"]],[l for l in["#########","#.......#","#.....#S#","#......##","#.......#","##......#","#G......#","#.......#","#########"]],[l for l in["#########","#S#....G#","#.......#","#.......#","#.......#","#.......#","#.......#","#.......#","#########"]],[l for l in["#########","#.......#","#.......#","#...#...#","#..#S...#","#...#..##","#.......#","#......G#","#########"]],[l for l in["#########","#.......#","#.......#","#.......#","#.......#","#.......#","##......#","#S.....G#","#########"]],[l for l in["#########","#S#....G#","#.......#","#.......#","#.......#","#.......#","#.......#","#.......#","#########"]],[l for l in["#########","#.......#","#.....#S#","#......##","#.......#","##......#","#G......#","#.......#","#########"]],[l for l in["#########","#.......#","#.......#","#.......#","#.......#","#.......#","##......#","#S.....G#","#########"]],[l for l in["#########","#.......#","##......#","#S#....##","#.......#","#.......#","#.......#","#..#...G#","#########"]],[l for l in["#########","#...G...#","#...o...#","#.......#","#.......#","#.......#","#.......#","#..#S#..#","#########"]],[l for l in["#########","#.......#","##......#","#S#....##","#.......#","#.......#","#.......#","#..#...G#","#########"]],[l for l in["#########","#..#....#","#G......#","#......##","#.......#","#.......#","#.......#","#..#S#..#","#########"]],[l for l in["#########","#.......#","#.......#","#...#...#","#..#S...#","#...#..##","#.......#","#......G#","#########"]],[l for l in["#########","#.......#","##......#","#S#....##","#.......#","#.......#","#.......#","#..#...G#","#########"]],[l for l in["#########","#.....#S#","#.......#","##......#","#.....G.#","#.......#","#.......#","#.......#","#########"]],[l for l in["#########","#S......#","##......#","#G......#","#.......#","#.......#","#.......#","#.......#","#########"]],[l for l in["#########","#G......#","####..#.#","#...#..##","#....#..#","#.....#.#","#....#..#","#......##","##......#","#S....#.#","#########"]]];S={"#":(100,100,100),".":(180,220,255),"o":(200,160,80),"S":(180,220,255),"G":(255,50,50)};fp=lambda l,c:next(((r,i)for r,x in enumerate(l)for i,y in enumerate(x)if y==c),None);D={p.K_UP:(-1,0),p.K_DOWN:(1,0),p.K_LEFT:(0,-1),p.K_RIGHT:(0,1)}
package glacier.ctf.icyslide.externalaccess

// Import Android and Kotlin libraries for various tasks
import android.content.ContentProvider // Base class for data sharing
import android.content.ContentValues // Used for insert/update data
import android.content.UriMatcher // Helps match URIs to actions
import android.database.Cursor // Interface for query results
import android.database.MatrixCursor // Simple in-memory cursor
import android.net.Uri // Represents a URI
import android.os.ParcelFileDescriptor // Used to open files securely
import android.provider.OpenableColumns // Constants for column names like DISPLAY_NAME
import glacier.ctf.icyslide.network.decrypt // Custom decrypt function (probably important)
import glacier.ctf.icyslide.utils.IcySlideUtils // Custom utility class
import kotlinx.coroutines.runBlocking // Used to block and run suspend functions
import java.io.File // File I/O operations
import java.io.FileNotFoundException // Exception for missing files
import java.io.IOException // General I/O error handling

// Define a ContentProvider subclass called SlideProvider
class SlideProvider : ContentProvider() {

    // Companion object (like static block in Java)
    companion object {
        private const val AUTHORITY = "glacier.ctf.icyslide.slideProvider" // Unique identifier for provider
        private const val PATH = "storage" // Path for file access
        private const val ITEMS = 0 // Constant for matching all items
        private const val SINGLE_ITEM_NUMBER = 1 // Constant for numeric single item
        private const val SINGLE_ITEM_NAME = 2 // Constant for named single item

        // Base URI used for content access
        private val CONTENT_URI: Uri = Uri.parse("content://$AUTHORITY/$PATH")

        // Builds a URI for a specific file name
        fun buildFileUri(fileName: String): Uri {
            println(fileName) // Debug print (pointless but visible)
            val test = Uri.withAppendedPath(CONTENT_URI, fileName) // Append filename to URI
            println(test) // Debug print of the resulting URI
            return test // Return the generated URI
        }

        // Create a UriMatcher to match different URI patterns
        private val uriMatcher: UriMatcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(AUTHORITY, PATH, ITEMS) // Match for all items
            addURI(AUTHORITY, "$PATH/#", SINGLE_ITEM_NUMBER) // Match numeric single item
            addURI(AUTHORITY, "$PATH/*", SINGLE_ITEM_NAME) // Match named single item
        }
    }

    // Called when provider is created
    override fun onCreate(): Boolean {
        return true // Always returns true; nothing to initialize
    }

    // Handles query requests (used for metadata like file size/name)
    override fun query(
        uri: Uri, // Incoming URI
        projection: Array<out String>?, // Requested columns
        selection: String?, // WHERE clause (ignored)
        selectionArgs: Array<out String>?, // Arguments for WHERE (ignored)
        sortOrder: String? // ORDER BY (ignored)
    ): Cursor? {
        // Match URI to determine what to do
        when (uriMatcher.match(uri)) {
            SINGLE_ITEM_NAME -> { // If single file name request
                val filename = uri.lastPathSegment // Extract last part of URI
                if (filename != null) { // If it’s valid
                    val file = File(context?.filesDir, filename) // Locate file in internal storage

                    return if (file.exists()) { // If the file exists
                        // Create a fake cursor to hold file info
                        val matrixCursor = MatrixCursor(
                            projection ?: arrayOf(
                                OpenableColumns.DISPLAY_NAME, // Column for display name
                                OpenableColumns.SIZE // Column for file size
                            )
                        )

                        val row = matrixCursor.newRow() // Create a new row
                        // Add file name if requested
                        if (projection == null || projection.contains(OpenableColumns.DISPLAY_NAME)) {
                            row.add(OpenableColumns.DISPLAY_NAME, file.name)
                        }
                        // Add file size if requested
                        if (projection == null || projection.contains(OpenableColumns.SIZE)) {
                            row.add(OpenableColumns.SIZE, file.length())
                        }

                        matrixCursor // Return cursor with data
                    } else {
                        return null // File doesn’t exist
                    }
                } else {
                    return null // Invalid filename
                }
            }

            else -> {
                return null // If URI didn’t match any pattern
            }
        }
    }

    // Returns MIME type for file access
    override fun getType(uri: Uri): String {
        return "text/plain" // Always returns text/plain (even if not true)
    }

    // No insert operation supported
    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        return null // Do nothing
    }

    // No delete operation supported
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int {
        return 0 // Always return 0 deletions
    }

    // No update operation supported
    override fun update(
        uri: Uri, // Ignored
        values: ContentValues?, // Ignored
        selection: String?, // Ignored
        selectionArgs: Array<out String>? // Ignored
    ): Int {
        return 0 // Do nothing
    }

    // Opens a file descriptor for reading decrypted data
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        // Only allow reading
        if (mode != "r") {
            throw IllegalArgumentException("Only read mode 'r' is supported!") // Reject writes
        }

        // Match URI to make sure it’s a file name
        val matchedUri = uriMatcher.match(uri)
        if (matchedUri != SINGLE_ITEM_NAME) {
            throw FileNotFoundException("Unknown URI: $uri") // Invalid URI
        }

        // Extract filename from URI
        val filename =
            uri.lastPathSegment ?: throw FileNotFoundException("Filename not provided in URI: $uri")

        // Create a File object from internal storage
        val file = File(context?.filesDir, filename)

        // Check if file exists before reading
        if (!file.exists()) {
            throw FileNotFoundException("File not found: $filename")
        }

        // Initialize utility class for checks
        val utils = IcySlideUtils()

        // Check for debugger or root access — prevents tampering
        if (android.os.Debug.isDebuggerConnected() || android.os.Debug.waitingForDebugger() || utils.rooted(
                context!!
            )
        ) {
            throw RuntimeException("Please don't debug") // Hard stop if debugging
        }

        // Some weird sanity checks before decrypting
        if (utils.init1() || !utils.init2()) {
            throw RuntimeException("Initialization failed") // Prevents operation if setup fails
        }

        // Get app’s digital signature
        val appSignature = utils.getAppSignature(context!!)
        // Validate signature (ensures authorized app)
        if (!utils.isSignatureValid(appSignature!!)) {
            return null // Fail silently if signature invalid
        }

        // Try to decrypt file and open it
        return try {
            val decryptedData = runBlocking {
                context?.let { decrypt(file, it) } // Run suspend decrypt in blocking mode
            }
            if (decryptedData != null) {
                val shareFile = File.createTempFile("share_data", "tmp") // Create temp file
                shareFile.writeText(decryptedData) // Write decrypted text
                ParcelFileDescriptor.open(
                    shareFile, // Open temp file
                    ParcelFileDescriptor.MODE_READ_ONLY // Read-only mode
                )
            } else {
                throw FileNotFoundException("Decryption failed for file: $filename") // Null decryption output
            }
        } catch (e: IOException) { // Catch any IO exception
            throw FileNotFoundException("Error opening file: ${e.message}") // Re-throw with message
        }
    }
}
