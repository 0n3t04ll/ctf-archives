package glacier.ctf.icyslide // Package declaration for logical organization

import android.os.Bundle // Import for Android activity lifecycle bundles
import android.widget.Toast // Import for showing short popup messages
import androidx.activity.ComponentActivity // Import base class for activities
import androidx.activity.compose.setContent // Import for Compose content setting
import androidx.compose.foundation.background // Import to add background to composables
import androidx.compose.foundation.layout.Arrangement // Import for vertical/horizontal arrangement
import androidx.compose.foundation.layout.Column // Import for Column layout
import androidx.compose.foundation.layout.Row // Import for Row layout                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          //def m():
import androidx.compose.foundation.layout.Spacer // Import for spacing elements
import androidx.compose.foundation.layout.fillMaxSize // Import to fill maximum size
import androidx.compose.foundation.layout.fillMaxWidth // Import to fill maximum width
import androidx.compose.foundation.layout.height // Import to specify height
import androidx.compose.foundation.layout.padding // Import to apply padding
import androidx.compose.foundation.layout.size // Import to specify size
import androidx.compose.foundation.layout.width // Import to specify width
import androidx.compose.foundation.text.selection.SelectionContainer // Import to allow text selection
import androidx.compose.material.icons.Icons // Import for material icons container
import androidx.compose.material.icons.automirrored.filled.ArrowBack // Import back arrow icon
import androidx.compose.material.icons.filled.Warning // Import warning icon
import androidx.compose.material.icons.outlined.Info // Import info icon
import androidx.compose.material3.AlertDialog // Import AlertDialog composable
import androidx.compose.material3.Button // Import Button composable
import androidx.compose.material3.ButtonDefaults // Import default button settings
import androidx.compose.material3.ExperimentalMaterial3Api // Import for opt-in experimental API
import androidx.compose.material3.Icon // Import Icon composable
import androidx.compose.material3.IconButton // Import IconButton composable
import androidx.compose.material3.MaterialTheme // Import MaterialTheme for styling
import androidx.compose.material3.Scaffold // Import Scaffold layout
import androidx.compose.material3.Text // Import Text composable
import androidx.compose.material3.TextButton // Import TextButton composable
import androidx.compose.material3.TextField // Import TextField composable
import androidx.compose.material3.TextFieldDefaults // Import default TextField settings
import androidx.compose.material3.TopAppBar // Import TopAppBar composable
import androidx.compose.material3.TopAppBarDefaults // Import TopAppBar defaults
import androidx.compose.runtime.Composable // Import Composable annotation
import androidx.compose.runtime.getValue // Import delegate for state read
import androidx.compose.runtime.mutableStateOf // Import mutable state function
import androidx.compose.runtime.remember // Import remember function
import androidx.compose.runtime.setValue // Import delegate for state write
import androidx.compose.ui.Alignment // Import for alignment constants
import androidx.compose.ui.Modifier // Import Modifier for composables
import androidx.compose.ui.draw.scale // Import scale modifier
import androidx.compose.ui.graphics.Color // Import Color class
import androidx.compose.ui.text.font.FontWeight // Import font weight constants
import androidx.compose.ui.tooling.preview.Preview // Import preview annotation
import androidx.compose.ui.unit.dp // Import dp unit
import androidx.compose.ui.unit.sp // Import sp unit
import glacier.ctf.icyslide.network.encrypt // Import encrypt function
import glacier.ctf.icyslide.ui.theme.IcySlideTheme // Import custom theme
import glacier.ctf.icyslide.utils.IcySlideUtils // Import utility class
import kotlinx.coroutines.runBlocking // Import coroutine helper
import java.io.File // Import File class

class CreateNewFileActivity : ComponentActivity() { // Declare activity class
    override fun onCreate(savedInstanceState: Bundle?) { // Override onCreate lifecycle
        super.onCreate(savedInstanceState) // Call superclass onCreate
        val utils = IcySlideUtils() // Initialize IcySlideUtils instance

        if (utils.rooted(this@CreateNewFileActivity) || android.os.Debug.isDebuggerConnected() || android.os.Debug.waitingForDebugger()) { // Check for root or debugger
            throw RuntimeException("No bueno of you!") // Crash if security check fails
        } // End of if
        if (utils.init1() || !utils.init2()) { // Call native integrity checks
            throw RuntimeException("Also no bueno of you") // Crash if init fails
        } // End of if

        setContent { // Set Compose content
            IcySlideTheme { // Apply custom theme
                CreateNewFileScreen( // Compose screen for creating files
                    onSaveClicked = { filename, content -> // Lambda for save action
                        var file: File? = null // Initialize file variable
                        try { // Start try block
                            file = File(filesDir, filename) // Create file in internal storage
                            val canonicalPath = file.canonicalPath // Get canonical path
                            require(canonicalPath.startsWith(filesDir.canonicalPath)) // Check path safety
                            file.writeText(content) // Write text content

                            val result = runBlocking { encrypt(file, this@CreateNewFileActivity) } // Encrypt file
                            if (result != null) { // Check if encryption succeeded
                                file.writeBytes(result) // Overwrite file with encrypted data
                                Toast.makeText(this@CreateNewFileActivity, "File '$filename' created successfully", Toast.LENGTH_LONG).show() // Show success message
                            } else { // Encryption failed
                                file.delete() // Delete file
                            } // End if-else
                            true // Return success
                        } catch (e: IllegalArgumentException) { // Handle illegal arguments
                            file?.delete() // Delete file if exists
                            Toast.makeText(this@CreateNewFileActivity, "Please don't do that", Toast.LENGTH_LONG).show() // Show error toast
                            false // Return failure
                        } // End try-catch
                    }, // End onSaveClicked lambda
                    onBackClicked = { finish() } // Lambda for back button
                ) // End CreateNewFileScreen
            } // End IcySlideTheme
        } // End setContent
    } // End onCreate
} // End class

@OptIn(ExperimentalMaterial3Api::class) // Opt-in to experimental Material3 APIs
@Composable // Mark function as a Compose UI function
fun CreateNewFileScreen( // Start of CreateNewFileScreen function
    onSaveClicked: (String, String) -> Boolean, // Lambda for save button click, takes filename and content
    onBackClicked: () -> Unit // Lambda for back button click, no parameters
) { // Start function body
    var filename by remember { mutableStateOf("") } // State for the filename input
    var content by remember { mutableStateOf("") } // State for the file content input
    var showHelpDialog by remember { mutableStateOf(false) } // State for help dialog visibility

    Scaffold( // Scaffold layout to structure top bar and body
        topBar = { // Define top bar of the scaffold
            TopAppBar( // Start of TopAppBar composable
                title = { // Title section of top bar
                    Text( // Display text for the title
                        text = "Create New Text File", // The title string
                        color = MaterialTheme.colorScheme.onPrimary, // Text color from theme
                        fontSize = 20.sp // Font size in sp
                    ) // End of Text composable
                }, // End of title lambda
                navigationIcon = { // Navigation icon section
                    IconButton(onClick = onBackClicked) { // Button wrapping the icon
                        Icon( // Display the icon
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack, // Back arrow icon
                            contentDescription = "Back" // Content description for accessibility
                        ) // End of Icon composable
                    } // End of IconButton
                }, // End of navigationIcon lambda
                actions = { // Actions section of top bar
                    IconButton(onClick = { showHelpDialog = true }) { // Show help dialog on click
                        Icon( // Icon composable for info
                            imageVector = Icons.Outlined.Info, // Info icon
                            contentDescription = "Help", // Accessibility description
                            tint = MaterialTheme.colorScheme.secondary, // Tint color from theme
                            modifier = Modifier.scale(1.1f) // Slightly scale icon
                        ) // End of Icon composable
                    } // End of IconButton
                }, // End of actions lambda
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors( // Top bar colors
                    containerColor = MaterialTheme.colorScheme.primary // Background color of top bar
                ) // End of TopAppBarDefaults
            ) // End of TopAppBar
        } // End of topBar lambda
    ) { paddingValues -> // Body content lambda, receives padding
        Column( // Column layout for content
            modifier = Modifier // Modifier for column
                .fillMaxSize() // Fill entire size
                .padding(paddingValues) // Respect scaffold padding
                .padding(16.dp) // Add additional padding
                .background(MaterialTheme.colorScheme.background), // Background color from theme
            verticalArrangement = Arrangement.Top, // Arrange children from top
            horizontalAlignment = Alignment.CenterHorizontally // Center horizontally
        ) { // Start column content


            FileNameField(filename) { filename = it } // Composable for filename input, update state
            Spacer(modifier = Modifier.height(16.dp)) // Spacer for vertical spacing
            ContentField(content) { content = it } // Composable for content input, update state
            Spacer(modifier = Modifier.height(16.dp)) // Spacer
            SaveButton(onClick = { // Save button composable with click lambda
                val wasSuccessful = onSaveClicked(filename, content) // Call save lambda
                if (wasSuccessful) { // Check if save succeeded
                    filename = "" // Clear filename state
                    content = "" // Clear content state
                } // End if
            }) // End SaveButton
            Spacer(modifier = Modifier.height(16.dp)) // Spacer

        } // End of Column
        if (showHelpDialog) { // Check if help dialog should be shown
            HelpDialog(onDismiss = { showHelpDialog = false }) // Show HelpDialog and reset state on dismiss
        } // End if
    } // End Scaffold body lambda
} // End CreateNewFileScreen function

@Composable // Mark function as a Compose UI function
fun HelpDialog(onDismiss: () -> Unit) { // Start HelpDialog function, accepts dismiss lambda
    AlertDialog( // AlertDialog composable
        onDismissRequest = onDismiss, // Callback when dialog is dismissed
        title = { WarningNotice() }, // Title section with warning composable
        containerColor = Color(0xFFFFF3CD), // Background color of dialog
        confirmButton = { // Confirm button section
            TextButton(onClick = onDismiss) { // Button to dismiss dialog
                Text("Got it") // Button text
            } // End TextButton
        } // End confirmButton lambda
    ) // End AlertDialog
} // End HelpDialog function

@Composable // Mark function as a Compose UI function
fun WarningNotice() { // Start WarningNotice function
    Row( // Row layout for horizontal arrangement
        modifier = Modifier // Modifier for the row
            .fillMaxWidth() // Fill full width
            .padding(16.dp) // Padding around the row
            .background(Color(0xFFFFF3CD)) // Light yellow background
            .padding(16.dp), // Inner padding inside the row
        verticalAlignment = Alignment.CenterVertically // Center children vertically
    ) { // Start Row content

        Icon( // Icon composable for warning
            imageVector = Icons.Filled.Warning, // Warning icon
            contentDescription = "Warning", // Accessibility description
            tint = MaterialTheme.colorScheme.scrim, // Color from theme
            modifier = Modifier.size(24.dp) // Set icon size
        ) // End Icon

        Spacer(modifier = Modifier.width(8.dp)) // Spacer for horizontal spacing

        SelectionContainer { // Allow text to be selectable
            Text( // Text composable
                text = "You can create text files here, however, you can share also share your text files with this app, if you already have some stored somewhere else.", // Warning text
                color = Color(0xFF856404), // Dark brown color
                fontWeight = FontWeight.Bold, // Bold text
                modifier = Modifier.weight(1f) // Take remaining horizontal space
            ) // End Text
        } // End SelectionContainer

    } // End Row
} // End WarningNotice

@OptIn(ExperimentalMaterial3Api::class) // Opt-in to experimental Material3 APIs
@Composable // Mark function as a Compose UI function
fun FileNameField(filename: String, onValueChange: (String) -> Unit) { // Start FileNameField function
    Column(modifier = Modifier.fillMaxWidth()) { // Column layout filling width
        Text( // Label for file name
            text = "File Name", // Label text
            color = MaterialTheme.colorScheme.onSurface, // Text color from theme
            fontSize = 16.sp, // Font size
            modifier = Modifier // Modifier for Text
                .align(Alignment.Start) // Align to start
                .padding(bottom = 8.dp) // Padding below text
        ) // End Text

        TextField( // Input field for file name
            value = filename, // Bind value to state
            onValueChange = onValueChange, // Update state on change
            modifier = Modifier.fillMaxWidth(), // Fill width
            colors = TextFieldDefaults.textFieldColors( // Colors for TextField
                containerColor = MaterialTheme.colorScheme.surface, // Background color
                focusedIndicatorColor = MaterialTheme.colorScheme.primary, // Focused underline
                unfocusedIndicatorColor = Color.Gray, // Unfocused underline
                focusedTextColor = MaterialTheme.colorScheme.onSurface, // Text color when focused
                cursorColor = MaterialTheme.colorScheme.primary // Cursor color
            ) // End textFieldColors
        ) // End TextField
    } // End Column
} // End FileNameField

@OptIn(ExperimentalMaterial3Api::class) // Opt-in to experimental Material3 APIs
@Composable // Mark function as a Compose UI function
fun ContentField(content: String, onValueChange: (String) -> Unit) { // Start ContentField function
    Column(modifier = Modifier.fillMaxWidth()) { // Column layout filling width
        Text( // Label for content
            text = "Content", // Label text
            color = MaterialTheme.colorScheme.onSurface, // Text color
            fontSize = 16.sp, // Font size
            modifier = Modifier // Modifier for Text
                .align(Alignment.Start) // Align to start
                .padding(bottom = 8.dp) // Padding below
        ) // End Text

        TextField( // Input field for content
            value = content, // Bind value to state
            onValueChange = onValueChange, // Update state on change
            modifier = Modifier // Modifier for TextField
                .fillMaxWidth() // Fill width
                .height(200.dp), // Set height
            colors = TextFieldDefaults.textFieldColors( // Colors for TextField
                containerColor = MaterialTheme.colorScheme.surface, // Background color
                focusedIndicatorColor = MaterialTheme.colorScheme.primary, // Focused underline
                unfocusedIndicatorColor = Color.Gray, // Unfocused underline
                focusedTextColor = MaterialTheme.colorScheme.onSurface, // Text color
                cursorColor = MaterialTheme.colorScheme.primary // Cursor color
            ) // End textFieldColors
        ) // End TextField
    } // End Column
} // End ContentField

@Composable // Mark function as a Compose UI function
fun SaveButton(onClick: () -> Unit) { // Start SaveButton function
    Button( // Button composable
        onClick = onClick, // Click lambda
        modifier = Modifier.fillMaxWidth(), // Fill full width
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary) // Button colors
    ) { // Start Button content
        Text("Save File", color = MaterialTheme.colorScheme.onPrimary) // Button text
    } // End Button content
} // End SaveButton

@Preview(showBackground = true) // Compose preview annotation
@Composable // Mark function as a Compose UI function
fun PreviewCreateNewFile() { // Start PreviewCreateNewFile function
    IcySlideTheme { // Apply app theme
        CreateNewFileScreen( // Show CreateNewFileScreen
            onSaveClicked = { _, _ -> true }, // Dummy lambda for preview
            onBackClicked = {} // Dummy back lambda
        ) // End CreateNewFileScreen
    } // End IcySlideTheme
} // End PreviewCreateNewFile
