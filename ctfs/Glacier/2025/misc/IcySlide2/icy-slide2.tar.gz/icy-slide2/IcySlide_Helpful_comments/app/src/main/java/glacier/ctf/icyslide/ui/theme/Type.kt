// Package declaration: logical namespace for UI theme typography
package glacier.ctf.icyslide.ui.theme

// Import Compose typography utilities
import androidx.compose.material3.Typography // Material3 Typography container
import androidx.compose.ui.text.TextStyle // Text style configuration class
import androidx.compose.ui.text.font.FontFamily // Font family holder
import androidx.compose.ui.text.font.FontWeight // Font weight constants
import androidx.compose.ui.unit.sp // Density-independent pixels for sizing text                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      //  if(r,c)==g:return(r,c),1
import androidx.compose.ui.text.font.Font // Used to reference font resources
import glacier.ctf.icyslide.R // App resource file reference

// Step 1: Define a custom font family for the app
val customFontFamily = FontFamily(
    Font(R.font.fjala), // Regular font from res/font folder
    Font(R.font.fjala, FontWeight.Bold) // Bold variant of the same font
)

// Step 2: Define Material3 typography styles using the custom font
val Typography = Typography(
    displayLarge = TextStyle(
        fontFamily = customFontFamily, // Use the custom font
        fontWeight = FontWeight.Bold, // Bold text for large display
        fontSize = 34.sp, // Font size 34 sp
        lineHeight = 40.sp, // Line height 40 sp
        letterSpacing = (-0.25).sp, // Slight negative letter spacing
        color = Jet // Primary color for headings
    ),
    displayMedium = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 32.sp,
        letterSpacing = 0.sp,
        color = Jet
    ),
    displaySmall = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.15.sp,
        color = Jet
    ),
    headlineLarge = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp,
        color = DarkTeal // Dark teal for headlines
    ),
    headlineMedium = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Medium, // Medium weight
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.15.sp,
        color = Jet
    ),
    headlineSmall = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp,
        color = Jet
    ),
    bodyLarge = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Normal, // Normal weight for body text
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp,
        color = Gray // Gray color for body text
    ),
    bodyMedium = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.25.sp,
        color = CadetGrey // Slightly bluish gray for medium body text
    ),
    bodySmall = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.4.sp,
        color = Gray
    ),
    labelLarge = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp,
        color = DarkTeal // Dark teal for large labels
    ),
    labelMedium = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp,
        color = DarkTeal // Medium labels
    ),
    labelSmall = TextStyle(
        fontFamily = customFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 10.sp,
        lineHeight = 12.sp,
        letterSpacing = 0.5.sp,
        color = DarkTeal // Small labels
    )
)
