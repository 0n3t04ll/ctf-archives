package com.example.cinema.movie.exception;

public class BadKeywordException extends RuntimeException{
    public BadKeywordException(String message) {
        super(message);
    }
}
