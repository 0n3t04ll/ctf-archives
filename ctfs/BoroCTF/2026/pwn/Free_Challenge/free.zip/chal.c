#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>

typedef struct report {
  char title[8];
  char* file_data;
  uint32_t size;
} report_t;

report_t target = {"flag!!!", "", 64};
report_t* report;

void read_report() {
  if (report == NULL) return;
  printf("'%s':\n", report->title);
  puts(report->file_data);
}

void edit_report() {
  if (report == NULL) return;
  printf("'%s' currently has: '", report->title);
  if (report->file_data != NULL) {
    printf("%s", report->file_data);
  }
  printf("' in it.\n");


  printf("Title (7 chars): ");
  if (fgets(report->title, 8, stdin) == NULL) return;
  report->title[strcspn(report->title, "\n")] = '\0';

  printf("What is the size of the report? ");
  uint32_t size = 0;
  if (scanf("%" PRIu32, &size) <= 0) exit(0);

  int c;
  while ((c = getchar()) != '\n' && c != EOF);
  
  if (size == 0) exit(0);

  char* buf;

  if (size < report->size || report->size > 0x500) {
    exit(0);
  }

  if (report->file_data != NULL) {
    buf = realloc(report->file_data, size);
  } else {
    buf = malloc(size);
  }

  report->size = size;
  report->file_data = (buf != NULL) ? buf : report->file_data;  

  if (report->file_data == NULL) exit(0);

  printf("Report: ");
  if (fgets(report->file_data, report->size, stdin) == NULL) return;
  report->file_data[strcspn(report->file_data, "\n")] = '\0';
  puts("Edited report!");
}

void make_report() {
  report = malloc(sizeof(report_t));
  if (report == NULL) exit(0);
  
  edit_report();
}

void close_report() {
  if (report == NULL) return;
  free(report);
  puts("Closed report!");
}

int main(int argc, char *argv[]) {
  FILE *file;

  file = fopen("flag.txt", "r");

  if (file == NULL) {
    printf("No flag.txt!\n");
    return 1;
  }

  target.file_data = malloc(64);
  if (fgets(target.file_data, 64, file) == NULL) {
    printf("Failed to read flag.txt!\n");
    fclose(file);
    return 1;
  }


  while (1) {
    puts("Welcome to the filing cabinet!");
    puts("What do you want to do?");
    puts("[1] - Make a new report\n[2] - Read your current report\n[3] - Edit your report\n[4] - Lock away your report");
    int input;
    if (scanf("%d", &input) <= 0) break;

    int c;
    while ((c = getchar()) != '\n' && c != EOF);

    if (input == 1) {
      make_report();
    } else if (input == 2) {
      read_report();
    } else if (input == 3) {
      edit_report();
    } else if (input == 4) {
      close_report();
    }
    puts("");
  }
  return 0;
}
