#!/bin/bash
exec timeout 600 qemu-system-x86_64 \
    -m 128 \
    -nographic \
    -kernel ./bzImage \
    -append 'console=ttyS0 loglevel=3 oops=panic panic=1 init=/init nokaslr' \
    -monitor /dev/null \
    -initrd initramfs.img  \
    -smp 4 \
