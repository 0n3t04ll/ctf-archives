#!/usr/bin/python3 -u 
from flask import Flask,request,session
from base64 import b64decode
from os import popen,urandom
from uuid import uuid4
from time import sleep,time
from random import randint
from hashlib import sha256

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 20 * 1024
app.config['SECRET_KEY'] = urandom(24)
alive_time = 5
ports = {}

@app.route('/')
def index():
    return "Hello"

@app.route('/upload', methods=['POST'])
def upload():
    try:
        # simple pow
        if not session.get('x') or not request.form.get('x'):
            return 'fail'
        x,_x = session.get('x'),request.form.get('x')
        if sha256(x.encode()).hexdigest() != sha256(_x.encode()).hexdigest():
            return 'fail'

        # file save
        file = request.files.get('file')
        if not file:
            return "file not found"

        now = int(time())
        rd_name = f'./file/{now}-{x[:10]}'
        file.save(rd_name)

        for i in range(10):
            rd_port = randint(10000,65535)
            if rd_port not in ports:
                ports[rd_port] = now
                break
        if i == 10:
            return "oops"

        popen(f"timeout {alive_time} nc -lp {rd_port} < {rd_name} &")
        return {'port':rd_port,'alive_time':alive_time}

    except Exception as e:
        app.logger.info(str(e))
        return "fail"

@app.route('/getX')
def getSession():
    x = session.get('x',uuid4().hex)
    session['x'] = x
    app.logger.info(x)
    return {'fake_x':x[:-6],'hash':sha256(x.encode()).hexdigest()}

@app.route('/secret/<string:option>')
def secret(option):
    if option == 'get':
        return repr(ports)
    if option == 'clear':
        ports = {}
        return repr(ports)


if __name__ == '__main__':
    app.run(host='0.0.0.0',port=80,debug=True)