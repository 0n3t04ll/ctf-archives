import time
import re,os,sys
from flask import Flask,render_template,request

nums,locked = 0, False
app = Flask(__name__)

@app.route('/')
@app.route('/index')
def domain():
	return 'Hello'

@app.route('/create')
def create():
	try:
		global nums, locked
		assert not locked, "LOCKED"
		default_content = "<h1>2</h1>"
		locked = True
		if nums > 9999:
			raise Exception("templates full")

		with open(f'./templates/{nums}.html', 'w') as f:
			f.write(default_content)

		msg = render_template(f'{nums}.html')
		if msg != default_content:
			kill()
		nums += 1
	except Exception as e:
		msg = f"Something fail. {e}"
	locked = False
	return msg

@app.route('/show/<int:tid>')
def show(tid):
	try:
		global locked
		assert not locked, "LOCKED"
		
		locked = True
		if not os.path.exists(f'./templates/{tid}.html'):
			raise Exception('file not found')

		msg = render_template(f'{tid}.html')
	except Exception as e:
		msg = f"Something fail. {e}"
	locked = False
	return msg

@app.route('/edit/<int:tid>', methods = ["POST"])
def edit(tid):
	try:
		global locked
		assert not locked, "LOCKED"
		locked = True

		if not os.path.exists(f'./templates/{tid}.html'):
			raise Exception('file not found')

		if not request.files.get('edit.html'):
			raise Exception('Please give me edit file')

		f = request.files['edit.html']
		f.save(f'./templates/{tid}.html')
		msg = 'ok'
	except Exception as e:
		msg = f"Something fail. {e}"
	locked = False
	return msg

@app.route('/kill')
def kill():
	func = request.environ.get('werkzeug.server.shutdown')
	func()
	return 'server exiting.'

if not os.path.exists('templates'):
	os.system('mkdir templates')
else:
	os.system('rm ./templates/*.html')

app.run(host='0.0.0.0', port=5001)