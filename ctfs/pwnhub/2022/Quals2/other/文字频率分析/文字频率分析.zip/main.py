import os
import random
import base64
import time
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import io
from secret import flag
import hashlib

def pow(hard_level = 6):
    if hard_level >= 30:
        hard_level = 30

    m = hex(random.getrandbits(16 * 8))[2:]
    c = hashlib.md5(m.encode()).hexdigest()
    part = m[:32 - hard_level]
    print(f'plaintext: {part}' + '?' * hard_level)
    print(f'md5_hex -> {c}')
    return part, c

def crack(part, c, level = 6):
    s = int(part, 16) << (level * 4)
    _limit = s + (1 << level * 4)
    while s <= _limit:
        s += 1
        seed = hex(s)[2:].encode()
        if hashlib.md5(seed).hexdigest() == c:
            return seed

def getData(nums = 400):
    data = []
    result = [0 for _ in range(26)]
    for i in range(nums):
        c = random.randint(0, 25)
        data.append(c)
        result[c] += 1
    return data, result

def makeImage(data = [], size = 20):
    img = Image.new('RGB', (size * 50, size * 50))
    for y in range(size):
        for x in range(size):
            img.paste(pngs[data[x + y * size]], (x * 50, y * 50))
    content = io.BytesIO()
    img.save(content, 'png')
    img.save('flag.png')
    img.close()
    return content.getvalue()

def game():
    print("Easy pow:")
    pm, c = pow()
    m = input("What's is plaintext?\n> ")
    if hashlib.md5(m.encode()).hexdigest() != c:
        print('Failed')
        return

    data, result = getData()
    png = makeImage(data)
    print('now, you get a png: ')
    print(base64.b64encode(png).decode())
    print("##The end, please tell me your list:")
    _start = time.time()
    _input = input('> ').split(',')
    _end = time.time()

    if _end - _start > 10:
        print('timeouted')
        return

    if _input == result:
        print("Got it!")
        print(flag)
    else:
        print('Sorry, try again.')

if __name__ == '__main__':
    random.seed(0)
    print('loading pngs, please waiting...')
    pngs = []
    seed = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    for i in range(26):
        pngs.append(Image.open(f'/app/src/{seed[i]}.png').resize((50, 50), Image.ANTIALIAS))
    game()
