import os
import random
import base64
import time
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import io
from secret import flag
import hashlib

animals = ['cat', 'pig', 'tigger', 'dog', 'cattle', 'mouse', 'bird', 'chicken', 'rabbit', 'koala', 'horse', 'deer', 'lion', 'elephant']
names = ['1.jpg','10.jpg','2.jpg','3.jpg','4.jpg','5.jpg','6.jpg','7.jpg','8.jpg','9.jpg']

def pow(hard_level = 6):
    if hard_level >= 30:
        hard_level = 30

    m = hex(random.getrandbits(16 * 8))[2:]
    c = hashlib.md5(m.encode()).hexdigest()
    part = m[:32 - hard_level]
    print(f'plaintext: {part}' + '?' * hard_level)
    print(f'md5_hex -> {c}')
    return part, c

def crack(part, c, level = 6):
    s = int(part, 16) << (level * 4)
    _limit = s + (1 << level * 4)
    while s <= _limit:
        s += 1
        seed = hex(s)[2:].encode()
        if hashlib.md5(seed).hexdigest() == c:
            return seed

def game():
    print("Easy pow:")
    pm, c = pow()
    m = input("What's is plaintext?\n> ")
    if hashlib.md5(m.encode()).hexdigest() != c:
        print('Failed')
        return

    _score = 0
    for _ in range(10):
        animal = random.choice(animals)
        name = random.choice(names)
        img = Image.open(f'/app/animal/{animal}/{name}')
        img = img.rotate(random.randint(30, 170), expand = 1)
        x, y = img.size
        _rate = random.randint(-50, 10)
        x, y = int(x + x * _rate / 100), int(y + y * _rate / 100)
        img = img.resize((x, y), Image.ANTIALIAS)
        content = io.BytesIO()
        img.save(content, format='jpeg')
        print(base64.b64encode(content.getvalue()).decode())
        img.close()
        content.close()
        time.sleep(1)
        _start = time.time()
        _input = input("What's animal in this picture?\n> ")
        _end = time.time()

        if _end - _start > 3:
            print('timeouted')
            return

        if _input != animal:
            print(f"Oh, This is {animal}")
        else:
            print("Yes, it's")
            _score += 1

    if _score >= 8:
        print("Great, you are good.")
        print(flag)
    else:
        print('Failed')

if __name__ == '__main__':
    game()
