use anchor_lang::prelude::*;

pub const EMULATE_CLOCK_SEED: &[u8] = b"emulate_clock";
#[account]
#[derive(InitSpace)]
pub struct EmulateClock {
    pub timestamp: i64,
    pub bump: u8,
}


// pub const VAULT_SEED: &[u8] = b"vault";

pub const GLOBAL_SEED: &[u8] = b"global";

#[account]
#[derive(InitSpace)]
pub struct Global {
    pub admin: Pubkey,
    pub bump: u8,
    // pub vault_bump: u8,
    pub fee_mint: Pubkey,
    pub create_fee: u64,
    pub claim_fee: u64,
    pub stake_sol_amount: u64,
}

pub const FAUCET_SEED: &[u8] = b"faucet";

#[account]
pub struct Faucet {
    pub authority: Pubkey,
    pub bump: u8,
    // pub vault_bump: u8,
    pub mint: Pubkey,
    pub refund_account: Pubkey,
    pub max_claim_cnt: u64,
    pub claimed_cnt: u64,
    pub per_user_amount: u64,
    pub unlock_timestamp: i64,
    pub refund_timestamp: i64,
    pub stake_unlock_delay: u64,
    pub stake_claim_delay: u64,
    pub no_pda: bool,
}


pub const CLAIM_REQUEST_SEED: &[u8] = b"claim_request";

#[account]
pub struct ClaimRequest {
    pub faucet: Pubkey,
    pub receipt: Pubkey,
    pub user: Pubkey,
    pub claimed: bool,
    pub amount: u64,
    pub valid_timestamp: i64,
    pub claimed_timestamp: i64,
    pub bump: u8,
}

pub const USER_SEED: &[u8] = b"user";

#[account]
pub struct User {
    pub authority: Pubkey,
    pub unlock_timestamp: i64,
    pub stake_timestamp: i64,
    pub bump: u8,
}