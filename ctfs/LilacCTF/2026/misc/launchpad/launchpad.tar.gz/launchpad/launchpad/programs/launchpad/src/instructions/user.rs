use anchor_lang::{prelude::*, system_program::{self, Transfer}};
// use anchor_spl::token_interface::{Mint, TokenAccount, TransferChecked, transfer_checked};

use crate::states::*;
use crate::error::*;

#[derive(Accounts)]
pub struct CreateUser<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(
        init,
        payer = authority,
        seeds = [USER_SEED, authority.key().as_ref()],
        bump,
        space = 8 + core::mem::size_of::<User>(),
    )]
    pub user: Account<'info, User>,

    #[account(
        seeds = [GLOBAL_SEED],
        bump = global.bump
    )]
    pub global: Account<'info, Global>,

    // #[account(
    //     mint::token_program = fee_token_program,
    //     address = global.fee_mint
    // )]
    // pub fee_mint: Box<InterfaceAccount<'info, Mint>>,

    // #[account(
    //     mut,
    //     associated_token::mint = fee_mint,
    //     associated_token::authority = global,
    //     associated_token::token_program = fee_token_program,
    // )]
    // pub fee_vault: Box<InterfaceAccount<'info, TokenAccount>>,
    
    // #[account(
    //     mut,
    //     associated_token::mint = fee_mint,
    //     associated_token::authority = authority,
    //     associated_token::token_program = fee_token_program,
    // )]
    // pub user_fee_ta: Box<InterfaceAccount<'info, TokenAccount>>,

    // /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    // #[account(executable)]
    // pub fee_token_program: UncheckedAccount<'info>,

    #[account(
        seeds = [EMULATE_CLOCK_SEED],
        bump = emulate_clock.bump,
    )]
    pub emulate_clock: Account<'info, EmulateClock>,

    pub system_program: Program<'info, System>,
}

pub fn create_user_handler(ctx: Context<CreateUser>) -> Result<()> {
    let global = &ctx.accounts.global;
    let user = &mut ctx.accounts.user;
    let authority = &ctx.accounts.authority;
    
    user.set_inner(User {
        authority: *authority.key,
        unlock_timestamp: 0, // can unstake at anytime, since no claim is requested
        stake_timestamp: ctx.accounts.emulate_clock.timestamp,
        bump: ctx.bumps.user
    });

    system_program::transfer(
        CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            Transfer {
                from: authority.to_account_info(),
                to: user.to_account_info(),
            }
        ),
        global.stake_sol_amount
    )?;

    // if global.create_fee != 0 {
    //     transfer_checked(
    //         CpiContext::new(
    //             ctx.accounts.fee_token_program.to_account_info(),
    //             TransferChecked {
    //                 from: ctx.accounts.user_fee_ta.to_account_info(),
    //                 to: ctx.accounts.fee_vault.to_account_info(),
    //                 mint: ctx.accounts.fee_mint.to_account_info(),
    //                 authority: authority.to_account_info(),
    //             }
    //         ),
    //         global.create_fee,
    //         ctx.accounts.fee_mint.decimals
    //     )?;
    // }
    Ok(())
}



#[derive(Accounts)]
pub struct CloseUser<'info> {
    #[account(
        mut,
        address = user.authority
    )]
    pub authority: Signer<'info>,

    #[account(
        mut,
        close = authority,
        seeds = [USER_SEED, user.authority.as_ref()],
        bump = user.bump,
    )]
    pub user: Account<'info, User>,

    #[account(
        seeds = [GLOBAL_SEED],
        bump = global.bump
    )]
    pub global: Account<'info, Global>,

    #[account(
        seeds = [EMULATE_CLOCK_SEED],
        bump = emulate_clock.bump,
    )]
    pub emulate_clock: Account<'info, EmulateClock>,
    pub system_program: Program<'info, System>,
}

pub fn close_user_handler(ctx: Context<CloseUser>) -> Result<()> {
    require_gte!(
        ctx.accounts.emulate_clock.timestamp,
        ctx.accounts.user.unlock_timestamp,
        FaucetError::UserStakeNotUnlocked
    );
    
    Ok(())
}
