use anchor_lang::prelude::*;
use anchor_spl::associated_token::AssociatedToken;
use anchor_spl::token_interface::{TokenAccount, Mint};

use crate::states::*;

#[derive(Accounts)]
pub struct InitializeGlobal<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,

    #[account(
        init,
        payer = admin,
        seeds = [GLOBAL_SEED],
        bump,
        space = 8 + core::mem::size_of::<Global>(),
    )]
    pub global: Account<'info, Global>,

    #[account(
        mint::token_program = token_program,
    )]
    pub fee_mint: InterfaceAccount<'info, Mint>,

    #[account(
        init_if_needed,
        payer = admin,
        associated_token::mint = fee_mint,
        associated_token::authority = global,
        associated_token::token_program = token_program,
    )]
    pub fee_vault: InterfaceAccount<'info, TokenAccount>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub token_program: UncheckedAccount<'info>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(AnchorSerialize, AnchorDeserialize)]
pub struct InitializeGlobalArgs {
    pub create_fee: u64,
    pub claim_fee: u64,
    pub stake_sol_amount: u64, // must stake sol before opening new user account, prevent spam
}

pub fn initialize_global_handler(ctx: Context<InitializeGlobal>, args: InitializeGlobalArgs) -> Result<()> {
    ctx.accounts.global.set_inner(Global {
        bump: ctx.bumps.global,
        admin: *ctx.accounts.admin.key,
        fee_mint: ctx.accounts.fee_mint.key(),
        create_fee: args.create_fee,
        claim_fee: args.claim_fee,
        stake_sol_amount: args.stake_sol_amount,
    });
    Ok(())
}
