use anchor_lang::prelude::*;

#[error_code]
pub enum FaucetError {
    #[msg("Invalid initialize arguments")]
    InvalidInitializeArgs,
    #[msg("Reach max claim limit")]
    ReachMaxClaimLimit,
    #[msg("Claim too early")]
    ClaimTooEarly,
    #[msg("Claim too late")]
    ClaimTooLate,
    #[msg("PDA not allowed")]
    PdaNotAllowed,
    #[msg("Remaining accounts count mismatch")]
    RemainingAccountsCountMismatch,
    #[msg("Receipt mismatch")]
    ReceiptMismatch,
    #[msg("Claim request PDA mismatch")]
    ClaimRequestPdaMismatch,
    #[msg("Already claimed")]
    AlreadyClaimed,
    #[msg("User stake not unlocked yet")]
    UserStakeNotUnlocked,
    #[msg("Refund too early")]
    RefundTooEarly,
}
