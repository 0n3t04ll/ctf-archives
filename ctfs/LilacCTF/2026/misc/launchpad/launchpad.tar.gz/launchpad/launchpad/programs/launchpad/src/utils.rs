use anchor_lang::prelude::*;

pub const CURVE25519_EDWARDS: u64 = 0;
pub const CURVE25519_RISTRETTO: u64 = 1;

pub fn is_on_curve(pubkey: &Pubkey) -> bool {
    #[cfg(not(target_os = "solana"))]
    {
        return Pubkey::is_on_curve(pubkey);
    }
    // https://github.com/anza-xyz/agave/blob/3af0acb63e89d8dd224741f4ccbffc28a107b15b/programs/bpf_loader/src/syscalls/mod.rs#L1031
    // https://github.com/solana-labs/solana/blob/7700cb3128c1f19820de67b81aa45d18f73d2ac0/zk-token-sdk/src/curve25519/edwards.rs#L143-L153 
    #[cfg(target_os = "solana")]
    {
        let mut _useless = 0u8;
        let result = unsafe {
            anchor_lang::solana_program::syscalls::sol_curve_validate_point(
                CURVE25519_EDWARDS,
                pubkey.as_array() as *const u8,
                &mut _useless,
            )
        };
        return result == 0;
    }
}