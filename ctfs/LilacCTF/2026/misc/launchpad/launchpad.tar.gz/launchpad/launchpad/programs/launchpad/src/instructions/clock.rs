use anchor_lang::prelude::*;
use crate::states::*;


#[derive(Accounts)]
pub struct InitializeEmulateClock<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        init,
        payer = payer,
        seeds = [EMULATE_CLOCK_SEED],
        bump,
        space = 8 + core::mem::size_of::<EmulateClock>(),
    )]
    pub emulate_clock: Account<'info, EmulateClock>,

    pub system_program: Program<'info, System>,
}

pub fn initialize_emulate_clock_handler(
    ctx: Context<InitializeEmulateClock>
) -> Result<()> {
    ctx.accounts.emulate_clock.set_inner(EmulateClock {
        timestamp: Clock::get()?.unix_timestamp,
        bump: ctx.bumps.emulate_clock
    });
    Ok(())
}

#[derive(Accounts)]
pub struct TweakEmulateClock<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        mut,
        seeds = [EMULATE_CLOCK_SEED],
        bump = emulate_clock.bump,
    )]
    pub emulate_clock: Account<'info, EmulateClock>,
}

pub fn tweak_emulate_clock_handler(
    ctx: Context<TweakEmulateClock>,
    delta: u64,
) -> Result<()> {
    msg!("before tweak: {}", ctx.accounts.emulate_clock.timestamp);
    ctx.accounts.emulate_clock.timestamp = ctx.accounts.emulate_clock.timestamp.checked_add(delta.try_into()?).unwrap();
    msg!("after tweak: {}", ctx.accounts.emulate_clock.timestamp);
    Ok(())
}

