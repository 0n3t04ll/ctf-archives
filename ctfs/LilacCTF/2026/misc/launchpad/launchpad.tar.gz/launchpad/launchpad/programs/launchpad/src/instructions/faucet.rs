use anchor_lang::prelude::*;
use anchor_spl::associated_token::AssociatedToken;
use anchor_spl::token_interface::{TokenAccount, Mint, mint_to, MintTo, TransferChecked, transfer_checked, CloseAccount, close_account};

use crate::states::*;
use crate::error::*;

#[derive(Accounts)]
pub struct CreateFaucet<'info> {
    #[account(mut)]
    pub authority: Signer<'info>, // must be the mint authority of faucet_mint

    #[account(
        seeds = [GLOBAL_SEED],
        bump = global.bump
    )]
    pub global: Account<'info, Global>,

    #[account(
        mint::token_program = fee_token_program,
        address = global.fee_mint
    )]
    pub fee_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(
        mut,
        associated_token::mint = fee_mint,
        associated_token::authority = global,
        associated_token::token_program = fee_token_program,
    )]
    pub fee_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(
        mut,
        associated_token::mint = fee_mint,
        associated_token::authority = authority,
        associated_token::token_program = fee_token_program,
    )]
    pub user_fee_ta: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub fee_token_program: UncheckedAccount<'info>,

    #[account(
        mut,
        mint::token_program = faucet_token_program,
    )]
    pub faucet_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(
        init,
        payer = authority,
        seeds = [FAUCET_SEED, faucet_mint.key().as_ref()],
        bump,
        space = 8 + core::mem::size_of::<Faucet>(),
    )]
    pub faucet: Account<'info, Faucet>,

    #[account(
        init_if_needed, // prevent DoS
        payer = authority,
        associated_token::mint = faucet_mint,
        associated_token::authority = global,
        associated_token::token_program = faucet_token_program,
    )]
    pub faucet_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(
        token::mint = faucet_mint,
        token::token_program = faucet_token_program,
    )] // can refund to any account
    pub refund_account: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub faucet_token_program: UncheckedAccount<'info>,
    
    #[account(
        seeds = [EMULATE_CLOCK_SEED],
        bump = emulate_clock.bump,
    )]
    pub emulate_clock: Account<'info, EmulateClock>,

    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(AnchorSerialize, AnchorDeserialize)]
pub struct CreateFaucetArgs {
    pub per_user_amount: u64,
    pub max_claim_cnt: u64,
    pub unlock_timestamp: Option<i64>,
    pub valid_period: Option<u64>,
    pub stake_unlock_delay: u64,
    pub stake_claim_delay: u64,
    pub no_pda: bool,
}

pub fn create_faucet_handler(ctx: Context<CreateFaucet>, args: CreateFaucetArgs) -> Result<()> {

    let unlock_timestamp = args.unlock_timestamp.unwrap_or(ctx.accounts.emulate_clock.timestamp);
    let valid_period = args.valid_period.unwrap_or(u64::MAX);

    let refund_timestamp = unlock_timestamp.saturating_add(valid_period.try_into()?);
    
    // user can only claim between [unlock_timestamp, refund_timestamp)
    // user can claim back stake assets after +stake_unlock_delay
    // user can claim from faucet only after stake for stake_claim_delay

    require_gt!(
        refund_timestamp,
        unlock_timestamp,
        FaucetError::InvalidInitializeArgs
    );

    if ctx.accounts.global.create_fee != 0 {
        transfer_checked(
            CpiContext::new(
                ctx.accounts.fee_token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.user_fee_ta.to_account_info(),
                    to: ctx.accounts.fee_vault.to_account_info(),
                    mint: ctx.accounts.fee_mint.to_account_info(),
                    authority: ctx.accounts.authority.to_account_info(),
                }
            ),
            ctx.accounts.global.create_fee,
            ctx.accounts.fee_mint.decimals
        )?;
    }

    ctx.accounts.faucet.set_inner(Faucet {
        authority: *ctx.accounts.authority.key,
        bump: ctx.bumps.faucet,
        mint: ctx.accounts.faucet_mint.key(),
        refund_account: ctx.accounts.refund_account.key(),
        max_claim_cnt: args.max_claim_cnt,
        per_user_amount: args.per_user_amount,
        claimed_cnt: 0,
        unlock_timestamp: unlock_timestamp,
        refund_timestamp: refund_timestamp,
        stake_unlock_delay: args.stake_unlock_delay,
        stake_claim_delay: args.stake_claim_delay,
        no_pda: args.no_pda
    });

    let total_amount = args.max_claim_cnt.checked_mul(args.per_user_amount).unwrap();

    let cpi_accounts = MintTo {
        mint: ctx.accounts.faucet_mint.to_account_info(),
        to: ctx.accounts.faucet_vault.to_account_info(),
        authority: ctx.accounts.authority.to_account_info()
    };
    let cpi_ctx = CpiContext::new(
        ctx.accounts.faucet_token_program.to_account_info(),
        cpi_accounts
    );
    mint_to(cpi_ctx, total_amount)
}


#[derive(Accounts)]
pub struct CloseFaucet<'info> {
    #[account(
        mut,
        address = faucet.authority,
    )]
    pub authority: Signer<'info>, // must be the mint authority of faucet_mint

    #[account(
        seeds = [GLOBAL_SEED],
        bump = global.bump
    )]
    pub global: Account<'info, Global>,

    #[account(
        mint::token_program = faucet_token_program,
        address = faucet_mint.key()
    )]
    pub faucet_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(
        mut,
        close = authority,
        seeds = [FAUCET_SEED, faucet.mint.as_ref()],
        bump = faucet.bump
    )]
    pub faucet: Account<'info, Faucet>,

    #[account(
        mut,
        associated_token::mint = faucet_mint,
        associated_token::authority = global,
        associated_token::token_program = faucet_token_program,
    )]
    pub faucet_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(
        mut,
        token::mint = faucet_mint,
        token::token_program = faucet_token_program,
        address = faucet.refund_account
    )] // can refund to any account
    pub refund_account: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub faucet_token_program: UncheckedAccount<'info>,

    #[account(
        seeds = [EMULATE_CLOCK_SEED],
        bump = emulate_clock.bump,
    )]
    pub emulate_clock: Account<'info, EmulateClock>,

    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

pub fn close_faucet_handler(ctx: Context<CloseFaucet>) -> Result<()> {

    let faucet = &ctx.accounts.faucet;
    let faucet_vault = &ctx.accounts.faucet_vault;

    let now_timestamp = ctx.accounts.emulate_clock.timestamp;

    if ctx.accounts.faucet_vault.amount != 0 || faucet.max_claim_cnt != faucet.claimed_cnt {
        require_gte!(
            now_timestamp,
            faucet.refund_timestamp,
            FaucetError::RefundTooEarly
        );
    }

    let signer_seeds: &[&[&[u8]]] = &[&[
        GLOBAL_SEED,
        &[faucet.bump]
    ]];
    
    transfer_checked(
        CpiContext::new_with_signer(
            ctx.accounts.faucet_token_program.to_account_info(),
            TransferChecked {
                from: faucet_vault.to_account_info(),
                to: ctx.accounts.refund_account.to_account_info(),
                mint: ctx.accounts.faucet_mint.to_account_info(),
                authority: ctx.accounts.global.to_account_info(),
            },
            signer_seeds
        ),
        faucet_vault.amount,
        ctx.accounts.faucet_mint.decimals
    )?;

    close_account(
        CpiContext::new_with_signer(
            ctx.accounts.faucet_token_program.to_account_info(),
            CloseAccount {
                account: faucet_vault.to_account_info(),
                destination: ctx.accounts.authority.to_account_info(),
                authority: ctx.accounts.global.to_account_info(),
            },
            signer_seeds
        )
    )?;

    Ok(())

}