use anchor_lang::prelude::*;
use anchor_spl::associated_token::AssociatedToken;
use anchor_spl::token_interface::{Mint, TokenAccount, TransferChecked, transfer_checked};

use itertools::Itertools;

use crate::states::*;
use crate::error::*;
use crate::utils::*;

#[derive(Accounts)]
pub struct CreateClaimRequest<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(
        mut,
        constraint = user.authority == *authority.key,
        seeds = [USER_SEED, user.authority.as_ref()],
        bump = user.bump
    )]
    pub user: Account<'info, User>,

    #[account(
        seeds = [GLOBAL_SEED],
        bump = global.bump
    )]
    pub global: Account<'info, Global>,

    #[account(
        mint::token_program = fee_token_program,
        address = global.fee_mint
    )]
    pub fee_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(
        mut,
        associated_token::mint = fee_mint,
        associated_token::authority = global,
        associated_token::token_program = fee_token_program,
    )]
    pub fee_vault: Box<InterfaceAccount<'info, TokenAccount>>,
    
    #[account(
        mut,
        token::mint = fee_mint,
        token::authority = authority,
        token::token_program = fee_token_program,
    )]
    pub user_fee_ta: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub fee_token_program: UncheckedAccount<'info>,

    #[account(
        mut,
        seeds = [FAUCET_SEED, faucet.mint.as_ref()],
        bump = faucet.bump
    )]
    pub faucet: Account<'info, Faucet>,

    #[account(
        mint::token_program = faucet_token_program,
    )]
    pub faucet_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(
        init,
        payer = authority,
        seeds = [CLAIM_REQUEST_SEED, faucet.key().as_ref(), user.key().as_ref()],
        bump,
        space = 8 + core::mem::size_of::<ClaimRequest>(),
    )]
    pub claim_request: Account<'info, ClaimRequest>,

    #[account(
        init_if_needed,
        payer = authority,
        associated_token::mint = faucet_mint,
        associated_token::authority = authority,
        associated_token::token_program = faucet_token_program,
    )]
    pub receipt: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub faucet_token_program: UncheckedAccount<'info>,

    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

pub fn create_claim_request_handler(ctx: Context<CreateClaimRequest>) -> Result<()> {
    let global = &ctx.accounts.global;
    let user = &mut ctx.accounts.user;
    let authority = &ctx.accounts.authority;
    let faucet = &mut ctx.accounts.faucet;

    // no stake time check here, users can always create request first
    // time check will be delay to claim_batch instead
    // which will be called by a off-chain bot
    // automatically collect all valid requests
    faucet.claimed_cnt = faucet.claimed_cnt.checked_add(1).unwrap(); // SECURITY: High risk of DoS

    require_gte!(
        faucet.max_claim_cnt,
        faucet.claimed_cnt,
        FaucetError::ReachMaxClaimLimit
    );
    
    ctx.accounts.claim_request.set_inner(ClaimRequest {
        faucet: faucet.key(),
        receipt: ctx.accounts.receipt.key(),
        user: user.key(),
        claimed: false,
        amount: faucet.per_user_amount,
        valid_timestamp: user.stake_timestamp.checked_add(faucet.stake_claim_delay.try_into()?).unwrap(),
        claimed_timestamp: 0,
        bump: ctx.bumps.claim_request
    });

    user.unlock_timestamp = user.unlock_timestamp.max(
        faucet.refund_timestamp.checked_add(faucet.stake_unlock_delay.try_into()?).unwrap()
    ); // we don't know when will refund called, so lets just use refund_timestamp as claimed timestamp, require user to stake sol until refund_timestamp + stake_unlock_delay

    // claim_fee charged here so we can reduce the accounts needed in claim_batch
    if global.claim_fee != 0 {
        transfer_checked(
            CpiContext::new(
                ctx.accounts.fee_token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.user_fee_ta.to_account_info(),
                    to: ctx.accounts.fee_vault.to_account_info(),
                    mint: ctx.accounts.fee_mint.to_account_info(),
                    authority: authority.to_account_info(),
                }
            ),
            global.claim_fee,
            ctx.accounts.fee_mint.decimals
        )?;
    }


    Ok(())
}

#[derive(Accounts)]
pub struct SimpleClaim<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(
        mut,
        constraint = user.authority == *authority.key,
        seeds = [USER_SEED, user.authority.as_ref()],
        bump = user.bump
    )]
    pub user: Account<'info, User>,

    #[account(
        seeds = [GLOBAL_SEED],
        bump = global.bump
    )]
    pub global: Account<'info, Global>,

    #[account(
        mint::token_program = fee_token_program,
        address = global.fee_mint
    )]
    pub fee_mint: Box<InterfaceAccount<'info, Mint>>, // Box to avoid stack too large

    #[account(
        mut,
        associated_token::mint = fee_mint,
        associated_token::authority = global,
        associated_token::token_program = fee_token_program,
    )]
    pub fee_vault: Box<InterfaceAccount<'info, TokenAccount>>,
    
    #[account(
        mut,
        token::mint = fee_mint,
        token::authority = authority,
        token::token_program = fee_token_program,
    )]
    pub user_fee_ta: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub fee_token_program: UncheckedAccount<'info>,


    #[account(
        mut,
        seeds = [FAUCET_SEED, faucet.mint.as_ref()],
        bump = faucet.bump
    )]
    pub faucet: Account<'info, Faucet>,

    #[account(
        mint::token_program = faucet_token_program,
        address = faucet.mint
    )]
    pub faucet_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(
        mut,
        associated_token::mint = faucet_mint,
        associated_token::authority = global,
        associated_token::token_program = faucet_token_program,
    )]
    pub faucet_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(
        init_if_needed,
        payer = authority,
        associated_token::mint = faucet_mint,
        associated_token::authority = authority,
        associated_token::token_program = faucet_token_program,
    )]
    pub receipt: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(
        init,
        payer = authority,
        seeds = [CLAIM_REQUEST_SEED, faucet.key().as_ref(), user.key().as_ref()],
        bump,
        space = 8 + core::mem::size_of::<ClaimRequest>(),
    )] // we still need to create ClaimRequest to prevent double claim
    pub claim_request: Account<'info, ClaimRequest>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub faucet_token_program: UncheckedAccount<'info>,
    
    #[account(
        seeds = [EMULATE_CLOCK_SEED],
        bump = emulate_clock.bump,
    )]
    pub emulate_clock: Account<'info, EmulateClock>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

pub fn simple_claim_handler(ctx: Context<SimpleClaim>) -> Result<()> {
    let global = &ctx.accounts.global;
    let user = &mut ctx.accounts.user;
    let authority = &ctx.accounts.authority;
    let faucet = &mut ctx.accounts.faucet;

    let now_timestamp = ctx.accounts.emulate_clock.timestamp;

    // no stake time check here, users can always create request first
    // time check will be delay to claim_batch instead
    // which will be called by a off-chain bot
    // automatically collect all valid requests
    faucet.claimed_cnt = faucet.claimed_cnt.checked_add(1).unwrap();

    require_gte!(
        faucet.max_claim_cnt,
        faucet.claimed_cnt,
        FaucetError::ReachMaxClaimLimit
    );

    require_gte!(
        now_timestamp,
        user.stake_timestamp.checked_add(faucet.stake_claim_delay.try_into()?).unwrap(),
        FaucetError::ClaimTooEarly
    );

    require_gt!(
        faucet.refund_timestamp,
        now_timestamp,
        FaucetError::ClaimTooLate
    );

    if faucet.no_pda {
        require!(is_on_curve(authority.key), FaucetError::PdaNotAllowed);
    }
    
    ctx.accounts.claim_request.set_inner(ClaimRequest {
        faucet: faucet.key(),
        receipt: ctx.accounts.receipt.key(),
        user: user.key(),
        claimed: true,
        amount: faucet.per_user_amount,
        valid_timestamp: now_timestamp,
        claimed_timestamp: now_timestamp,
        bump: ctx.bumps.claim_request
    });

    user.unlock_timestamp = user.unlock_timestamp.max(
        now_timestamp.checked_add(faucet.stake_unlock_delay.try_into()?).unwrap()
    );

    if global.claim_fee != 0 {
        transfer_checked(
            CpiContext::new(
                ctx.accounts.fee_token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.user_fee_ta.to_account_info(),
                    to: ctx.accounts.fee_vault.to_account_info(),
                    mint: ctx.accounts.fee_mint.to_account_info(),
                    authority: authority.to_account_info(),
                }
            ),
            global.claim_fee,
            ctx.accounts.fee_mint.decimals
        )?;
    }

    transfer_checked(
        CpiContext::new_with_signer(
            ctx.accounts.faucet_token_program.to_account_info(),
            TransferChecked {
                from: ctx.accounts.faucet_vault.to_account_info(),
                to: ctx.accounts.receipt.to_account_info(),
                mint: ctx.accounts.faucet_mint.to_account_info(),
                authority: global.to_account_info(),
            },
            &[&[
                GLOBAL_SEED,
                &[global.bump]
            ]]
        ),
        faucet.per_user_amount,
        ctx.accounts.fee_mint.decimals
    )
}

#[derive(Accounts)]
pub struct ClaimBatch<'info> {
    #[account(
        seeds = [GLOBAL_SEED],
        bump = global.bump
    )]
    pub global: Account<'info, Global>,

    #[account(
        seeds = [FAUCET_SEED, faucet.mint.as_ref()],
        bump = faucet.bump
    )]
    pub faucet: Account<'info, Faucet>,

    #[account(
        mint::token_program = faucet_token_program,
        address = faucet.mint
    )]
    pub faucet_mint: InterfaceAccount<'info, Mint>,

    #[account(
        mut,
        associated_token::mint = faucet_mint,
        associated_token::authority = global,
        associated_token::token_program = faucet_token_program,
    )]
    pub faucet_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: For forward compatibility, we don't restrict the token program - who knows, maybe one day there will be a Token 2077.
    #[account(executable)]
    pub faucet_token_program: UncheckedAccount<'info>,

    #[account(
        seeds = [EMULATE_CLOCK_SEED],
        bump = emulate_clock.bump,
    )]
    pub emulate_clock: Account<'info, EmulateClock>,

    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}


pub fn claim_batch_handler<'info>(ctx: Context<'_, '_, 'info, 'info, ClaimBatch<'info>>) -> Result<()> {

    let remaining_iter = ctx.remaining_accounts.iter();
    let faucet = &ctx.accounts.faucet;
    // let global = &ctx.accounts.global;

    let now_timestamp = ctx.accounts.emulate_clock.timestamp;

    require!(remaining_iter.len() % 2 == 0, FaucetError::RemainingAccountsCountMismatch);

    require_gt!(
        faucet.refund_timestamp,
        now_timestamp,
        FaucetError::ClaimTooLate
    );

    for (claim_request, receipt) in remaining_iter.tuples() {
        let receipt_ta = TokenAccount::try_deserialize(&mut &receipt.try_borrow_data()?[..])?;
        if faucet.no_pda {
            require!(is_on_curve(&receipt_ta.owner), FaucetError::PdaNotAllowed);
        }

        // don't need to check mint or whatever, transfer will check for us

        let mut claim_request_account = Account::<ClaimRequest>::try_from(claim_request)?;

        let (expected_claim_request, _claim_bump) = Pubkey::find_program_address(
            &[CLAIM_REQUEST_SEED, claim_request_account.faucet.as_ref(), claim_request_account.user.as_ref()],
            &crate::id(),
        );
        
        require_keys_eq!(
            expected_claim_request,
            *claim_request.key,
            FaucetError::ClaimRequestPdaMismatch
        );

        require_keys_eq!(
            claim_request_account.receipt,
            *receipt.key,
            FaucetError::ReceiptMismatch
        );

        require_gte!(
            now_timestamp,
            claim_request_account.valid_timestamp,
            FaucetError::ClaimTooEarly
        );

        require!(
            !claim_request_account.claimed,
            FaucetError::AlreadyClaimed
        );

        transfer_checked(
            CpiContext::new_with_signer(
                ctx.accounts.faucet_token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.faucet_vault.to_account_info(),
                    to: receipt.clone(),
                    mint: ctx.accounts.faucet_mint.to_account_info(),
                    authority: ctx.accounts.global.to_account_info(),
                },
                &[&[
                    GLOBAL_SEED,
                    &[ctx.accounts.global.bump]
                ]]
            ),
            claim_request_account.amount,
            ctx.accounts.faucet_mint.decimals
        )?;

        claim_request_account.claimed = true;
        claim_request_account.claimed_timestamp = now_timestamp;

        claim_request_account.exit(&crate::id())?;
    }

    Ok(())
}
