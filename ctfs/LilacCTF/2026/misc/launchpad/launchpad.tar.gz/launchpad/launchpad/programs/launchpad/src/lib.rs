#![allow(unexpected_cfgs)]
use anchor_lang::prelude::*;

declare_id!("4Y2Xg2yiHNCzEvfsz9DjGBzhCinu3z7R6pG3RbDqVgUd");

pub mod error;
pub mod instructions;
pub mod states;
pub mod utils;

pub use anchor_lang;

pub use instructions::*;

#[program]
pub mod launchpad {
    use super::*;

    pub fn initialize_global(ctx: Context<InitializeGlobal>, args: InitializeGlobalArgs) -> Result<()> {
        initialize_global_handler(ctx, args)
    }

    pub fn create_faucet(
        ctx: Context<CreateFaucet>,
        args: CreateFaucetArgs,
    ) -> Result<()> {
        create_faucet_handler(ctx, args)
    }

    pub fn close_faucet(
        ctx: Context<CloseFaucet>,
    ) -> Result<()> {
        close_faucet_handler(ctx)
    }

    pub fn create_user(
        ctx: Context<CreateUser>,
    ) -> Result<()> {
        create_user_handler(ctx)
    }

    pub fn close_user(
        ctx: Context<CloseUser>,
    ) -> Result<()> {
        close_user_handler(ctx)
    }
    
    pub fn simple_claim(
        ctx: Context<SimpleClaim>,
    ) -> Result<()> {
        simple_claim_handler(ctx)
    }
    
    pub fn create_claim_request(
        ctx: Context<CreateClaimRequest>,
    ) -> Result<()> {
        create_claim_request_handler(ctx)
    }

    pub fn claim_batch<'info>(
        ctx: Context<'_, '_, 'info, 'info, ClaimBatch<'info>>,
    ) -> Result<()> {
        claim_batch_handler(ctx)
    }

    pub fn initialize_emulate_clock(
        ctx: Context<InitializeEmulateClock>,
    ) -> Result<()> {
        initialize_emulate_clock_handler(ctx)
    }

    pub fn tweak_emulate_clock(
        ctx: Context<TweakEmulateClock>,
        delta: u64,
    ) -> Result<()> {
        tweak_emulate_clock_handler(ctx, delta)
    }

}
