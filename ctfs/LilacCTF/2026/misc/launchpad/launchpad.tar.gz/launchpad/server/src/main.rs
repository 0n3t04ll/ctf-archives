use launchpad::{CreateFaucetArgs, InitializeGlobalArgs};
use challenge::ChallengeBuilder;
use challenge::ProofOfWork;
use solana_program_test::tokio;

use solana_sdk::{
    pubkey::Pubkey, signature::Keypair, signer::Signer,
    system_instruction,
};
use spl_associated_token_account::get_associated_token_address;
use std::env;
use std::io::Write;
use std::{
    io::BufReader,
    net::{TcpListener, TcpStream},
};
use utils::get_line;

pub mod challenge;
pub mod utils;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let listener = TcpListener::bind("0.0.0.0:1337")?;
    println!("starting server at port 1337!");
    for stream in listener.incoming() {
        if stream.is_err() {
            println!("error: {:?}", stream.err());
            continue;
        }
        let mut stream = stream.unwrap();

        tokio::spawn(async move {
            if let Err(err) = handle_connection(&mut stream).await {
                let _ = writeln!(stream, "error: {:?}", err);
                println!("error: {:?}", err);
            }
        });
    }
    Ok(())
}

async fn handle_pow(socket: &mut TcpStream) -> anyhow::Result<()> {
    let pow = ProofOfWork::new();
    let prefix = pow.prefix.clone();
    writeln!(socket, "prefix: {}", prefix)?;
    let mut reader = BufReader::new(socket.try_clone()?);
    let nonce = get_line(&mut reader)?;
    let nonce = nonce.parse::<u128>()?;
    if !pow.verify(nonce) {
        writeln!(socket, "invalid nonce")?;
        return Err(anyhow::anyhow!("invalid nonce"));
    };
    Ok(())
}

const SOLVE_ID: Pubkey = Pubkey::from_str_const("BXMft3v8jaZSdN9y5MsoJHAomREuQfHpjLAGdQfHA1Ph");

async fn handle_connection(socket: &mut TcpStream) -> anyhow::Result<()> {

    // Proof of Work
    handle_pow(socket).await?;

    // Prepare challenge
    //
    // 1. load challenge program
    let mut builder = ChallengeBuilder::try_from(socket.try_clone().unwrap()).unwrap();

    assert!(builder.input_program(SOLVE_ID)? == SOLVE_ID);

    assert!(builder.add_program("./launchpad.so", Some(launchpad::ID)) == launchpad::ID);

    let mut chall = builder.build().await;

    // 2. create user account
    let user_keypair = Keypair::new();
    let user = user_keypair.pubkey();

    let admin_keypair = &chall.ctx.payer;
    let admin = admin_keypair.pubkey();

    // 3. airdrop for gas fee
    chall
        .run_ix(system_instruction::transfer(&admin, &user, 1_000_000_000)) // 1 sol
        .await?;

    // 4. prepare mint and token account
    let fee_mint = chall.add_mint(&admin, 0).await?;
    let admin_ata = get_associated_token_address(
        &admin,
        &fee_mint,
    );

    let faucet_mint = fee_mint.clone();
    
    // 5. initialize
    let init_ixs = [
        chall.create_ata_instruction(&admin, &admin, &fee_mint).await?,
        chall.mint_to_instruction(10_000, &fee_mint, &admin_ata).await?,
        chall.initialize_global_instruction(
            &admin,
            &fee_mint,
            InitializeGlobalArgs {
                create_fee: 100,
                claim_fee: 0,
                stake_sol_amount: 700_000_000, // 0.7 sol
            }
        ).await?,
        chall.initialize_emulate_clock_instruction(
            &admin,
        ),
    ];

    chall.run_ixs(&init_ixs).await?;

    // 6. create faucet
    let create_faucet_ixs = [
        chall.create_faucet_instruction(
            &admin, 
            &faucet_mint, 
            &admin_ata,
            CreateFaucetArgs {
                per_user_amount: 50,
                max_claim_cnt: 10,
                unlock_timestamp: None,
                valid_period: Some(3600 * 24),
                stake_unlock_delay: 3600,
                stake_claim_delay: 3600,
                no_pda: true
            },
        ).await?
    ];
    chall.run_ixs(&create_faucet_ixs).await?;

    // 7. run user instructions
    writeln!(socket, "admin: {}", admin)?;
    writeln!(socket, "user: {}", user)?;
    writeln!(socket, "fee_mint: {}", fee_mint)?;
    writeln!(socket, "faucet_mint: {}", faucet_mint)?;
    
    let solve_ixs = chall.read_instructions().await?;

    chall
        .run_ixs_full(&solve_ixs, &[&user_keypair], &user)
        .await?;

    // 8. verify solution

    let faucet_vault = chall.get_faucet_vault(&faucet_mint);
    let fee_vault = chall.get_faucet_vault(&fee_mint);

    if let Ok(ta) = chall.read_token_account(&faucet_vault).await {
        if ta.amount != 0 {
            writeln!(socket, "faucet vault not empty")?;
            return Ok(());
        }
    }

    if let Ok(ta) = chall.read_token_account(&fee_vault).await {
        if ta.amount != 0 {
            writeln!(socket, "fee vault not empty")?;
            return Ok(());
        }
    }

    writeln!(socket, "congrats! you won the flag!")?;
    if let Ok(flag) = env::var("FLAG") {
        writeln!(socket, "flag: {}", flag)?;
    } else {
        writeln!(socket, "flag not found, please contact admin")?;
    }
    Ok(())
}
