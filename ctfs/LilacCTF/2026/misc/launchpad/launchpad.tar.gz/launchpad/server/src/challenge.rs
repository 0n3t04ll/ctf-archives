use rand::distributions::Alphanumeric;
use rand::Rng;
use sha2::{Digest, Sha256};
use solana_program_test::{ProgramTest, ProgramTestContext};
use solana_sdk::signer::signers::Signers;
use solana_sdk::{signature::Signer, transaction::Transaction};
use std::fs::File;
use std::io::{BufRead, BufReader, Write};
use std::net::TcpStream;

use launchpad::anchor_lang::{AccountDeserialize, InstructionData, ToAccountMetas};
use launchpad::{InitializeGlobalArgs, CreateFaucetArgs};

use spl_associated_token_account::{get_associated_token_address, get_associated_token_address_with_program_id};

use solana_sdk::{
    instruction::Instruction,
    pubkey::Pubkey,
    signature::Keypair,
};

use spl_token::solana_program::program_pack::Pack;
use tempfile::Builder;

mod helpers {
    use rand::{prelude::StdRng, SeedableRng};
    use sha2::{Digest, Sha256};
    use solana_sdk::signature::Keypair;

    pub fn keypair_from_data(data: &[u8]) -> Keypair {
        let mut hash = Sha256::default();
        hash.update(&data);

        // panic here is probably fine since this should always be 32 bytes, regardless of user input
        let mut rng = StdRng::from_seed(hash.finalize()[..].try_into().unwrap());
        Keypair::generate(&mut rng)
    }
}

pub struct ProofOfWork {
    pub prefix: String,
}

impl ProofOfWork {
    const DIFFICULTY: usize = 5;

    pub fn new() -> Self {
        let prefix: String = rand::thread_rng()
            .sample_iter(&Alphanumeric)
            .take(10)
            .map(char::from)
            .collect();
        Self { prefix }
    }

    pub fn verify(&self, nonce: u128) -> bool {
        let mut hasher = Sha256::new();
        hasher.update(format!("{}{}", self.prefix, nonce));
        let result = hasher.finalize();
        let hex_result = format!("{:x}", result);

        hex_result.starts_with(&"0".repeat(Self::DIFFICULTY))
    }
}

pub struct Challenge<R: BufRead, W: Write> {
    input: R,
    output: W,
    pub ctx: ProgramTestContext,
}

pub struct ChallengeBuilder<R: BufRead, W: Write> {
    input: R,
    output: W,
    pub builder: ProgramTest,
}

impl<R: BufRead, W: Write> ChallengeBuilder<R, W> {
    fn read_line(&mut self) -> anyhow::Result<String> {
        let mut line = String::new();
        self.input.read_line(&mut line)?;

        Ok(line.replace("\n", ""))
    }

    /// Build challenge environment
    pub async fn build(self) -> Challenge<R, W> {
        Challenge {
            input: self.input,
            output: self.output,
            ctx: self.builder.start_with_context().await,
        }
    }

    /// Adds programs to challenge environment
    ///
    /// Returns vector of program pubkeys, with positions corresponding to input slice
    pub fn add_program(&mut self, path: &str, key: Option<Pubkey>) -> Pubkey {
        let program_so = std::fs::read(path).unwrap();
        let program_key = key.unwrap_or(helpers::keypair_from_data(&program_so).pubkey());

        // MEMORY LEAK
        let name: &'static str = Box::leak(path.replace(".so", "").into_boxed_str());

        self.builder
            .add_program(name, program_key, None);

        program_key
    }

    /// Reads program from input and adds it to environment
    pub fn input_program(&mut self, key: Pubkey) -> anyhow::Result<Pubkey> {
        // writeln!(self.output, "program pubkey: ")?;
        // let program_key = Pubkey::from_str(&self.read_line()?)?;

        writeln!(self.output, "program len: ")?;
        let len: usize = std::cmp::min(10_000_000, self.read_line()?.parse()?);

        let mut input_so = vec![0; len];
        self.input.read_exact(&mut input_so)?;

        let dir = Builder::new()
            .prefix("my-temporary-dir")
            .rand_bytes(5)
            .tempdir()?;

        let file_path = dir.path().join("solve.so");
        let mut input_file = File::create(file_path.clone())?;

        input_file.write_all(&input_so)?;

        self.add_program( &file_path.to_str().unwrap(), Some(key));

        Ok(key)
    }
}

impl<R: BufRead, W: Write> Challenge<R, W> {
    pub fn builder(input: R, output: W) -> ChallengeBuilder<R, W> {
        let mut builder = ProgramTest::default();
        builder.prefer_bpf(true);

        ChallengeBuilder {
            input,
            output,
            builder,
        }
    }

    pub async fn add_mint(&mut self, authority: &Pubkey, decimals: u8) -> anyhow::Result<Pubkey> {
        let mint_keypair = Keypair::new();
        let mint = mint_keypair.pubkey();
        let payer = &self.ctx.payer;
        let mut tx = Transaction::new_with_payer(
            &[
                solana_program::system_instruction::create_account(
                    &payer.pubkey(),
                    &mint,
                    10000000,
                    spl_token::state::Mint::LEN.try_into().unwrap(),
                    &spl_token::ID,
                ),
                spl_token::instruction::initialize_mint(
                    &spl_token::ID,
                    &mint,
                    authority,
                    None,
                    decimals,
                )?,
            ],
            Some(&payer.pubkey()),
        );
        tx.sign(&[&mint_keypair, payer], self.ctx.last_blockhash);
        self.ctx
            .banks_client
            .process_transaction_with_preflight(tx)
            .await?;

        Ok(mint)
    }


    pub async fn mint_to_instruction(
        &mut self,
        amount: u64,
        mint: &Pubkey,
        account: &Pubkey,
    ) -> anyhow::Result<Instruction> {
        Ok(spl_token::instruction::mint_to(
            &spl_token::ID,
            mint,
            account,
            &self.ctx.payer.pubkey(),
            &[],
            amount,
        )?)
    }

    pub async fn create_ata_instruction(
        &mut self,
        payer: &Pubkey,
        wallet: &Pubkey,
        mint: &Pubkey,
    ) -> anyhow::Result<Instruction> {
        Ok(spl_associated_token_account::instruction::create_associated_token_account_idempotent(
            payer,
            wallet,
            mint,
            &spl_token::ID,
        ))
    }

    pub async fn read_token_account(
        &mut self,
        pubkey: &Pubkey,
    ) -> anyhow::Result<spl_token::state::Account> {
        Ok(spl_token::state::Account::unpack(
            &self
                .ctx
                .banks_client
                .get_account(pubkey.clone())
                .await?
                .ok_or_else(|| anyhow::anyhow!("token account not exists"))?
                .data,
        )?)
    }

    pub async fn read_mint_account(
        &mut self,
        pubkey: &Pubkey,
    ) -> anyhow::Result<spl_token::state::Mint> {
        Ok(spl_token::state::Mint::unpack(
            &self
                .ctx
                .banks_client
                .get_account(pubkey.clone())
                .await?
                .ok_or_else(|| anyhow::anyhow!("mint account not exists"))?
                .data,
        )?)
    }

    pub fn get_global_address(&self) -> Pubkey {
        let (pubkey, _) = Pubkey::find_program_address(
            &[launchpad::states::GLOBAL_SEED],
            &launchpad::ID
        );
        pubkey
    }

    pub fn get_fee_vault(&self, fee_mint: &Pubkey) -> Pubkey {
        get_associated_token_address(
            &self.get_global_address(),
            fee_mint
        )
    }

    pub async fn read_global_account(
        &mut self,
    ) -> anyhow::Result<launchpad::states::Global> {
        Ok(launchpad::states::Global::try_deserialize(
            &mut &self
                .ctx
                .banks_client
                .get_account(self.get_global_address())
                .await?
                .unwrap()
                .data[..],
        )?)
    }

    pub fn get_emulate_clock_address(&self) -> Pubkey {
        let (pubkey, _) = Pubkey::find_program_address(
            &[launchpad::states::EMULATE_CLOCK_SEED],
            &launchpad::ID
        );
        pubkey
    }


    pub fn get_faucet_address(&self, mint: &Pubkey) -> Pubkey {
        let (pubkey, _) = Pubkey::find_program_address(
            &[launchpad::states::FAUCET_SEED, mint.as_ref()],
            &launchpad::ID
        );
        pubkey
    }

    pub fn get_faucet_vault(&self, mint: &Pubkey) -> Pubkey {
        get_associated_token_address(
            &self.get_global_address(),
            mint
        )
    }

    pub async fn initialize_global_instruction(
        &mut self,
        admin: &Pubkey,
        fee_mint: &Pubkey,
        args: InitializeGlobalArgs,
    ) -> anyhow::Result<Instruction> {

        let global = self.get_global_address();

        let token_program = self.ctx.banks_client.get_account(fee_mint.clone()).await?.unwrap().owner;

        let fee_vault = get_associated_token_address_with_program_id(
            &global,
            fee_mint,
            &token_program
        );
        
        Ok(Instruction::new_with_bytes(
            launchpad::ID,
            &launchpad::instruction::InitializeGlobal {
                args,
            }.data(),
            launchpad::accounts::InitializeGlobal {
                admin: admin.clone(),
                global,
                fee_mint: fee_mint.clone(),
                fee_vault,
                token_program,
                associated_token_program: spl_associated_token_account::ID,
                system_program: solana_program::system_program::ID,
            }.to_account_metas(None)
        ))
    }

    pub fn initialize_emulate_clock_instruction(
        &self,
        payer: &Pubkey
    ) -> Instruction {
        Instruction::new_with_bytes(
            launchpad::ID,
            &launchpad::instruction::InitializeEmulateClock{}.data(),
            launchpad::accounts::InitializeEmulateClock {
                payer: payer.clone(),
                emulate_clock: self.get_emulate_clock_address(),
                system_program: solana_program::system_program::ID,
            }.to_account_metas(None)
        )
    }

    pub async fn create_faucet_instruction(
        &mut self,
        authority: &Pubkey,
        faucet_mint: &Pubkey,
        refund_account: &Pubkey,
        args: CreateFaucetArgs,
    ) -> anyhow::Result<Instruction> {

        let global = self.get_global_address();
        let global_account = self.read_global_account().await?;
        let fee_mint = global_account.fee_mint;

        let fee_token_program = self.ctx.banks_client.get_account(fee_mint.clone()).await?.unwrap().owner;

        let fee_vault = get_associated_token_address_with_program_id(
            &global,
            &fee_mint,
            &fee_token_program
        );
        
        let faucet_token_program = self.ctx.banks_client.get_account(faucet_mint.clone()).await?.unwrap().owner;

        let faucet = self.get_faucet_address(faucet_mint);

        let faucet_vault = get_associated_token_address_with_program_id(
            &global,
            &faucet_mint,
            &faucet_token_program
        );

        let user_fee_ta = get_associated_token_address_with_program_id(
            authority,
            &fee_mint,
            &fee_token_program
        );

        Ok(Instruction::new_with_bytes(
            launchpad::ID,
            &launchpad::instruction::CreateFaucet {
                args,
            }.data(),
            launchpad::accounts::CreateFaucet {
                authority: authority.clone(),
                global,
                fee_mint,
                fee_vault,
                user_fee_ta,
                fee_token_program,
                faucet_mint: faucet_mint.clone(),
                faucet,
                faucet_vault,
                refund_account: refund_account.clone(),
                faucet_token_program,
                emulate_clock: self.get_emulate_clock_address(),
                associated_token_program: spl_associated_token_account::ID,
                system_program: solana_program::system_program::ID,
            }.to_account_metas(None)
        ))
    }


    pub async fn run_ixs(&mut self, ixs: &[Instruction]) -> anyhow::Result<()> {
        let payer_keypair = &self.ctx.payer;
        let payer = payer_keypair.pubkey();
        let mut tx = Transaction::new_with_payer(ixs, Some(&payer));

        tx.sign(&[payer_keypair], self.ctx.last_blockhash);
        self.ctx
            .banks_client
            .process_transaction_with_preflight(tx)
            .await?;

        Ok(())
    }

    pub async fn run_ix(&mut self, ix: Instruction) -> anyhow::Result<()> {
        self.run_ixs(&[ix]).await
    }

    pub async fn run_ixs_full<T: Signers>(
        &mut self,
        ixs: &[Instruction],
        signers: &T,
        payer: &Pubkey,
    ) -> anyhow::Result<()> {
        let mut tx = Transaction::new_with_payer(ixs, Some(payer));

        tx.sign(signers, self.ctx.last_blockhash);
        self.ctx
            .banks_client
            .process_transaction_with_preflight(tx)
            .await?;

        Ok(())
    }

    pub async fn read_instructions(&mut self) -> anyhow::Result<Vec<Instruction>> {
        let mut buf = [0; 8];
        self.input.read_exact(&mut buf)?;
        let len = u64::from_le_bytes(buf);
        let mut buf = vec![0; len as usize];
        self.input.read_exact(&mut buf)?;
        let instructions = serde_json::from_slice(&buf)?;
        Ok(instructions)
    }

}

impl TryFrom<TcpStream> for ChallengeBuilder<BufReader<TcpStream>, TcpStream> {
    type Error = std::io::Error;

    fn try_from(socket: TcpStream) -> Result<Self, Self::Error> {
        let reader = BufReader::new(socket.try_clone()?);
        Ok(Challenge::builder(reader, socket))
    }
}
