#!/bin/bash
pushd solve
anchor build
popd
cargo run
