#![allow(unexpected_cfgs)]

pub use anchor_lang;

use anchor_lang::prelude::*;

declare_id!("BXMft3v8jaZSdN9y5MsoJHAomREuQfHpjLAGdQfHA1Ph");


#[program]
pub mod solve {

    use super::*;

    pub fn solve(ctx: Context<Solve>) -> Result<()> {
        msg!("hello, {}", ctx.accounts.user.key);

        Ok(())
    }
}

#[derive(Accounts)]
pub struct Solve<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
}
