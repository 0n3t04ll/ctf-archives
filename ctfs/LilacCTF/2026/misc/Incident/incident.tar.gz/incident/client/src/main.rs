use std::fs;
use std::str::FromStr;
use std::{io::BufReader, net::TcpStream};
use std::io::{Read, Write};

pub mod utils;

use solana_program::pubkey;
use solana_sdk::compute_budget::ComputeBudgetInstruction;
use solana_sdk::instruction::Instruction;
use crate::pubkey::Pubkey;

pub use utils::*;

use solve::anchor_lang::{InstructionData, ToAccountMetas};

fn main() -> anyhow::Result<()> {
    let mut stream = TcpStream::connect("127.0.0.1:1337")?;
    let mut reader = BufReader::new(stream.try_clone()?);

    // solve proof of work
    println!("Solving proof of work...");
    let prefix = get_line(&mut reader)?;
    let pow = ProofOfWork::from(prefix);
    let nonce = pow.calculate();
    writeln!(stream, "nonce: {}", nonce)?;
    
    let so_data = fs::read("./solve/target/deploy/solve.so")?;
    let _ = get_line(&mut reader)?;
    writeln!(stream, "{}", so_data.len())?;
    stream.write_all(&so_data)?;

    let admin = Pubkey::from_str(&get_line(&mut reader)?)?;
    let user = Pubkey::from_str(&get_line(&mut reader)?)?;


    let marginfi_program = Pubkey::from_str(&get_line(&mut reader)?)?;
    let mint = Pubkey::from_str(&get_line(&mut reader)?)?;
    let group = Pubkey::from_str(&get_line(&mut reader)?)?;
    let mint_bank = Pubkey::from_str(&get_line(&mut reader)?)?;
    let sol_bank = Pubkey::from_str(&get_line(&mut reader)?)?;
    let admin_marginfi_account = Pubkey::from_str(&get_line(&mut reader)?)?;

    println!("admin: {}", admin);
    println!("user: {}", user);
    println!("marginfi_program: {}", marginfi_program);
    println!("mint: {}", mint);
    println!("group: {}", group);
    println!("mint_bank: {}", mint_bank);
    println!("sol_bank: {}", sol_bank);
    println!("admin_marginfi_account: {}", admin_marginfi_account);

    assert!(marginfi_cpi::ID == marginfi_program, "program id mismatch");

    let mut instructions: Vec<Instruction> = vec![];
    
    // --------------------------------
    // your solution here
    // Don't forget to push your instruction to `instructions`


    // Example: call solve
    instructions.push(Instruction::new_with_bytes(
        solve::ID,
        &solve::instruction::Solve {}.data(),
        solve::accounts::Solve {
            user,
        }.to_account_metas(None),
    ));

    // --------------------------------
    // you don't need to modify code blow
    
    let send_data = serde_json::to_vec(&instructions)?;
    let len = send_data.len() as u64;
    stream.write_all(&len.to_le_bytes())?;
    stream.write_all(&send_data)?;

    let mut response = Vec::<u8>::new();
    stream.read_to_end(&mut response)?;
    let response = String::from_utf8(response)?;
    println!("{}", response);
    Ok(())
}