use rand::distributions::Alphanumeric;
use rand::Rng;
use sha2::{Digest, Sha256};
use solana_program_test::{ProgramTest, ProgramTestContext};
use solana_sdk::signer::signers::Signers;
use solana_sdk::{signature::Signer, transaction::Transaction};
use std::fs::File;
use std::io::{BufRead, BufReader, Write};
use std::net::TcpStream;

use spl_associated_token_account::get_associated_token_address;

use solana_sdk::{
    instruction::Instruction,
    pubkey::Pubkey,
    signature::Keypair,
};

use spl_token::solana_program::program_pack::Pack;
use tempfile::Builder;

mod helpers {
    use rand::{prelude::StdRng, SeedableRng};
    use sha2::{Digest, Sha256};
    use solana_sdk::signature::Keypair;

    pub fn keypair_from_data(data: &[u8]) -> Keypair {
        let mut hash = Sha256::default();
        hash.update(&data);

        // panic here is probably fine since this should always be 32 bytes, regardless of user input
        let mut rng = StdRng::from_seed(hash.finalize()[..].try_into().unwrap());
        Keypair::generate(&mut rng)
    }
}

mod marginfi_helpers {
    use super::*;
    use anchor_lang::{InstructionData, ToAccountMetas};
    use marginfi_cpi::{BankConfigCompact, BankOperationalState, InterestRateConfigCompact, RiskTier, WrappedI80F48, accounts as marginfi_accounts, instruction as marginfi_ix};
    use marginfi_type_crate::constants::{
        FEE_STATE_SEED, FEE_VAULT_AUTHORITY_SEED, FEE_VAULT_SEED, INSURANCE_VAULT_AUTHORITY_SEED,
        INSURANCE_VAULT_SEED, LIQUIDITY_VAULT_AUTHORITY_SEED, LIQUIDITY_VAULT_SEED, ORACLE_MIN_AGE,
    };
    use solana_sdk::{instruction::Instruction, system_program};

    pub use marginfi_type_crate::constants::{ASSET_TAG_DEFAULT, ASSET_TAG_SOL};

    pub struct BankVaults {
        pub liquidity_vault_authority: Pubkey,
        pub liquidity_vault: Pubkey,
        pub insurance_vault_authority: Pubkey,
        pub insurance_vault: Pubkey,
        pub fee_vault_authority: Pubkey,
        pub fee_vault: Pubkey,
    }

    fn wrapped_i80f48_from_i128(value: i128) -> WrappedI80F48 {
        WrappedI80F48 {
            value: (value << 48).to_le_bytes(),
        }
    }

    fn wrapped_i80f48_from_ratio(numer: i128, denom: i128) -> WrappedI80F48 {
        let scaled = (numer << 48) / denom;
        WrappedI80F48 {
            value: scaled.to_le_bytes(),
        }
    }

    pub fn fixed_price(value: i128) -> WrappedI80F48 {
        wrapped_i80f48_from_i128(value)
    }

    pub fn fee_state_pda(program_id: &Pubkey) -> Pubkey {
        Pubkey::find_program_address(&[FEE_STATE_SEED.as_bytes()], program_id).0
    }

    pub fn bank_vaults(program_id: &Pubkey, bank: &Pubkey) -> BankVaults {
        let liquidity_vault_authority = Pubkey::find_program_address(
            &[LIQUIDITY_VAULT_AUTHORITY_SEED.as_bytes(), bank.as_ref()],
            program_id,
        )
        .0;
        let liquidity_vault = Pubkey::find_program_address(
            &[LIQUIDITY_VAULT_SEED.as_bytes(), bank.as_ref()],
            program_id,
        )
        .0;
        let insurance_vault_authority = Pubkey::find_program_address(
            &[INSURANCE_VAULT_AUTHORITY_SEED.as_bytes(), bank.as_ref()],
            program_id,
        )
        .0;
        let insurance_vault = Pubkey::find_program_address(
            &[INSURANCE_VAULT_SEED.as_bytes(), bank.as_ref()],
            program_id,
        )
        .0;
        let fee_vault_authority = Pubkey::find_program_address(
            &[FEE_VAULT_AUTHORITY_SEED.as_bytes(), bank.as_ref()],
            program_id,
        )
        .0;
        let fee_vault =
            Pubkey::find_program_address(&[FEE_VAULT_SEED.as_bytes(), bank.as_ref()], program_id).0;

        BankVaults {
            liquidity_vault_authority,
            liquidity_vault,
            insurance_vault_authority,
            insurance_vault,
            fee_vault_authority,
            fee_vault,
        }
    }

    pub fn bank_config_with_asset_tag(asset_tag: u8) -> BankConfigCompact {
        BankConfigCompact {
            asset_weight_init: wrapped_i80f48_from_ratio(75, 100),
            asset_weight_maint: wrapped_i80f48_from_ratio(80, 100),
            liability_weight_init: wrapped_i80f48_from_ratio(120, 100),
            liability_weight_maint: wrapped_i80f48_from_ratio(110, 100),
            deposit_limit: u64::MAX,
            interest_rate_config: InterestRateConfigCompact::default(),
            operational_state: BankOperationalState::Operational,
            borrow_limit: u64::MAX,
            risk_tier: RiskTier::Collateral,
            asset_tag,
            config_flags: 0,
            pad0: [0; 5],
            total_asset_value_init_limit: 0,
            oracle_max_age: ORACLE_MIN_AGE,
            oracle_max_confidence: u32::MAX,
        }
    }

    pub fn init_fee_state_ix(
        program_id: Pubkey,
        payer: Pubkey,
        fee_state: Pubkey,
        admin: Pubkey,
        fee_wallet: Pubkey,
    ) -> Instruction {
        let accounts = marginfi_accounts::InitGlobalFeeState {
            payer,
            fee_state,
            system_program: system_program::id(),
        };
        let data = marginfi_ix::InitGlobalFeeState {
            _admin: admin,
            _fee_wallet: fee_wallet,
            _bank_init_flat_sol_fee: 0,
            _liquidation_flat_sol_fee: 0,
            _program_fee_fixed: marginfi_cpi::WrappedI80F48::default(),
            _program_fee_rate: marginfi_cpi::WrappedI80F48::default(),
            _liquidation_max_fee: marginfi_cpi::WrappedI80F48::default(),
        }
        .data();

        Instruction {
            program_id,
            accounts: accounts.to_account_metas(Some(true)),
            data,
        }
    }

    pub fn marginfi_group_initialize_ix(
        program_id: Pubkey,
        marginfi_group: Pubkey,
        admin: Pubkey,
        fee_state: Pubkey,
    ) -> Instruction {
        let accounts = marginfi_accounts::MarginfiGroupInitialize {
            marginfi_group,
            admin,
            fee_state,
            system_program: system_program::id(),
        };
        let data = marginfi_ix::MarginfiGroupInitialize {
            _is_arena_group: false,
        }
        .data();

        Instruction {
            program_id,
            accounts: accounts.to_account_metas(Some(true)),
            data,
        }
    }

    pub fn lending_pool_add_bank_ix(
        program_id: Pubkey,
        marginfi_group: Pubkey,
        admin: Pubkey,
        fee_payer: Pubkey,
        fee_state: Pubkey,
        global_fee_wallet: Pubkey,
        bank_mint: Pubkey,
        bank: Pubkey,
        liquidity_vault_authority: Pubkey,
        liquidity_vault: Pubkey,
        insurance_vault_authority: Pubkey,
        insurance_vault: Pubkey,
        fee_vault_authority: Pubkey,
        fee_vault: Pubkey,
        token_program: Pubkey,
        bank_config: BankConfigCompact,
    ) -> Instruction {
        let accounts = marginfi_accounts::LendingPoolAddBank {
            marginfi_group,
            admin,
            fee_payer,
            fee_state,
            global_fee_wallet,
            bank_mint,
            bank,
            liquidity_vault_authority,
            liquidity_vault,
            insurance_vault_authority,
            insurance_vault,
            fee_vault_authority,
            fee_vault,
            token_program,
            system_program: system_program::id(),
        };
        let data = marginfi_ix::LendingPoolAddBank { 
            _bank_config: bank_config
        }.data();

        Instruction {
            program_id,
            accounts: accounts.to_account_metas(Some(true)),
            data,
        }
    }

    pub fn lending_pool_set_fixed_oracle_price_ix(
        program_id: Pubkey,
        group: Pubkey,
        admin: Pubkey,
        bank: Pubkey,
        price: WrappedI80F48,
    ) -> Instruction {
        let accounts = marginfi_accounts::LendingPoolSetFixedOraclePrice { group, admin, bank };
        let data = marginfi_ix::LendingPoolSetFixedOraclePrice { 
            _price: price
        }.data();

        Instruction {
            program_id,
            accounts: accounts.to_account_metas(Some(true)),
            data,
        }
    }

    pub fn marginfi_account_initialize_ix(
        program_id: Pubkey,
        marginfi_group: Pubkey,
        marginfi_account: Pubkey,
        authority: Pubkey,
        fee_payer: Pubkey,
    ) -> Instruction {
        let accounts = marginfi_accounts::MarginfiAccountInitialize {
            marginfi_group,
            marginfi_account,
            authority,
            fee_payer,
            system_program: system_program::id(),
        };
        let data = marginfi_ix::MarginfiAccountInitialize {}.data();

        Instruction {
            program_id,
            accounts: accounts.to_account_metas(Some(true)),
            data,
        }
    }

    pub fn lending_account_deposit_ix(
        program_id: Pubkey,
        group: Pubkey,
        marginfi_account: Pubkey,
        authority: Pubkey,
        bank: Pubkey,
        signer_token_account: Pubkey,
        liquidity_vault: Pubkey,
        token_program: Pubkey,
        amount: u64,
    ) -> Instruction {
        let accounts = marginfi_accounts::LendingAccountDeposit {
            group,
            marginfi_account,
            authority,
            bank,
            signer_token_account,
            liquidity_vault,
            token_program,
        };
        let data = marginfi_ix::LendingAccountDeposit {
            _amount: amount,
            _deposit_up_to_limit: None,
        }
        .data();

        Instruction {
            program_id,
            accounts: accounts.to_account_metas(Some(true)),
            data,
        }
    }
}

pub struct MarginfiSetup {
    pub group: Pubkey,
    pub bank: Pubkey,
    pub bank_liquidity_vault: Pubkey,
    pub sol_bank: Pubkey,
    pub sol_bank_liquidity_vault: Pubkey,
    pub marginfi_account: Pubkey,
    pub mint: Pubkey,
    pub deposit_source_token_account: Pubkey,
}

pub struct ProofOfWork {
    pub prefix: String,
}

impl ProofOfWork {
    const DIFFICULTY: usize = 5;

    pub fn new() -> Self {
        let prefix: String = rand::thread_rng()
            .sample_iter(&Alphanumeric)
            .take(10)
            .map(char::from)
            .collect();
        Self { prefix }
    }

    pub fn verify(&self, nonce: u128) -> bool {
        let mut hasher = Sha256::new();
        hasher.update(format!("{}{}", self.prefix, nonce));
        let result = hasher.finalize();
        let hex_result = format!("{:x}", result);

        hex_result.starts_with(&"0".repeat(Self::DIFFICULTY))
    }
}

pub struct Challenge<R: BufRead, W: Write> {
    input: R,
    output: W,
    pub ctx: ProgramTestContext,
}

pub struct ChallengeBuilder<R: BufRead, W: Write> {
    input: R,
    output: W,
    pub builder: ProgramTest,
}

impl<R: BufRead, W: Write> ChallengeBuilder<R, W> {
    fn read_line(&mut self) -> anyhow::Result<String> {
        let mut line = String::new();
        self.input.read_line(&mut line)?;

        Ok(line.replace("\n", ""))
    }

    /// Build challenge environment
    pub async fn build(self) -> Challenge<R, W> {
        Challenge {
            input: self.input,
            output: self.output,
            ctx: self.builder.start_with_context().await,
        }
    }

    /// Adds programs to challenge environment
    ///
    /// Returns vector of program pubkeys, with positions corresponding to input slice
    pub fn add_program(&mut self, path: &str, key: Option<Pubkey>) -> Pubkey {
        let program_so = std::fs::read(path).unwrap();
        let program_key = key.unwrap_or(helpers::keypair_from_data(&program_so).pubkey());

        // MEMORY LEAK
        let name: &'static str = Box::leak(path.replace(".so", "").into_boxed_str());

        self.builder
            .add_program(name, program_key, None);

        program_key
    }

    /// Reads program from input and adds it to environment
    pub fn input_program(&mut self, key: Pubkey) -> anyhow::Result<Pubkey> {
        // writeln!(self.output, "program pubkey: ")?;
        // let program_key = Pubkey::from_str(&self.read_line()?)?;

        writeln!(self.output, "program len: ")?;
        let len: usize = std::cmp::min(10_000_000, self.read_line()?.parse()?);

        let mut input_so = vec![0; len];
        self.input.read_exact(&mut input_so)?;

        let dir = Builder::new()
            .prefix("my-temporary-dir")
            .rand_bytes(5)
            .tempdir()?;

        let file_path = dir.path().join("solve.so");
        let mut input_file = File::create(file_path.clone())?;

        input_file.write_all(&input_so)?;

        self.add_program( &file_path.to_str().unwrap(), Some(key));

        Ok(key)
    }
}

impl<R: BufRead, W: Write> Challenge<R, W> {
    pub fn builder(input: R, output: W) -> ChallengeBuilder<R, W> {
        let mut builder = ProgramTest::default();
        builder.prefer_bpf(true);

        ChallengeBuilder {
            input,
            output,
            builder,
        }
    }

    pub async fn add_mint(&mut self, authority: &Pubkey, decimals: u8) -> anyhow::Result<Pubkey> {
        let mint_keypair = Keypair::new();
        let mint = mint_keypair.pubkey();
        let payer = &self.ctx.payer;
        let mut tx = Transaction::new_with_payer(
            &[
                solana_program::system_instruction::create_account(
                    &payer.pubkey(),
                    &mint,
                    10000000,
                    spl_token::state::Mint::LEN.try_into().unwrap(),
                    &spl_token::ID,
                ),
                spl_token::instruction::initialize_mint(
                    &spl_token::ID,
                    &mint,
                    authority,
                    None,
                    decimals,
                )?,
            ],
            Some(&payer.pubkey()),
        );
        tx.sign(&[&mint_keypair, payer], self.ctx.last_blockhash);
        self.ctx
            .banks_client
            .process_transaction_with_preflight(tx)
            .await?;

        Ok(mint)
    }


    pub async fn mint_to_instruction(
        &mut self,
        amount: u64,
        mint: &Pubkey,
        account: &Pubkey,
    ) -> anyhow::Result<Instruction> {
        Ok(spl_token::instruction::mint_to(
            &spl_token::ID,
            mint,
            account,
            &self.ctx.payer.pubkey(),
            &[],
            amount,
        )?)
    }

    pub async fn create_ata_instruction(
        &mut self,
        payer: &Pubkey,
        wallet: &Pubkey,
        mint: &Pubkey,
    ) -> anyhow::Result<Instruction> {
        Ok(spl_associated_token_account::instruction::create_associated_token_account_idempotent(
            payer,
            wallet,
            mint,
            &spl_token::ID,
        ))
    }

    pub async fn setup_marginfi_deposit(
        &mut self,
        program_id: Pubkey,
        admin: &Keypair,
    ) -> anyhow::Result<MarginfiSetup> {
        let fee_state = marginfi_helpers::fee_state_pda(&program_id);
        let marginfi_group = Keypair::new();
        let bank = Keypair::new();
        let marginfi_account = Keypair::new();

        let mint = self.add_mint(&admin.pubkey(), 6).await?;
        let deposit_source_token_account = get_associated_token_address(&admin.pubkey(), &mint);
        let deposit_amount = 1_000_000u64;
        let create_ata_ix = self
            .create_ata_instruction(&admin.pubkey(), &admin.pubkey(), &mint)
            .await?;
        let mint_to_ix = self
            .mint_to_instruction(deposit_amount, &mint, &deposit_source_token_account)
            .await?;
        self.run_ixs(&[create_ata_ix, mint_to_ix]).await?;

        let init_fee_state_ix = marginfi_helpers::init_fee_state_ix(
            program_id,
            admin.pubkey(),
            fee_state,
            admin.pubkey(),
            admin.pubkey(),
        );
        let init_group_ix = marginfi_helpers::marginfi_group_initialize_ix(
            program_id,
            marginfi_group.pubkey(),
            admin.pubkey(),
            fee_state,
        );
        self.run_ixs_full(
            &[init_fee_state_ix, init_group_ix],
            &[admin, &marginfi_group],
            &admin.pubkey(),
        )
        .await?;

        let vaults = marginfi_helpers::bank_vaults(&program_id, &bank.pubkey());
        let add_bank_ix = marginfi_helpers::lending_pool_add_bank_ix(
            program_id,
            marginfi_group.pubkey(),
            admin.pubkey(),
            admin.pubkey(),
            fee_state,
            admin.pubkey(),
            mint,
            bank.pubkey(),
            vaults.liquidity_vault_authority,
            vaults.liquidity_vault,
            vaults.insurance_vault_authority,
            vaults.insurance_vault,
            vaults.fee_vault_authority,
            vaults.fee_vault,
            spl_token::ID,
            marginfi_helpers::bank_config_with_asset_tag(marginfi_helpers::ASSET_TAG_DEFAULT),
        );
        self.run_ixs_full(&[add_bank_ix], &[admin, &bank], &admin.pubkey())
            .await?;

        let set_oracle_ix = marginfi_helpers::lending_pool_set_fixed_oracle_price_ix(
            program_id,
            marginfi_group.pubkey(),
            admin.pubkey(),
            bank.pubkey(),
            marginfi_helpers::fixed_price(1),
        );
        self.run_ixs_full(&[set_oracle_ix], &[admin], &admin.pubkey())
            .await?;

        let sol_mint = self.add_mint(&admin.pubkey(), 9).await?;
        let sol_bank = Keypair::new();
        let sol_vaults = marginfi_helpers::bank_vaults(&program_id, &sol_bank.pubkey());
        let add_sol_bank_ix = marginfi_helpers::lending_pool_add_bank_ix(
            program_id,
            marginfi_group.pubkey(),
            admin.pubkey(),
            admin.pubkey(),
            fee_state,
            admin.pubkey(),
            sol_mint,
            sol_bank.pubkey(),
            sol_vaults.liquidity_vault_authority,
            sol_vaults.liquidity_vault,
            sol_vaults.insurance_vault_authority,
            sol_vaults.insurance_vault,
            sol_vaults.fee_vault_authority,
            sol_vaults.fee_vault,
            spl_token::ID,
            marginfi_helpers::bank_config_with_asset_tag(marginfi_helpers::ASSET_TAG_SOL),
        );
        self.run_ixs_full(&[add_sol_bank_ix], &[admin, &sol_bank], &admin.pubkey())
            .await?;

        let set_sol_oracle_ix = marginfi_helpers::lending_pool_set_fixed_oracle_price_ix(
            program_id,
            marginfi_group.pubkey(),
            admin.pubkey(),
            sol_bank.pubkey(),
            marginfi_helpers::fixed_price(1),
        );
        self.run_ixs_full(&[set_sol_oracle_ix], &[admin], &admin.pubkey())
            .await?;

        let init_account_ix = marginfi_helpers::marginfi_account_initialize_ix(
            program_id,
            marginfi_group.pubkey(),
            marginfi_account.pubkey(),
            admin.pubkey(),
            admin.pubkey(),
        );
        self.run_ixs_full(
            &[init_account_ix],
            &[admin, &marginfi_account],
            &admin.pubkey(),
        )
        .await?;

        let deposit_ix = marginfi_helpers::lending_account_deposit_ix(
            program_id,
            marginfi_group.pubkey(),
            marginfi_account.pubkey(),
            admin.pubkey(),
            bank.pubkey(),
            deposit_source_token_account,
            vaults.liquidity_vault,
            spl_token::ID,
            deposit_amount,
        );
        self.run_ixs_full(&[deposit_ix], &[admin], &admin.pubkey())
            .await?;

        Ok(MarginfiSetup {
            group: marginfi_group.pubkey(),
            bank: bank.pubkey(),
            bank_liquidity_vault: vaults.liquidity_vault,
            sol_bank: sol_bank.pubkey(),
            sol_bank_liquidity_vault: sol_vaults.liquidity_vault,
            marginfi_account: marginfi_account.pubkey(),
            mint,
            deposit_source_token_account,
        })
    }

    pub async fn read_token_account(
        &mut self,
        pubkey: &Pubkey,
    ) -> anyhow::Result<spl_token::state::Account> {
        Ok(spl_token::state::Account::unpack(
            &self
                .ctx
                .banks_client
                .get_account(pubkey.clone())
                .await?
                .ok_or_else(|| anyhow::anyhow!("token account not exists"))?
                .data,
        )?)
    }

    pub async fn read_mint_account(
        &mut self,
        pubkey: &Pubkey,
    ) -> anyhow::Result<spl_token::state::Mint> {
        Ok(spl_token::state::Mint::unpack(
            &self
                .ctx
                .banks_client
                .get_account(pubkey.clone())
                .await?
                .ok_or_else(|| anyhow::anyhow!("mint account not exists"))?
                .data,
        )?)
    }

    pub async fn run_ixs(&mut self, ixs: &[Instruction]) -> anyhow::Result<()> {
        let payer_keypair = &self.ctx.payer;
        let payer = payer_keypair.pubkey();
        let mut tx = Transaction::new_with_payer(ixs, Some(&payer));

        tx.sign(&[payer_keypair], self.ctx.last_blockhash);
        self.ctx
            .banks_client
            .process_transaction_with_preflight(tx)
            .await?;

        Ok(())
    }

    pub async fn run_ix(&mut self, ix: Instruction) -> anyhow::Result<()> {
        self.run_ixs(&[ix]).await
    }

    pub async fn run_ixs_full<T: Signers>(
        &mut self,
        ixs: &[Instruction],
        signers: &T,
        payer: &Pubkey,
    ) -> anyhow::Result<()> {
        let mut tx = Transaction::new_with_payer(ixs, Some(payer));

        tx.sign(signers, self.ctx.last_blockhash);
        self.ctx
            .banks_client
            .process_transaction_with_preflight(tx)
            .await?;

        Ok(())
    }

    pub async fn read_instructions(&mut self) -> anyhow::Result<Vec<Instruction>> {
        let mut buf = [0; 8];
        self.input.read_exact(&mut buf)?;
        let len = u64::from_le_bytes(buf);
        let mut buf = vec![0; len as usize];
        self.input.read_exact(&mut buf)?;
        let instructions = serde_json::from_slice(&buf)?;
        Ok(instructions)
    }

}

impl TryFrom<TcpStream> for ChallengeBuilder<BufReader<TcpStream>, TcpStream> {
    type Error = std::io::Error;

    fn try_from(socket: TcpStream) -> Result<Self, Self::Error> {
        let reader = BufReader::new(socket.try_clone()?);
        Ok(Challenge::builder(reader, socket))
    }
}
