#!/bin/bash
cargo run -r
