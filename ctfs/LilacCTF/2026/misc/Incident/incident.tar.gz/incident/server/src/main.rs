use challenge::ChallengeBuilder;
use challenge::ProofOfWork;
use solana_program_test::tokio;

use solana_sdk::{signature::Keypair, signer::Signer, pubkey::Pubkey, system_instruction};
use std::env;
use std::io::Write;
use std::{
    io::BufReader,
    net::{TcpListener, TcpStream},
};
use utils::get_line;

pub mod challenge;
pub mod utils;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let listener = TcpListener::bind("0.0.0.0:1337")?;
    println!("starting server at port 1337!");
    for stream in listener.incoming() {
        if stream.is_err() {
            println!("error: {:?}", stream.err());
            continue;
        }
        let mut stream = stream.unwrap();

        tokio::spawn(async move {
            if let Err(err) = handle_connection(&mut stream).await {
                let _ = writeln!(stream, "error: {:?}", err);
                println!("error: {:?}", err);
            }
        });
    }
    Ok(())
}

async fn handle_pow(socket: &mut TcpStream) -> anyhow::Result<()> {
    let pow = ProofOfWork::new();
    let prefix = pow.prefix.clone();
    writeln!(socket, "prefix: {}", prefix)?;
    let mut reader = BufReader::new(socket.try_clone()?);
    let nonce = get_line(&mut reader)?;
    let nonce = nonce.parse::<u128>()?;
    if !pow.verify(nonce) {
        writeln!(socket, "invalid nonce")?;
        return Err(anyhow::anyhow!("invalid nonce"));
    };
    Ok(())
}


const SOLVE_ID: Pubkey = Pubkey::from_str_const("BXMft3v8jaZSdN9y5MsoJHAomREuQfHpjLAGdQfHA1Ph");

async fn handle_connection(socket: &mut TcpStream) -> anyhow::Result<()> {

    // Proof of Work
    handle_pow(socket).await?;

    // Prepare marginfi environment.
    let mut builder = ChallengeBuilder::try_from(socket.try_clone().unwrap()).unwrap();

    assert!(builder.input_program(SOLVE_ID)? == SOLVE_ID);

    let marginfi_program_id = builder.add_program("./marginfi.so", Some(marginfi_cpi::ID));

    let mut chall = builder.build().await;

    // create user account
    let user_keypair = Keypair::new();
    let user = user_keypair.pubkey();

    // Copy the payer keypair out of `chall` so we don't keep an immutable borrow
    // of `chall` alive across the awaited calls below.
    let admin_keypair = Keypair::from_bytes(&chall.ctx.payer.to_bytes())?;
    let admin = admin_keypair.pubkey();

    // 3. airdrop for gas fee
    chall
        .run_ix(system_instruction::transfer(&admin, &user, 10_000_000_000)) // 10 sol
        .await?;

    writeln!(socket, "admin: {}", admin)?;
    writeln!(socket, "user: {}", user)?;

    let setup = chall
        .setup_marginfi_deposit(marginfi_program_id, &admin_keypair)
        .await?;

    writeln!(socket, "marginfi_program: {}", marginfi_program_id)?;
    writeln!(socket, "mint: {}", setup.mint)?;
    writeln!(socket, "group: {}", setup.group)?;
    writeln!(socket, "mint_bank: {}", setup.bank)?;
    writeln!(socket, "sol_bank: {}", setup.sol_bank)?;
    writeln!(socket, "marginfi_account: {}", setup.marginfi_account)?;


    let solve_ixs = chall.read_instructions().await?;

    chall
        .run_ixs_full(&solve_ixs, &[&user_keypair], &user)
        .await?;


    let bank_balance = chall
        .read_token_account(&setup.bank_liquidity_vault)
        .await?
        .amount;
    let sol_bank_balance = chall
        .read_token_account(&setup.sol_bank_liquidity_vault)
        .await?
        .amount;

    if bank_balance != 0 || sol_bank_balance != 0 {
        writeln!(
            socket,
            "bank balances not cleared: {} / {}",
            bank_balance, sol_bank_balance
        )?;
        return Ok(());
    }

    writeln!(socket, "congrats! you won the flag!")?;
    if let Ok(flag) = env::var("FLAG") {
        writeln!(socket, "flag: {}", flag)?;
    } else {
        writeln!(socket, "flag not found, please contact admin")?;
    }
    Ok(())
}
