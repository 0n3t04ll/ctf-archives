pub mod gcp_pubsub {
    tonic::include_proto!("gcp_pubsub");
}
