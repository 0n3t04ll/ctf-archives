anchor_gen::generate_cpi_crate!("marginfi.json");
