#include "seal/seal.h"
#include "seal/util/ntt.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include <cassert>
using namespace std;
using namespace seal;
using namespace seal::util;

uint64_t inverse(uint64_t a, uint64_t m) {
    int64_t t = 0, newt = 1;
    int64_t r = m, newr = a;
    while (newr != 0) {
        int64_t quotient = r / newr;
        t = t - quotient * newt; swap(t, newt);
        r = r - quotient * newr; swap(r, newr);
    }
    if (t < 0) t += m;
    return (uint64_t)t;
}



string flag = "LilacCTF{XXXXXXXXXXXXXXX}";
int main() {
    EncryptionParameters parms(scheme_type::ckks);
    size_t n = 4096;
    parms.set_poly_modulus_degree(n);
    auto coeff_modulus = CoeffModulus::Create(n, { 30, 30, 30 });
    parms.set_coeff_modulus(coeff_modulus);
    SEALContext context(parms);
    
    
    KeyGenerator keygen(context);
    SecretKey secret_key = keygen.secret_key(); 
    
    PublicKey public_key;
    keygen.create_public_key(public_key);


    Encryptor encryptor(context, public_key);
    Decryptor decryptor(context, secret_key);
    CKKSEncoder encoder(context);
    Evaluator evaluator(context);

    vector<double> input; 
    
    for(int i = 0; i < flag.size(); i++){
        input.push_back(1.0*flag.at(i)/256);
    }
    
    for(int i = flag.size(); i < 50; i++){
        input.push_back(0.5);
    }
    double scale = pow(2.0, 20); 
    Plaintext pt_init, pt_mask;
    encoder.encode(input, scale, pt_init);
    encoder.encode(0, scale, pt_mask);
    
    Ciphertext ct, ct_mask;
    encryptor.encrypt(pt_init, ct);
    encryptor.encrypt(pt_mask, ct_mask);
    
    evaluator.add_inplace(ct,ct_mask);
    ofstream fs_ct("ciphertext.dat", ios::binary);
    ct.save(fs_ct);
    fs_ct.close();

    ofstream fs_ct_mask("ciphertext_mask.dat", ios::binary);
    ct_mask.save(fs_ct_mask);
    fs_ct_mask.close();


    
    while (context.get_context_data(ct.parms_id())->next_context_data()) {
        evaluator.mod_switch_to_next_inplace(ct);
    }

    auto context_low = context.get_context_data(ct.parms_id());
    auto context_high = context.get_context_data(context.first_parms_id());
    auto &mod_high = context_high->parms().coeff_modulus();
    int q_low = context_low->parms().coeff_modulus().back().value();

    Ciphertext ct_high;
    ct_high.resize(context, context.first_parms_id(), ct.size());
    evaluator.transform_from_ntt_inplace(ct); 

    for (size_t poly_idx = 0; poly_idx < ct.size(); poly_idx++) {
        for (size_t i = 0; i < n; i++) {
            uint64_t raw_val = *(ct.data(poly_idx) + i); 
            for (size_t rns_idx = 0; rns_idx < mod_high.size(); rns_idx++) {
                uint64_t qi = mod_high[rns_idx].value();
                *(ct_high.data(poly_idx) + (rns_idx * n) + i) = raw_val % qi;
            }
        }
    }
    ct_high.is_ntt_form() = false;
    ct_high.scale() = ct.scale();

    evaluator.transform_to_ntt_inplace(ct_high);
    Plaintext pt_kq;
    decryptor.decrypt(ct_high, pt_kq);

    for (size_t rns_idx = 0; rns_idx < mod_high.size(); rns_idx++) {
        inverse_ntt_negacyclic_harvey(pt_kq.data() + (rns_idx * n), context_high->small_ntt_tables()[rns_idx]);
    }

    uint64_t Q = 1;
    for(auto &m : mod_high) Q *= m.value();

    for (size_t i = 0; i < n; i++) {
        uint64_t X = 0;
        for (size_t j = 0; j < mod_high.size(); j++) {
            int qj = mod_high[j].value();
            int vj = pt_kq.data()[j * n + i];
            int Mj = Q / qj;
            int invMj = inverse((Mj % qj), qj);
            X = (X + (unsigned __int128)vj * Mj * invMj) % Q;
        }
        int signed_X = (X > Q / 2) ? (int)X - Q : X;
        int clean_m = (signed_X % q_low);
        if (clean_m > q_low / 2) clean_m -= q_low;
        if (clean_m < -q_low / 2) clean_m += q_low;

        for (size_t j = 0; j < mod_high.size(); j++) {
            int qj = mod_high[j].value();
            int limb = clean_m % qj;
            if (limb < 0) limb += qj;
            pt_kq.data()[j * n + i] = limb;
        }
    }

    for (size_t rns_idx = 0; rns_idx < mod_high.size(); rns_idx++) {
        ntt_negacyclic_harvey(pt_kq.data() + (rns_idx * n), context_high->small_ntt_tables()[rns_idx]);
    }
    pt_kq.parms_id() = context_high->parms_id();

    vector<double> result;
    encoder.decode(pt_kq, result);

    for(int i = flag.size(); i < 50; i++){
        cout << result[i] - input[i] << endl;
    }
    return 0;
}


/*

-1.63573e-05
-6.73093e-07
-2.00591e-06
-2.59483e-05
-1.44904e-05
-3.5275e-05
-2.47104e-05

*/