import random
import hashlib
from secret import input_str

TOTAL_BITS = 50000
huge_int = random.getrandbits(TOTAL_BITS)
def is_chinese(char):
    return '\u4e00' <= char <= '\u9fa5'

def add_unicode_noise(text, step=100, noise_bits=2): 
    noisy_text = ""
    bit_stream_segments = []
    temp_val = huge_int
    num_chunks = (TOTAL_BITS + 31) // 32
    for _ in range(num_chunks):
        chunk_val = temp_val & 0xFFFFFFFF
        bit_stream_segments.append(format(chunk_val, '032b'))
        temp_val >>= 32
    full_bit_stream = "".join(bit_stream_segments)  
    stream_ptr = 0
    for char in text:
        if is_chinese(char):
            if stream_ptr + noise_bits > len(full_bit_stream):
                noisy_text += char
                continue
            chunk = full_bit_stream[stream_ptr : stream_ptr + noise_bits]
            noise_val = int(chunk, 2)
            stream_ptr += noise_bits
            original_code = ord(char)
            noisy_text += chr(original_code + (noise_val * step))
        else:
            noisy_text += char
    return noisy_text

step_val = 9997
NOISE_BITS = 1 

output_str = add_unicode_noise(input_str, step=step_val, noise_bits=NOISE_BITS)

with open("ciphertext.txt", "w", encoding="utf-8") as f:
    f.write(output_str)

flag_hash = hashlib.sha256(input_str.encode('utf-8')).hexdigest()
print(f"LilacCTF{{{flag_hash}}}")


#

# LilacCTF{df0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx}