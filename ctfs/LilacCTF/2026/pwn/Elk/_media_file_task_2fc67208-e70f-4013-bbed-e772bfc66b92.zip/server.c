#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/mman.h>
#include "./elk.h"

#define JS_BUFLEN 0x1000

#define EXIT_ERROR -126
#define MEMORY_ERROR -127
#define EVAL_ERROR -128

enum {
  // IMPORTANT: T_OBJ, T_PROP, T_STR must go first.  That is required by the
  // memory layout functions: memory entity types are encoded in the 2 bits,
  // thus type values must be 0,1,2,3
  T_OBJ, T_PROP, T_STR, T_UNDEF, T_NULL, T_NUM, T_BOOL, T_FUNC, T_CODEREF,
  T_CFUNC, T_ERR
};

static jsval_t js_print(struct js *js, jsval_t *args, int nargs) {
  for (int i = 0; i < nargs; i++) {
    printf("%s%s", i == 0 ? "" : " ", js_str(js, args[i]));
  }
  putchar('\n');
  return js_mkundef();
}

static jsval_t js_exit(struct js *js, jsval_t *args, int nargs) {
    if(nargs != 1){
        return EXIT_ERROR;
    }
    if(js_type(args[0]) == T_NUM)
        exit(js_getnum(args[0]));
    else if(js_type(args[0]) == T_STR){
        printf("[Exit] %s", js_getstr(js, args[0], NULL));
        exit(0);
    }
    return 0;
}

void init() {
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stderr, 0, 2, 0);
}

int main(int argc, char *argv[]) {

    init();

    char *js_buf = mmap(NULL, JS_BUFLEN, PROT_WRITE | PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (!js_buf) return MEMORY_ERROR;

    // init
    struct js *js = js_create(js_buf, JS_BUFLEN);
    if (!js) return MEMORY_ERROR;

    // register
    js_set(js, js_glob(js), "print", js_mkfun(js_print));
    js_set(js, js_glob(js), "exit", js_mkfun(js_exit));

    // loop
    char buffer[0x1010];
    while(true) {
        printf("> \n");
        size_t nbytes = 0;
        while(nbytes < 0x1000){
            size_t ibytes = read(0, buffer+nbytes, 3);
            if(ibytes != 3)
                break;
            if(!memcmp(buffer+nbytes, "EOF", 3)){
                nbytes -= 3;
                break;
            }
            nbytes += ibytes;
        }
        // size_t nbytes = read(0, buffer, 0x1000);
        buffer[nbytes] = 0;
        jsval_t res = js_eval(js, buffer, nbytes);
        if(res < 0){
            jsval_t retcode = js_mknum((double)EVAL_ERROR);
            js_exit(js, &retcode, 1);
        }
        else{
            printf("%s\n", js_str(js, res));
        }
    }
    
    free(js_buf);

    return 0;
}
