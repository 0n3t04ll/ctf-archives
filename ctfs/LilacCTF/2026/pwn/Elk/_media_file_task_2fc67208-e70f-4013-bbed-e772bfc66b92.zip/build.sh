#!/bin/sh
gcc ./server.c ./elk.c -o ./pwn