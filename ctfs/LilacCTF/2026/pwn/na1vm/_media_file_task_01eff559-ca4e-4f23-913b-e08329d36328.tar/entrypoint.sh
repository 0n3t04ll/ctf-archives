#!/bin/sh
set -e

if [ -n "$FLAG1" ]; then
  echo "$FLAG1" > /flag
else
  echo "LilacCTF{testflag}" > /flag
fi

if id -u ctf >/dev/null 2>&1; then
  chown ctf:ctf /flag >/dev/null 2>&1 || true
fi

/etc/init.d/xinetd start
trap : TERM INT
sleep infinity & wait
