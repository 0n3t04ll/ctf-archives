package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

const maxLineLen = 1024

type config struct {
	addr          string
	challDir      string
	logDir        string
	maxUpload     int64
	powSuffixLen  int
	powTimeout    time.Duration
	uploadTimeout time.Duration
	execTimeout   time.Duration
	runUID        int
	runGID        int
}

func main() {
	cfg := parseFlags()
	if os.Geteuid() != 0 {
		log.Fatal("must run as root or with CAP_SYS_CHROOT")
	}

	ln, err := net.Listen("tcp", cfg.addr)
	if err != nil {
		log.Fatalf("listen %s: %v", cfg.addr, err)
	}
	log.Printf("listening on %s", cfg.addr)

	for {
		conn, err := ln.Accept()
		if err != nil {
			log.Printf("accept: %v", err)
			continue
		}
		go handleConn(conn, cfg)
	}
}

func parseFlags() config {
	var cfg config
	flag.StringVar(&cfg.addr, "addr", ":9990", "listen address")
	flag.StringVar(&cfg.challDir, "chall", "./chall", "chall directory path (contains sqlite3)")
	flag.StringVar(&cfg.logDir, "log-dir", "/log", "log directory path")
	flag.Int64Var(&cfg.maxUpload, "max-upload", 16<<20, "max upload size")
	flag.IntVar(&cfg.powSuffixLen, "pow-suffix-len", 6, "pow hex suffix length")
	flag.DurationVar(&cfg.powTimeout, "pow-timeout", 2*time.Minute, "pow timeout")
	flag.DurationVar(&cfg.uploadTimeout, "upload-timeout", 2*time.Minute, "upload timeout")
	flag.DurationVar(&cfg.execTimeout, "exec-timeout", 120*time.Second, "sqlite timeout")
	flag.IntVar(&cfg.runUID, "run-uid", 65534, "uid for sqlite process")
	flag.IntVar(&cfg.runGID, "run-gid", 65534, "gid for sqlite process")
	flag.Parse()
	return cfg
}

func handleConn(conn net.Conn, cfg config) {
	defer conn.Close()
	remote := conn.RemoteAddr().String()
	log.Printf("conn %s", remote)
	start := time.Now()

	r := bufio.NewReader(conn)
	w := bufio.NewWriter(conn)

	if err := doPoW(conn, r, w, cfg); err != nil {
		log.Printf("pow %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR pow %v", err))
		return
	}

	logPath, size, err := receiveUpload(conn, r, w, cfg)
	if err != nil {
		log.Printf("upload %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR upload %v", err))
		return
	}
	log.Printf("upload %s: %d bytes to %s", remote, size, logPath)
	_ = writeLine(conn, w, fmt.Sprintf("STAGE upload ok bytes=%d", size))

	tempRoot, err := os.MkdirTemp("", "trustsql-")
	if err != nil {
		log.Printf("tempdir %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR tempdir %v", err))
		return
	}
	log.Printf("env %s: created %s", remote, tempRoot)
	if err := os.Chmod(tempRoot, 0777); err != nil {
		log.Printf("chmod tempdir %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR tempdir %v", err))
		return
	}
	defer func() {
		log.Printf("env %s: removing %s", remote, tempRoot)
		if err := os.RemoveAll(tempRoot); err != nil {
			log.Printf("cleanup %s: %v", remote, err)
			return
		}
		log.Printf("env %s: removed %s", remote, tempRoot)
	}()

	if err := copyDir(cfg.challDir, filepath.Join(tempRoot, "chall"), false); err != nil {
		log.Printf("copy chall %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR setup chall %v", err))
		return
	}
	if err := setChallPermissions(tempRoot); err != nil {
		log.Printf("chmod chall %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR setup chall %v", err))
		return
	}

	dbPath := filepath.Join(tempRoot, "db.sqlite")
	if err := copyFile(logPath, dbPath, 0644); err != nil {
		log.Printf("copy db %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR setup db %v", err))
		return
	}

	libs := []string{
		"/lib/x86_64-linux-gnu/libm.so.6",
		"/lib/x86_64-linux-gnu/libz.so.1",
		"/lib/x86_64-linux-gnu/libc.so.6",
		"/lib64/ld-linux-x86-64.so.2",
		"/lib/x86_64-linux-gnu/libselinux.so.1",
		"/lib/x86_64-linux-gnu/libpcre2-8.so.0",
		"/lib/x86_64-linux-gnu/libtinfo.so.6",
	}
	if err := copyLibs(tempRoot, libs); err != nil {
		log.Printf("copy libs %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR setup libs %v", err))
		return
	}
	if err := copyBins(tempRoot, []string{"/bin/ls", "/bin/cat", "/bin/sh"}); err != nil {
		log.Printf("copy bin %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR setup bin %v", err))
		return
	}
	log.Printf("env %s: setup complete %s", remote, tempRoot)

	_ = writeLine(conn, w, "STAGE setup ok")

	sqlitePath := "/chall/sqlite3"
	_ = writeLine(conn, w, "STAGE sqlite start")
	sqliteStart := time.Now()
	if err := runSqlite(tempRoot, sqlitePath, "/db.sqlite", cfg.execTimeout, cfg.runUID, cfg.runGID); err != nil {
		log.Printf("sqlite %s: %v", remote, err)
		_ = writeLine(conn, w, fmt.Sprintf("ERR sqlite %v", err))
		return
	}
	sqliteMs := time.Since(sqliteStart).Milliseconds()
	_ = writeLine(conn, w, fmt.Sprintf("STAGE sqlite done ms=%d", sqliteMs))
	_ = writeLine(conn, w, fmt.Sprintf("DONE total_ms=%d", time.Since(start).Milliseconds()))
}

func doPoW(conn net.Conn, r *bufio.Reader, w *bufio.Writer, cfg config) error {
	if cfg.powSuffixLen <= 0 {
		return errors.New("pow suffix length must be > 0")
	}
	prefix, err := randHex(8)
	if err != nil {
		return err
	}
	suffix, err := randHex((cfg.powSuffixLen + 1) / 2)
	if err != nil {
		return err
	}
	suffix = suffix[:cfg.powSuffixLen]

	_ = conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if _, err := fmt.Fprintf(w, "POW: find nonce so sha256(\"%s\"+nonce) hex ends with \"%s\".\nSend nonce as a single line:\nnonce> ", prefix, suffix); err != nil {
		return err
	}
	if err := w.Flush(); err != nil {
		return err
	}

	_ = conn.SetReadDeadline(time.Now().Add(cfg.powTimeout))
	nonce, err := readLineLimited(r, maxLineLen)
	if err != nil {
		return err
	}
	nonce = strings.TrimSpace(nonce)
	sum := sha256.Sum256([]byte(prefix + nonce))
	if !strings.HasSuffix(hex.EncodeToString(sum[:]), suffix) {
		return errors.New("pow mismatch")
	}

	_ = conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if _, err := fmt.Fprintln(w, "OK"); err != nil {
		return err
	}
	return w.Flush()
}

func receiveUpload(conn net.Conn, r *bufio.Reader, w *bufio.Writer, cfg config) (string, int64, error) {
	_ = conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if _, err := fmt.Fprintln(w, "SEND 8-BYTE SIZE THEN FILE"); err != nil {
		return "", 0, err
	}
	if err := w.Flush(); err != nil {
		return "", 0, err
	}

	_ = conn.SetReadDeadline(time.Now().Add(cfg.uploadTimeout))
	var sizeBuf [8]byte
	if _, err := io.ReadFull(r, sizeBuf[:]); err != nil {
		return "", 0, err
	}
	size := int64(binary.BigEndian.Uint64(sizeBuf[:]))
	if size < 0 || size > cfg.maxUpload {
		return "", 0, fmt.Errorf("size %d exceeds limit", size)
	}

	logPath, logFile, err := createLogFile(cfg.logDir)
	if err != nil {
		return "", 0, err
	}
	defer logFile.Close()

	written, err := io.CopyN(logFile, r, size)
	if err != nil {
		_ = os.Remove(logPath)
		return "", 0, err
	}
	if written != size {
		_ = os.Remove(logPath)
		return "", 0, fmt.Errorf("short write %d", written)
	}

	_ = conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if _, err := fmt.Fprintln(w, "RECEIVED"); err != nil {
		return "", 0, err
	}
	if err := w.Flush(); err != nil {
		return "", 0, err
	}
	return logPath, size, nil
}

func runSqlite(tempRoot, sqlitePath, dbPath string, timeout time.Duration, uid, gid int) error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	cmd := execCommandContext(ctx, sqlitePath, dbPath, "SELECT * FROM vuln;")
	cmd.Dir = "/"
	cmd.Stdout = io.Discard
	cmd.Stderr = io.Discard
	cmd.SysProcAttr = &syscall.SysProcAttr{
		Chroot:  tempRoot,
		Setpgid: true,
	}
	if uid >= 0 && gid >= 0 {
		cmd.SysProcAttr.Credential = &syscall.Credential{
			Uid: uint32(uid),
			Gid: uint32(gid),
		}
	}

	if err := cmd.Start(); err != nil {
		return err
	}

	done := make(chan error, 1)
	go func() {
		done <- cmd.Wait()
	}()

	select {
	case err := <-done:
		return err
	case <-ctx.Done():
		if cmd.Process != nil {
			_ = syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL)
		}
		<-done
		return fmt.Errorf("sqlite timeout: %w", ctx.Err())
	}
}

func copyBins(root string, paths []string) error {
	binDir := filepath.Join(root, "bin")
	if err := os.MkdirAll(binDir, 0755); err != nil {
		return err
	}
	for _, path := range paths {
		resolved, err := filepath.EvalSymlinks(path)
		if err != nil {
			return err
		}
		info, err := os.Stat(resolved)
		if err != nil {
			return err
		}
		if !info.Mode().IsRegular() {
			return fmt.Errorf("not a file: %s", resolved)
		}
		dst := filepath.Join(binDir, filepath.Base(path))
		if err := copyFileWithMode(resolved, dst, info.Mode()); err != nil {
			return err
		}
	}
	return nil
}

func copyLibs(root string, paths []string) error {
	for _, path := range paths {
		resolved, err := filepath.EvalSymlinks(path)
		if err != nil {
			return err
		}
		info, err := os.Stat(resolved)
		if err != nil {
			return err
		}
		if !info.Mode().IsRegular() {
			return fmt.Errorf("not a file: %s", resolved)
		}
		dst := filepath.Join(root, strings.TrimPrefix(path, "/"))
		if err := copyFileWithMode(resolved, dst, info.Mode()); err != nil {
			return err
		}
	}
	return nil
}

func setChallPermissions(root string) error {
	flagPath := filepath.Join(root, "chall", "flag")
	readflagPath := filepath.Join(root, "chall", "readflag")

	if err := os.Chown(flagPath, 0, 0); err != nil {
		return err
	}
	if err := os.Chmod(flagPath, 0400); err != nil {
		return err
	}
	if err := os.Chown(readflagPath, 0, 0); err != nil {
		return err
	}
	if err := os.Chmod(readflagPath, 0755 | os.ModeSetuid); err != nil {
		return err
	}
	return nil
}

func createLogFile(dir string) (string, *os.File, error) {
	if err := os.MkdirAll(dir, 0755); err != nil {
		return "", nil, err
	}
	file, err := os.CreateTemp(dir, "upload-*.sqlite")
	if err != nil {
		return "", nil, err
	}
	if err := file.Chmod(0644); err != nil {
		_ = file.Close()
		return "", nil, err
	}
	return file.Name(), file, nil
}

func copyDir(src, dst string, hardlink bool) error {
	args := []string{"-a"}
	if hardlink {
		args = append(args, "-l")
	}
	args = append(args, src, dst)
	cmd := exec.Command("cp", args...)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("cp %s -> %s: %w: %s", src, dst, err, strings.TrimSpace(string(out)))
	}
	return nil
}

func copyFile(src, dst string, perm fs.FileMode) error {
	return copyFileWithMode(src, dst, perm)
}

func copyFileWithMode(src, dst string, mode fs.FileMode) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()

	out, err := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, mode.Perm())
	if err != nil {
		return err
	}
	defer out.Close()

	if _, err := io.Copy(out, in); err != nil {
		return err
	}
	return out.Sync()
}

func readLineLimited(r *bufio.Reader, limit int) (string, error) {
	var buf []byte
	for {
		line, isPrefix, err := r.ReadLine()
		if err != nil {
			return "", err
		}
		if len(buf)+len(line) > limit {
			return "", errors.New("line too long")
		}
		buf = append(buf, line...)
		if !isPrefix {
			break
		}
	}
	return string(buf), nil
}

func randHex(nbytes int) (string, error) {
	b := make([]byte, nbytes)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func writeLine(conn net.Conn, w *bufio.Writer, msg string) error {
	_ = conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if !strings.HasSuffix(msg, "\n") {
		msg += "\n"
	}
	if _, err := w.WriteString(msg); err != nil {
		return err
	}
	return w.Flush()
}

// execCommandContext allows tests or wrappers to override behavior.
var execCommandContext = func(ctx context.Context, name string, args ...string) *exec.Cmd {
	return exec.CommandContext(ctx, name, args...)
}
