#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(void) {
	if (setgid(0) != 0 || setuid(0) != 0) {
		fprintf(stderr, "setuid failed: %s\n", strerror(errno));
		return 1;
	}

	int fd = open("/chall/flag", O_RDONLY);
	if (fd < 0) {
		fprintf(stderr, "open failed: %s\n", strerror(errno));
		return 1;
	}

	char buf[4096];
	ssize_t n;
	while ((n = read(fd, buf, sizeof(buf))) > 0) {
		ssize_t off = 0;
		while (off < n) {
			ssize_t w = write(STDOUT_FILENO, buf + off, (size_t)(n - off));
			if (w < 0) {
				fprintf(stderr, "write failed: %s\n", strerror(errno));
				close(fd);
				return 1;
			}
			off += w;
		}
	}
	if (n < 0) {
		fprintf(stderr, "read failed: %s\n", strerror(errno));
		close(fd);
		return 1;
	}

	close(fd);
	return 0;
}
