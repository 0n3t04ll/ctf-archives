#!/bin/sh
# Use this script if you cannot run QEMU in your host machine
docker build . -t i2c-device
docker run --rm -it i2c-device
