#!/bin/sh
./qemu-system-x86_64 \
    -L pc-bios \
    -cpu qemu64 \
    -m 64M \
    -nographic \
    -kernel bzImage \
    -initrd rootfs.cpio \
    -append "console=ttyS0 loglevel=3 oops=panic panic=-1" \
    -no-reboot \
    -monitor /dev/null \
    -device i2c-alpaca,address=0x41
