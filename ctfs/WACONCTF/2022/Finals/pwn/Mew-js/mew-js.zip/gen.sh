#!/bin/bash
wget https://mujs.com/downloads/mujs-1.2.0.tar.xz
tar xf mujs-1.2.0.tar.xz
cd mujs-1.2.0
patch -s -p0 < ../chall.patch
make debug
ls ./build/debug/mujs 