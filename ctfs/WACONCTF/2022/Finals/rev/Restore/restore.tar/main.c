#include<stdio.h>
#include<string.h>
#include<openssl/sha.h>
#include<sys/mman.h>

unsigned int tbl[40] = {496, 364, 268, 592, 728, 688, 532, 152, 392, 148, 388, 400, 248, 392, 364, 416, 412, 440, 224, 460, 224, 196, 608, 728, 728, 532, 412, 676, 412, 104, 488, 296, 304, 344, 244, 104, 728, 56, 532, 748};

// no asm level tricks
// Hint: returns 0 or 1
int check(char *buf) {
    // ????????????????????
}

void decode_func(void *func, void *end, char *buf)
{
    int i;
    int len = strlen(buf);

    mprotect((void *)(((unsigned long long)func) & (~0xFFF)), 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC);
    for(i = 0; i < (unsigned long long)end - (unsigned long long)func; i++)
    {
        ((unsigned char *)func)[i] ^= buf[i % len];
    }
    mprotect((void *)(((unsigned long long)func) & (~0xFFF)), 0x1000, PROT_READ | PROT_EXEC);
}

int check_func(void *ptr_start, void *ptr_end)
{
    int len = (unsigned long long)ptr_end - (unsigned long long)ptr_start;
    unsigned char hash[SHA_DIGEST_LENGTH];
    unsigned char target[SHA_DIGEST_LENGTH] = {28, 225, 123, 174, 150, 98, 211, 165, 174, 245, 77, 38, 1, 171, 94, 98, 250, 90, 169, 67};
    SHA1(ptr_start, len, hash);
    return memcmp(hash, target, SHA_DIGEST_LENGTH);
}

int main() {
    char buf[0x100] = {0, };
    scanf("%255s", buf);

    decode_func(check, decode_func, buf);
    if(check_func(check, decode_func)) {
        puts("Wrong!");
        return 0;
    }

    int res = check(buf);
    if(res == 1) {
        puts("Correct! Your input is flag.");
    } else if(res == 0){
        puts("Wrong!");
    }

    return 0;
}
