const express = require('express')
const app = express()
const port = 80

app.use(function(req, res, next) {
  res.setHeader('X-Frame-Options', 'deny');
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  next();
});

app.get('/', (req, res) => {

  res.send(`
<html>
<head>
<script>
opener=null;
name='';

const xss = new URL(location).searchParams.get("xss") || '';

const characters = /^[a-zA-Z,'+\\.()]+$/;
const words =/eval|setTimeout|setInterval|Function|location|open|document|script|HTML|Element|href|String|Object|Array|Number|atob|call|apply|replace|assign|on|write|import|navigator|navigation|fetch|Symbol|name|this|window|self|top|parent|globalThis|proto|construct/i;

if(xss.length<100 && characters.test(xss) && !words.test(xss)){
	eval(xss);
}
else{
	console.log("try harder");
}
</script>
</head>
<body>
<center>
<br><br><br><br><br>
<h1>which kind of box do you like? or can you escape the boxes?</h1>
<h2><a href="/?xss=alert()">alert</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="/?xss=prompt()">prompt</a></h2>
</center>
</body>
</html>
`)
})

app.listen(port, () => {
  console.log(`app listening at port ${port}`)
})