<?php
    session_save_path('/tmp');
    session_start();
    
    if(!isset($_SESSION['uuid'])) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 32; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        $_SESSION['uuid'] = $randomString;
    }

    $include_url = $_GET['url'];
    if(isset($include_url) && !preg_match("/^(php:|compress\.)|fd|tmp|filter/i",$include_url)){
        include($include_url .'.php');
    } else {
        die("no hack :)");
    }
?>