<?php

    session_save_path('/tmp');
    session_start();

    if(!isset($_SESSION['uuid'])) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 32; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        $_SESSION['uuid'] = $randomString;
    }

    function filter($tempfile) {
        $data = file_get_contents($tempfile);
        if(stripos($data, "__HALT_COMPILER();") !== false || stripos($data, "PK") !== false) { // i hate zip and phar file
            return true;
        }
        else {
            file_put_contents($tempfile, "USER_UPLOAD_DATA" . $data);
            return false;
        }
    }

    $SANDBOX = getcwd() . "/uploads/" . md5("WA!SAFE_SALT" . $_SESSION['uuid']) . basename($_GET['folder']);
    
    mkdir($SANDBOX);

    echo "Here is your current directory : " . $SANDBOX . "<br>";

    if (is_uploaded_file($_FILES['file']['tmp_name'])) {
        if (filter($_FILES['file']['tmp_name'])) {
            die("No hack~~ :)");
        } else {
            if(null != array_pop(explode('.', basename($_FILES['file']['name'])))) {
                $filename = array_pop(explode('.', basename($_FILES['file']['name'])));
                if (move_uploaded_file( $_FILES['file']['tmp_name'], "$SANDBOX/" . $filename)) {
                    echo "File upload success!";
                }
            } else {
                if (move_uploaded_file( $_FILES['file']['tmp_name'], "$SANDBOX/" . basename($_FILES['file']['name']))) {
                    echo "File upload success!";
                }
            }
        }
    }
?>

<form enctype='multipart/form-data' action='upload.php' method='post'>
	<input type='file' name='file'>
	<input type="submit" value="upload"></p>
</form>