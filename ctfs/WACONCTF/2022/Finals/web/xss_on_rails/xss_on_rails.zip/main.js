const express = require('express')
const app = express()
const createDOMPurify = require('dompurify')
const { JSDOM } = require('jsdom')
const port = 5551

app.get('/', (req, res) => {

const user = req.query.user || 'guest';
const action = req.query.action ? /^[a-zA-Z\.]+$/.test(req.query.action) ? req.query.action : 'console.log' : 'console.log'

const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window);
const clean = DOMPurify.sanitize(user);


res.setHeader("Content-Security-Policy", "default-src 'none'; script-src 'self' 'unsafe-inline' https://code.jquery.com https://cdnjs.cloudflare.com/; connect-src https://code.jquery.com");
res.set({
  'Content-Type': 'text/html; charset=utf-8'
})
  res.setHeader('X-Frame-Options', 'deny');
  res.send(`
Wellcome ${clean}

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src=https://cdnjs.cloudflare.com/ajax/libs/jquery-ujs/1.2.3/rails.min.js></script>
<script src="/callback?jsonp=${action}"></script>
`)

})

app.get('/callback', (req, res) => {

res.set({
  'Content-Type': 'application/javascript; charset=utf-8',
  'X-Content-Type-Options': 'nosniff',
})

const jsonp = req.query.jsonp;

res.send(`${jsonp}("website is ready")`)

})

app.listen(port, () => {
  console.log(`app listening at port ${port}`)
})