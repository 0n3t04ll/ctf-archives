#ifndef MANCHESTER_H
#define MANCHESTER_H


#endif /* MANCHESTER_H */
