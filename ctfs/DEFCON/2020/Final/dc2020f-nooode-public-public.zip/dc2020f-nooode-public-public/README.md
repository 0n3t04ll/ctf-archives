# DEFCON 2020 Finals - nooode

Can you find the treasure?
