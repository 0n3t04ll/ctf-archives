#!/bin/sh -e

tar -xf /public-nooode.tar.gz --no-same-owner -C /service || true