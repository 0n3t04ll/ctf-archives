#!/usr/bin/env bash

until yarn start; do
    echo "Bot exited with non-zero status. Restarting..."
done
