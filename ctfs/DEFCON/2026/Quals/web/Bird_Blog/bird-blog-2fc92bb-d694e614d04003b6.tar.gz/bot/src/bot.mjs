import puppeteer from "puppeteer";
import { readdir, readFile } from "node:fs/promises";
import pgp from "pg-promise";

const CONFIG_HOST = process.env.CONFIG_HOST ?? "http://blog_app:8081";
const BLOG_HOST = process.env.BLOG_HOST ?? "http://blog_app:8080";

const db = pgp({})(process.env.BOT_POSTGRES_URL);

await db.one("SELECT count(*) FROM bot.state");

async function getState(key) {
	const row = await db.oneOrNone("SELECT value FROM bot.state WHERE key = $1", [key]);
	return row?.value ?? null;
}

async function setStateIfAbsent(key, value) {
	await db.none(
		"INSERT INTO bot.state (key, value) VALUES ($1, $2) ON CONFLICT (key) DO NOTHING",
		[key, value]
	);
}

const postsDir = new URL("posts/", import.meta.url);

async function loadPosts() {
	const files = (await readdir(postsDir)).filter((f) => f.endsWith(".md")).sort();
	const posts = [];

	for (const file of files) {
		const raw = await readFile(new URL(file, postsDir), "utf-8");
		const separatorIndex = raw.indexOf("\n---\n");
		const header = raw.slice(0, separatorIndex);
		const body = raw.slice(separatorIndex + 5);
		const titleMatch = header.match(/^Title:\s*(.+)$/m);
		const categoriesMatch = header.match(/^Categories:\s*(.+)$/m);

		posts.push({
			title: titleMatch[1].trim(),
			categories: categoriesMatch ? categoriesMatch[1].split(",").map((c) => c.trim()) : [],
			content: body.trimEnd() + "\n",
		});
	}

	return posts;
}

async function fillInput(page, selector, text) {
	await page.$eval(selector, (el) => { el.value = ""; });
	await page.type(selector, text);
}

async function withBrowser(fn) {
	const browser = await puppeteer.launch({
		browser: "chrome",
		headless: true,
		pipe: true,
		executablePath: process.env.PUPPETEER_EXECUTABLE_PATH ?? undefined,
		args: [
			"--no-sandbox",
			"--disable-setuid-sandbox",
			"--disable-dev-shm-usage",
			"--disable-gpu",
			"--no-first-run",
			"--no-zygote",
			"--js-flags=--jitless,--noexpose_wasm"
		]
	});

	try {
		return await fn(browser);
	} finally {
		await browser.close();
	}
}

async function init() {
	if (await getState("configured") === "true") {
		console.log("Bot state says blog is already configured, skipping setup");
		return;
	}

	return await withBrowser(async (browser) => {
		const page = await browser.newPage();
		const resp = await page.goto(BLOG_HOST, { waitUntil: "networkidle0" });

		const status = resp.status()
		if (status !== 200) {
			throw new Error(`Blog is not up yet (status code: ${status})`);
		}

		if (await page.title() === "Musings on Birds") {
			console.log("Blog already looks configured; latching bot state");
			await setStateIfAbsent("configured", "true");
			return;
		}

		console.log("Configuring the blog");
		await page.goto(`${CONFIG_HOST}/configure`, { waitUntil: "networkidle0" });
		await fillInput(page, "input[name=title]", "Musings on Birds");
		await page.click("input[name=theme]#raven");
		await fillInput(page, "input[name=categories]", "*Birdwatching/Tips,*Birdwatching/Stories,*Species/Cardinals,*Species/Warblers,Migration");
		await page.click("button[type=submit]");
		await page.waitForNavigation({ waitUntil: "networkidle0" });
		// Disarm the configure-response meta-refresh before the app restarts.
		await page.goto("about:blank");

		await new Promise((resolve) => setTimeout(resolve, 4000));

		console.log("Configuration complete, now we need a couple of posts...");

		const posts = await loadPosts();
		const postIds = [];
		for (const post of posts) {
			await page.goto(`${CONFIG_HOST}/posts/create`, { waitUntil: "networkidle0" });
			await fillInput(page, "input[name=title]", post.title);
			await fillInput(page, "textarea[name=content]", post.content);
			for (const category of post.categories) {
				await page.click(`input[name=categories]#category-${category}`);
			}
			await page.click("button[type=submit]");
			await page.waitForNavigation({ waitUntil: "networkidle0" });
			const idMatch = page.url().match(/\/posts\/(\d+)\/edit/);
			if (idMatch) {
				postIds.push(parseInt(idMatch[1]));
			}
			console.log(`Created post: ${post.title}${idMatch ? ` (id ${idMatch[1]})` : ""}`);
		}

		if (postIds.length > 0) {
			console.log("Pinning posts to the nav...");
			await page.goto(`${CONFIG_HOST}/configure`, { waitUntil: "networkidle0" });
			await fillInput(page, "input[name=inNavPosts]", postIds.join(","));
			await page.click("button[type=submit]");
			await page.waitForNavigation({ waitUntil: "networkidle0" });
			await page.goto("about:blank");
			await new Promise((resolve) => setTimeout(resolve, 4000));
		}

		await setStateIfAbsent("configured", "true");
		console.log("All done!");
	});
}

async function evaluateWithTimeout(page, fn, timeout = 10000) {
	const evaluationPromise = page.evaluate(fn);
	const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error("Evaluation timed out")), timeout));

	return await Promise.race([evaluationPromise, timeoutPromise]);
}

async function checkComments() { // returns whether or not to immediately check again
	return await withBrowser(async (browser) => {
		const moderationPage = await browser.newPage();
		await moderationPage.goto(`${CONFIG_HOST}/comments`, { waitUntil: "networkidle0" });

		const currentLastUpdated = await evaluateWithTimeout(moderationPage, () => document.querySelector("footer")?.textContent?.trim() ?? "");
		await setStateIfAbsent("last_updated_baseline", currentLastUpdated);
		const baseline = await getState("last_updated_baseline");
		if (baseline !== currentLastUpdated) {
			console.log("I don't remember reconfiguring the blog, what happened here?? Moderating comments can wait until I get to the bottom of this existential crisis");
			return false;
		}

		const firstUnmoderatedComment = await evaluateWithTimeout(moderationPage, () => {
			return document.querySelector("tr:has(form.approve)")?.id;
		});

		if (firstUnmoderatedComment === undefined) {
			return false;
		}

		const approve = async () => {
			await moderationPage.bringToFront();
			console.log("Approving comment");
			await moderationPage.click(`#${firstUnmoderatedComment} form.approve button`);
			await moderationPage.waitForNavigation({ waitUntil: "networkidle0" });
		};

		const reject = async () => {
			await moderationPage.bringToFront();
			console.log("Rejecting comment");
			await moderationPage.click(`#${firstUnmoderatedComment} form.reject button`);
			await moderationPage.waitForNavigation({ waitUntil: "networkidle0" });
		};

		console.log(`Found unmoderated comment with id ${firstUnmoderatedComment}`);
		try {
			const [commentPageTarget] = await Promise.all([
				browser.waitForTarget((target) => target.url().startsWith(`${BLOG_HOST}/comments/`), { timeout: 10000 }),
				moderationPage.click(`#${firstUnmoderatedComment} form.view button`)
			]);

			const commentPage = await commentPageTarget.page();

			if (commentPage === undefined) {
				console.error("Failed to find comment page");
				return true;
			}

			// Take a moment to read the comment...
			await new Promise((resolve) => setTimeout(resolve, 30000));
			const commentHTML = await evaluateWithTimeout(commentPage, () => document.querySelector(".comment")?.innerHTML ?? "");

			if (commentHTML.includes("cat")) {
				console.log("All of this talk of cats will scare my readers, rejecting comment");
				await reject();
				return true;
			} else {
				console.log("Thanks for not talking about cats, approving comment");
				await approve();
				return true;
			}
		} catch (error) {
			console.error(error);
			console.log("Something went wrong and that makes me suspicious, rejecting comment just to be safe");
			await reject();
			return true;
		}
	});
}

await init();

while (true) {
	console.log("Checking for unmoderated comments");
	try {
		const shouldCheckAgain = await checkComments();
		if (!shouldCheckAgain) {
			console.log("No unmoderated comments, waiting 5 seconds before checking again");
			await new Promise((resolve) => setTimeout(resolve, 5000));
		} else {
			console.log("Checking for more unmoderated comments immediately");
		}
	} catch (err) {
		console.error("Error while checking comments, waiting 5 seconds before trying again", err);
		await new Promise((resolve) => setTimeout(resolve, 5000));
	}
}
