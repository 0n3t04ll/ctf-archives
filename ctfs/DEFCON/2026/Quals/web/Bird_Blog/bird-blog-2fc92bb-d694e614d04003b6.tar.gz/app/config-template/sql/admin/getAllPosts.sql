SELECT id, title, content, created_at
FROM posts