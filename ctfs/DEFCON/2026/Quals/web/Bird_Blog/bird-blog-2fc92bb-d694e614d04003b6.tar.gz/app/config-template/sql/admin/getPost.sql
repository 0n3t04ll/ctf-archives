SELECT jsonb_build_object(
	'id', posts.id,
	'title', title,
	'content', content,
	'created_at', created_at,
	'categories', coalesce(
		jsonb_agg(jsonb_build_object(
			'slug', categories.slug,
			'name', categories.name
		)) filter (WHERE categories.slug IS NOT NULL),
		'[]'::jsonb
	)
) as post
FROM posts
	LEFT JOIN post_categories ON posts.id = post_categories.post
	LEFT JOIN categories ON post_categories.category = categories.slug
WHERE posts.id = $1
GROUP BY posts.id
