UPDATE comments
SET approved = $2
WHERE id = $1
