WITH
	post AS (
		UPDATE posts
		SET title = $2, content = $3
		WHERE id = $1
		RETURNING id
	),
	categories AS (
		SELECT slug
		FROM categories
		WHERE slug = ANY($4::text[])
	)
MERGE INTO post_categories AS pc
USING (SELECT post.id AS post_id, categories.slug AS category_slug FROM post, categories) AS src
ON pc.post = src.post_id AND pc.category = src.category_slug
WHEN NOT MATCHED BY TARGET THEN
	INSERT (post, category)
	VALUES (src.post_id, src.category_slug)
WHEN NOT MATCHED BY SOURCE AND EXISTS (SELECT 1 FROM post WHERE id = pc.post) THEN
	DELETE