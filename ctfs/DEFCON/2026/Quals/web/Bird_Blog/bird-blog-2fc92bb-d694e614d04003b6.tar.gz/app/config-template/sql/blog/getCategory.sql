WITH category_posts AS (
	SELECT
		jsonb_build_object(
			'id', posts.id,
			'title', title,
			'content', content,
			'created_at', created_at,
			'categories', coalesce(
				(
					SELECT jsonb_agg(jsonb_build_object(
						'slug', categories.slug,
						'name', categories.name
					))
					FROM categories
						JOIN post_categories ON categories.slug = post_categories.category
					WHERE post_categories.post = posts.id
				),
				'[]'::jsonb
			),
			'comment_count', coalesce(
				(
					SELECT count(*)
					FROM comments
					WHERE comments.post = posts.id AND approved
				),
				0
			)
		) as post,
		created_at
	FROM posts
	WHERE EXISTS (
		SELECT 1
		FROM post_categories
		WHERE post_categories.post = posts.id
			AND post_categories.category = $1
	)
	ORDER BY posts.created_at DESC
	LIMIT 11
	OFFSET ($2 * 10)
)
SELECT jsonb_build_object(
	'slug', slug,
	'name', name,
	'page', $2,
	'hasMorePosts', (
		SELECT count(*)
		FROM category_posts
	) > 10,
	'posts', (
		SELECT jsonb_agg(post)
		FROM (
			SELECT post
			FROM category_posts
			ORDER BY created_at DESC
			LIMIT 10
		)
	)
) as category
FROM categories
WHERE slug = $1