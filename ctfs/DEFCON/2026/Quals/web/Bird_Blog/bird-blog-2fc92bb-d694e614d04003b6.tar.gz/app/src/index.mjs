import { startAdminService } from "./admin.mjs";
import { startBlogService } from "./blog.mjs";

process.on("SIGINT", () => {
	console.log("Received SIGINT. Shutting down...");
	process.exit(0);
});

try {
	await startAdminService();
} catch (err) {
	console.error("Failed to start admin service:", err);
	process.exit(1);
}

try {
	await startBlogService();
} catch (err) {
	console.error("Failed to start blog service:", err);
	process.exit(1);
}
