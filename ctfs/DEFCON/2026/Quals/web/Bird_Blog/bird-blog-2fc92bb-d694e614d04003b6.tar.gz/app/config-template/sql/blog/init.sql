CREATE TABLE categories (
	id SERIAL PRIMARY KEY,
	slug text not null unique,
	name text not null unique
);

CREATE TABLE posts (
	id SERIAL PRIMARY KEY,
	title text not null,
	content text not null,
	created_at timestamptz default current_timestamp
);

CREATE TABLE post_categories (
	post integer not null references posts (id) on delete cascade,
	category text not null references categories (slug) on delete cascade,
	PRIMARY KEY (post, category)
);

CREATE TABLE comments (
	id SERIAL PRIMARY KEY,
	post integer not null references posts (id) on delete cascade,
	author text not null,
	content text not null,
	created_at timestamptz default current_timestamp,
	approved boolean
);
