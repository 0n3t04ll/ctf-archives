SELECT slug, name
FROM categories
ORDER BY id;
