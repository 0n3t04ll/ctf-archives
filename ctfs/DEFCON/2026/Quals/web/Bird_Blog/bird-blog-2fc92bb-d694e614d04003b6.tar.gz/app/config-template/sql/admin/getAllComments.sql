SELECT
	id,
	(
		SELECT jsonb_build_object(
			'id', comments.post,
			'title', posts.title
		)
		FROM posts
		WHERE posts.id = comments.post
	) AS post,
	author,
	created_at,
	approved
FROM comments
ORDER BY created_at
