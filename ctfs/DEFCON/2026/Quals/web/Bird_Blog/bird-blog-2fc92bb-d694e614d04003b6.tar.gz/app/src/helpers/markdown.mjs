export function markdown(content) {
	const paragraphs = content.replace(/\r/g, "").split("\n\n");
	return paragraphs.map((paragraph) => `<p>${markdownInline(paragraph)}</p>`).join("");
}

function markdownInline(content) {
	content = content.replace(/\n/g, "");

	content = content.replace(/[<>&]/g, (char) => `&#${char.charCodeAt(0)};`);
	content = content.replace(/[^\x00-\x7F]/ug, (char) => `&#${char.codePointAt(0)};`);
	content = content.replace(/(?<!\w)"(?=\w)/g, "&ldquo;");
	content = content.replace(/"/g, "&rdquo;");
	content = content.replace(/(?<!\w)'(?=\w)/g, "&lsquo;");
	content = content.replace(/'/g, "&rsquo;");

	content = content.replace(/(__|\*\*)((?:(?!\1).)+?)\1/g, (match, p1, p2) => {
		return `<strong>${p2}</strong>`;
	});
	content = content.replace(/(_|\*)((?:(?!\1).)+?)\1/g, (match, p1, p2) => {
		return `<em>${p2}</em>`;
	});
	content = content.replace(/`([^`]+?)`/g, (match, p1) => {
		return `<code>${p1}</code>`;
	});
	content = content.replace(/~~((?:(?!~~).)+?)~~/g, (match, p1) => {
		return `<del>${p1}</del>`;
	});
	content = content.replace(/!\[([^\]]*)\]\((https?:\/\/[a-zA-Z0-9.-]+(?::\d+)?\/[^)]+)\)/g, (match, alt, url) => {
		try {
			const parsedUrl = new URL(url);
			return `<img src="${parsedUrl.href}" alt="${alt}">`;
		} catch {
			return match;
		}
	});
	content = content.replace(/\[([^\]]+)\]\((https?:\/\/[a-zA-Z0-9.-]+(?::\d+)?\/[^)]+)\)/g, (match, text, url) => {
		try {
			const parsedUrl = new URL(url);
			return `<a href="${parsedUrl.href}">${text}</a>`;
		} catch {
			return match;
		}
	});

	if (content.startsWith("#")) {
		content = content.replace(/^(#+)\s*(.*)$/, (match, hashes, text) => {
			const level = 2 + Math.min(hashes.length, 3);
			return `<h${level}>${text}</h${level}>`;
		});
	}

	return content;
}