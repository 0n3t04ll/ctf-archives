WITH
	post AS (
		INSERT INTO posts (title, content)
		VALUES ($1, $2)
		RETURNING id
	),
	categories AS (
		SELECT slug
		FROM categories
		WHERE slug = ANY($3::text[])
	),
	_ AS (
		INSERT INTO post_categories (post, category)
		SELECT post.id, categories.slug
		FROM post, categories
	)
SELECT id FROM post