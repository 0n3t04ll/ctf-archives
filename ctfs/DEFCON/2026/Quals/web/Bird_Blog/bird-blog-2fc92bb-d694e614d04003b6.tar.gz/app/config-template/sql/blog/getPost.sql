SELECT jsonb_build_object(
	'id', posts.id,
	'title', title,
	'content', content,
	'created_at', created_at,
	'categories', coalesce(
		(
			SELECT jsonb_agg(jsonb_build_object(
				'slug', categories.slug,
				'name', categories.name
			))
			FROM categories
				JOIN post_categories ON categories.slug = post_categories.category
			WHERE post_categories.post = posts.id
		),
		'[]'::jsonb
	),
	'comments', coalesce(
		(
			SELECT jsonb_agg(jsonb_build_object(
				'id', comments.id,
				'author', comments.author,
				'content', comments.content,
				'created_at', comments.created_at
			) ORDER BY comments.created_at)
			FROM comments
			WHERE comments.post = posts.id AND approved
		),
		'[]'::jsonb
	)
) as post
FROM posts
WHERE posts.id = $1
