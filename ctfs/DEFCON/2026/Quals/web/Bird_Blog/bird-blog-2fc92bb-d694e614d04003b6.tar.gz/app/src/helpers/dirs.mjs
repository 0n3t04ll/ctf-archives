export const appDir = new URL("../../", import.meta.url);
export const templateDir = new URL("template/", appDir);
export const configTemplateDir = new URL("config-template/", appDir);
export const sqlDir = new URL("sql/", templateDir);
export const hbsDir = new URL("hbs/", templateDir);
export const blogHbsDir = new URL("blog/", hbsDir);
export const adminHbsDir = new URL("admin/", hbsDir);
export const staticDir = new URL("static/", appDir);