#!/usr/bin/env bash

until yarn start; do
    echo "Application exited with non-zero status. Restarting..."
done
