import { createHash, timingSafeEqual, randomBytes } from "node:crypto";

import fastify from "fastify";
import fastifyView from "@fastify/view";
import fastifyFormbody from "@fastify/formbody";
import fastifyCookie from "@fastify/cookie";
import fastifyStatic from "@fastify/static";
import handlebars from "handlebars";

import { configure, adminInitialized } from "./helpers/configure.mjs";
import { adminHbsDir, staticDir } from "./helpers/dirs.mjs";
import { executeQuery } from "./helpers/db.mjs";

const LOCALHOST_ONLY_REGEX = /^127\.0\.0\.1$/;
const PRIVATE_IP_REGEX = /^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.)/;
const ALLOW_PRIVATE_IPS = process.env.CONFIG_ALLOW_PRIVATE_IPS === "true";
const IP_REGEX = ALLOW_PRIVATE_IPS ? PRIVATE_IP_REGEX : LOCALHOST_ONLY_REGEX;
const BLOG_HOST = process.env.BLOG_HOST ?? "http://localhost:8080";

export async function startAdminService() {
	if (!adminInitialized) {
		console.log("Detected missing admin templates — running initial configuration to ensure they are present.  Application will restart.");
		await configure({}, true);
		process.exit(2);
	}

	const app = fastify();

	app.register(fastifyFormbody);
	app.register(fastifyCookie);

	app.register(fastifyStatic, {
		root: staticDir.pathname,
		prefix: "/static/"
	});

	app.register(fastifyView, {
		engine: { handlebars },
		root: adminHbsDir.pathname,
		layout: "layout.hbs"
	});

	app.decorateRequest("csrfToken", null);

	app.addHook("preHandler", async (request, reply) => {
		if (!IP_REGEX.test(request.ip)) {
			console.log(`Blocked request from disallowed IP: ${request.ip}`);
			reply.status(403).send({ error: `Forbidden; you must access this page from ${ALLOW_PRIVATE_IPS ? "a private IP" : "localhost"}` });
			return;
		}

		if (request.method === "POST") {
			const csrfSecret = request.cookies._csrf;
			const bodyCsrfToken = request.body?.csrfToken;

			if (csrfSecret === undefined || csrfSecret === "") {
				reply.status(400).send({ error: "CSRF secret cookie missing" });
				return;
			}

			if (bodyCsrfToken === undefined) {
				reply.status(400).send({ error: "CSRF token missing in request body" });
				return;
			}

			const [csrfSalt, csrfHash] = bodyCsrfToken.split(";");
			if (!csrfSalt || !csrfHash) {
				reply.status(400).send({ error: "Invalid CSRF token format" });
				return;
			}

			const hash = createHash("sha256").update(csrfSalt + ":" + csrfSecret).digest();

			if (!timingSafeEqual(Buffer.from(csrfHash, "hex"), hash)) {
				reply.status(403).send({ error: "Invalid CSRF token" });
				return;
			}
		}

		let csrfSecret = request.cookies._csrf;

		if (!csrfSecret) {
			csrfSecret = randomBytes(16).toString("hex");
			reply.header("Set-Cookie", `_csrf=${csrfSecret}; HttpOnly; SameSite=Strict; Path=/; Max-Age=3600`);
		}

		const csrfSalt = randomBytes(16).toString("hex");
		const csrfHash = createHash("sha256").update(csrfSalt + ":" + csrfSecret).digest("hex");
		const csrfToken = `${csrfSalt};${csrfHash}`;
		request.csrfToken = csrfToken;
	});

	app.get("/", async (request, reply) => {
		return reply.view("index.hbs", { csrfToken: request.csrfToken });
	});

	app.get("/posts", async (request, reply) => {
		const posts = await executeQuery("admin/getAllPosts");
		return reply.view("posts.hbs", { posts, blogHost: BLOG_HOST, csrfToken: request.csrfToken });
	});

	app.get("/posts/create", async (request, reply) => {
		const categories = await executeQuery("admin/getCategories");
		return reply.view("editPost.hbs", { categories, csrfToken: request.csrfToken, message: request.query.message });
	});

	app.get("/posts/:id/edit", async (request, reply) => {
		const [[{ post }], categories] = await Promise.all([
			executeQuery("admin/getPost", [request.params.id]),
			executeQuery("admin/getCategories")
		]);
		return reply.view("editPost.hbs", { post, categories, message: request.query.message, csrfToken: request.csrfToken });
	});

	app.post("/posts/create", async (request, reply) => {
		let { title, content, categories } = request.body;
		if (!title || !content || !categories) {
			reply.status(400).send({ error: "Title, content, and categories are required" });
			return;
		}

		if (!Array.isArray(categories)) {
			categories = [categories];
		}

		const [{ id }] = await executeQuery("admin/createPost", [title, content, categories]);
		reply.redirect(`/posts/${id}/edit?message=Post+created!`);
	});

	app.post("/posts/:id/edit", async (request, reply) => {
		let { title, content, categories } = request.body;
		if (!title || !content || !categories) {
			reply.status(400).send({ error: "Title, content, and categories are required" });
			return;
		}

		if (!Array.isArray(categories)) {
			categories = [categories];
		}

		await executeQuery("admin/updatePost", [request.params.id, title, content, categories]);
		reply.redirect(`/posts/${request.params.id}/edit?message=Post+updated!`);
	});

	app.get("/comments", async (request, reply) => {
		const comments = await executeQuery("admin/getAllComments");
		return reply.view("comments.hbs", { comments, blogHost: BLOG_HOST, csrfToken: request.csrfToken });
	});

	app.post("/comments/:id/approve", async (request, reply) => {
		await executeQuery("admin/setCommentApproved", [request.params.id, true]);
		reply.redirect("/comments");
	});

	app.post("/comments/:id/reject", async (request, reply) => {
		await executeQuery("admin/setCommentApproved", [request.params.id, false]);
		reply.redirect("/comments");
	});

	app.get("/configure", async (request, reply) => {
		return reply.view("configure.hbs", { csrfToken: request.csrfToken });
	});

	app.post("/configure", async (request, reply) => {
		if (request.body === undefined) {
			reply.status(400).send({ error: "Missing request body" });
			return;
		}

		await configure(request.body);
		reply.header("Content-Type", "text/html");
		reply.send(`
			<!DOCTYPE html>
			<html>
			<head>
				<title>Configuration Updated</title>
				<link rel="stylesheet" href="/static/admin.css">
				<meta http-equiv="refresh" content="5;url=/configure">
			</head>
			<body>
				<div class="container">
					<h1>Configuration Updated</h1>
					<div class="flash success">Configuration saved successfully. The application is restarting&hellip;</div>
					<p>You will be redirected shortly. If not, <a href="/configure">click here</a>.</p>
				</div>
			</body>
			</html>
		`);
		console.log("Configuration updated, restarting...");
		setTimeout(() => process.exit(2), 500);
	});

	await app.listen({ port: 8081, host: process.env.CONFIG_BIND_ADDRESS ?? "localhost" });
}
