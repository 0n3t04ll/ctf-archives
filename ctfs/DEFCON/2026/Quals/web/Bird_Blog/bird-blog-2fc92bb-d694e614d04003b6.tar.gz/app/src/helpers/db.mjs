import pgp from "pg-promise";

import { sqlDir } from "./dirs.mjs";

const pgpInstance = pgp({});

const db = pgpInstance(process.env.POSTGRES_URL ?? "postgres://user:password@localhost:5432/mydb");
export let initialized = false;

const initTest = await db.oneOrNone("SELECT to_regclass('public.posts') is not null AS exists");
initialized = initTest?.exists === true;

if (!initialized) {
	try {
		const initSql = new pgp.QueryFile(new URL("blog/init.sql", sqlDir));
		await db.any(initSql);
		initialized = true;
	} catch (err) {
		if (err.message.startsWith("ENOENT")) {
			console.error("Initialization SQL file not found.");
		} else {
			console.error("Error during database initialization:", err);
		}
	}
}

// Always reload categories, in case the configuration changed
try {
	const categoriesSql = new pgp.QueryFile(new URL("blog/categories.sql", sqlDir));
	await db.any(categoriesSql);
} catch (err) {
	console.error("Error reloading categories:", err);
}

const queryCache = new Map();

export async function executeQuery(name, parameters = []) {
	let queryFile;

	if (queryCache.has(name)) {
		queryFile = queryCache.get(name);
	} else {
		queryFile = new pgp.QueryFile(new URL(`${name}.sql`, sqlDir));
		queryCache.set(name, queryFile);
	}

	const result = await db.any(queryFile, parameters);
	return result;
}
