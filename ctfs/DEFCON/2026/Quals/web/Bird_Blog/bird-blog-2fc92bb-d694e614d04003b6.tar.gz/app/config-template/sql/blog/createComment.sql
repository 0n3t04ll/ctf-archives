INSERT INTO comments (post, author, content)
VALUES ($1, $2, $3)