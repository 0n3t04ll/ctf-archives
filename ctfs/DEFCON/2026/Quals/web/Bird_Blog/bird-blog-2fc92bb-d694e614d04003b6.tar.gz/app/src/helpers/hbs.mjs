import { readFile } from "node:fs/promises";

import handlebars from "handlebars";

import { slugify } from "./slugify.mjs";
import { hbsDir } from "./dirs.mjs";
import { markdown } from "./markdown.mjs";

handlebars.registerHelper("sqlString", function (str) {
	return `'${str}'`.replace(/'/g, "''").slice(1, -1);
});

handlebars.registerHelper("slugify", function (str) {
	const slug = slugify(str.replace(/\//g, " "), { lower: true, remove: /[^\w\s]/ });
	if (slug.includes("/")) {
		// Needs to be a valid URL segment
		throw new Error(`Invalid slug "${slug}" generated from "${str}"`);
	}
	return slug;
});

handlebars.registerHelper("formatCategory", function (name) {
	const parts = name.split("/").map((p) => p.trim());
	if (parts.length > 2) {
		throw new Error(`Invalid category name "${name}"; only one level of nesting is supported`);
	}
	return parts.join(" » ");
});

handlebars.registerHelper("isArray", function (value) {
	return Array.isArray(value);
});

handlebars.registerHelper("urlEncode", function (str) {
	return encodeURIComponent(str);
});

handlebars.registerHelper("hbsEscape", function (str) {
	return new handlebars.SafeString(
		str.replace(/[^a-zA-Z0-9-_]/g, (char) => `&#${char.charCodeAt(0)};`)
	);
});

handlebars.registerHelper("hasCategory", function (post, category) {
	return post.categories.some((cat) => cat.slug === category);
});

handlebars.registerHelper("relativeTime", function (datetime) {
	const now = new Date();
	const then = new Date(datetime);
	const diff = Math.floor((now - then) / 1000);

	if (diff < 10) {
		return "a few seconds ago";
	} else if (diff < 60) {
		return `${diff} seconds ago`;
	} else if (diff < 3600) {
		const minutes = Math.floor(diff / 60);
		return minutes === 1 ? "1 minute ago" : `${minutes} minutes ago`;
	} else if (diff < 86400) {
		const hours = Math.floor(diff / 3600);
		return hours === 1 ? "1 hour ago" : `${hours} hours ago`;
	} else {
		const days = Math.floor(diff / 86400);
		return days === 1 ? "1 day ago" : `${days} days ago`;
	}
});

handlebars.registerHelper("markdown", function (content) {
	return new handlebars.SafeString(markdown(content));
});

handlebars.registerHelper("markdownPreview", function (content) {
	const parts = content.replace(/\r/g, "").split("\n\n");

	if (parts[0].startsWith("#")) {
		content = parts.slice(0, 2).join("\n\n");
	} else {
		content = parts[0];
	}

	return new handlebars.SafeString(markdown(content));
});

handlebars.registerHelper("pluralize", function (count, singular, plural) {
	if (count === 1) {
		return singular;
	} else {
		return plural ?? singular + "s";
	}
});

handlebars.registerHelper("isNullish", function (value) {
	return value === undefined || value === null;
});

handlebars.registerHelper("eq", function (a, b) {
	return a === b;
});

handlebars.registerHelper("not", function (value) {
	return !value;
});

handlebars.registerHelper("add", function (a, b) {
	return a + b;
});

const partials = ["article", "comment", "articleTitle", "pageNav", "topCategories"];
export let adminInitialized = true;

for (const partial of partials) {
	const partialPath = new URL(`partials/${partial}.hbs`, hbsDir);
	try {
		const partialContent = await readFile(partialPath, "utf-8");
		handlebars.registerPartial(partial, partialContent);
	} catch {
		console.error(`Failed to load ${partial} partial`);
		adminInitialized = false;
	}
}
