import fs from "node:fs/promises";
import path from "node:path";

import handlebars from "handlebars";

import { templateDir, configTemplateDir, sqlDir, hbsDir } from "./dirs.mjs";
import { executeQuery } from "./db.mjs";

// Ensure handlebars helpers and partials are registered
export { adminInitialized } from "./hbs.mjs";

const defaultCategories = [
	"Birdwatching",
	"Conservation",
	"Bird Photography",
	"Behavior and Migration Patterns",
];

export async function configure(rawArgs, adminOnly = false) {
	let categories = rawArgs?.categories?.split(",").map((category) => category.trim()).filter((category) => category.length > 0);

	if (categories === undefined || categories.length === 0) {
		categories = defaultCategories;
	}

	if (categories.length > 12) {
		throw new Error("Too many categories specified; maximum is 12");
	}

	categories = categories.map((rawCategory) => {
		let inNav = false;
		let name = rawCategory;
		if (name.startsWith("*")) {
			inNav = true;
			name = name.slice(1).trim();
		}
		const parts = name.split("/").map((part) => part.trim());
		if (parts.length > 2) {
			throw new Error(`Invalid category name "${name}"; only one level of nesting is supported`);
		}
		return { name: parts.join("/"), inNav };
	});

	const navTree = {};
	for (const category of categories) {
		if (!category.inNav) {
			continue;
		}

		const dividerIndex = category.name.indexOf("/");

		if (dividerIndex !== -1) {
			const superCategory = category.name.slice(0, dividerIndex).trim();
			const subCategory = category.name.slice(dividerIndex + 1).trim();

			if (Array.isArray(navTree[superCategory])) {
				throw new Error(`Invalid category hierarchy: "${superCategory}" is both a category and a super-category`);
			}

			navTree[superCategory] ??= {};
			navTree[superCategory][subCategory] = [];
		} else {
			if (category.name in navTree) {
				throw new Error(`Invalid category hierarchy: "${category.name}" is both a category and a super-category`);
			}

			navTree[category.name] = [];
		}
	}

	let inNavPosts = rawArgs?.inNavPosts?.split(",").map((id) => parseInt(id.trim())).filter((id) => !isNaN(id));

	if (inNavPosts === undefined) {
		inNavPosts = [];
	}

	try {
		for (const postId of inNavPosts) {
			const [{ post }] = await executeQuery("admin/getPost", [postId]);
			for (const superCategory of Object.keys(navTree)) {
				if (Array.isArray(navTree[superCategory])) {
					if (post.categories.some((cat) => cat.name === superCategory)) {
						navTree[superCategory].push(post);
						break;
					}
				} else {
					for (const subCategory of Object.keys(navTree[superCategory])) {
						const fullName = `${superCategory}/${subCategory}`;
						if (post.categories.some((cat) => cat.name === fullName)) {
							navTree[superCategory][subCategory].push(post);
							break;
						}
					}
				}
			}
		}
	} catch (err) {
		console.error("Error validating inNav posts, ignoring since this probably means the site wasn't configured yet");
	}

	const args = {
		categories,
		topCategories: categories.filter((c) => c.inNav).slice(0, 3),
		navTree,
		categoriesString: categories.map((c) => (c.inNav ? "*" : "") + c.name).join(","),
		inNavPostsString: inNavPosts.join(","),
		theme: rawArgs.theme ?? "bluebird",
		title: rawArgs.title?.trim() ?? "My Bird Blog",
		lastUpdated: new Date().toISOString(),
	};

	// We can't delete the entire template directory because it's a volume, so delete the subdirectories instead
	await fs.rm(sqlDir, { recursive: true, force: true });
	await fs.rm(hbsDir, { recursive: true, force: true });

	for (const file of await fs.readdir(configTemplateDir, { recursive: true, withFileTypes: true })) {
		if (file.isDirectory()) {
			continue;
		}

		const filePath = path.join(file.parentPath, file.name);
		const relativePath = path.relative(configTemplateDir.pathname, filePath);

		if (adminOnly && !relativePath.includes("/admin/") && !relativePath.includes("/partials/")) {
			continue;
		}

		await fs.mkdir(new URL(path.dirname(relativePath), templateDir), { recursive: true });

		if (relativePath.endsWith(".chbs")) {
			const templateContent = await fs.readFile(filePath, "utf-8");
			const template = handlebars.compile(templateContent);
			const rendered = template(args);
			const outputPath = new URL(relativePath.replace(".chbs", ""), templateDir);
			await fs.writeFile(outputPath, rendered, "utf-8");
		} else {
			const outputPath = new URL(relativePath, templateDir);
			await fs.copyFile(filePath, outputPath);
		}
	}
}
