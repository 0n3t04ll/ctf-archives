import fastify from "fastify";
import fastifyFormbody from "@fastify/formbody";
import fastifyView from "@fastify/view";
import fastifyStatic from "@fastify/static";
import handlebars from "handlebars";

import { initialized, executeQuery } from "./helpers/db.mjs";
import { blogHbsDir, staticDir } from "./helpers/dirs.mjs";

function formatCategoryName(name) {
	return name.split("/").map((p) => p.trim()).join(" » ");
}

export async function startBlogService() {
	const app = fastify();

	if (!initialized) {
		app.get("/", async (request, reply) => {
			reply.header("Content-Type", "text/html");
			return reply.send(`
				<!DOCTYPE html>
				<html lang="en">
				<head>
					<meta charset="UTF-8">
					<meta name="viewport" content="width=device-width, initial-scale=1.0">
					<title>Blog Not Configured</title>
					<style>
						body {
							font-family: Arial, sans-serif;
							text-align: center;
							padding: 50px;
						}
						h1 {
							font-size: 2em;
							color: #333;
						}
						p {
							font-size: 1.2em;
							color: #666;
						}
						a {
							color: #007BFF;
							text-decoration: none;
						}
						a:hover {
							text-decoration: underline;
						}
					</style>
				</head>
				<body>
					<h1>Ain't nobody here but us chickens!</h1>
					<p>The blog hasn't been configured yet. If you're the admin, visit <a href="http://localhost:8081/configure">http://localhost:8081/configure</a> to set up the blog.</p>
					<p>Once you've completed the configuration, refresh this page to see the blog.</p>
				</body>
				</html>
			`);
		});
	} else {
		app.register(fastifyFormbody);

		app.register(fastifyStatic, {
			root: staticDir.pathname,
			prefix: "/static/"
		});

		app.register(fastifyView, {
			engine: { handlebars },
			root: blogHbsDir.pathname,
			layout: "layout.hbs",
		});

		app.get("/", async (request, reply) => {
			try {
				const [{ posts }] = await executeQuery("blog/archive", [0]);
				return reply.view("index.hbs", { posts });
			} catch (err) {
				console.error(err);
				return reply.status(500).send("Internal Server Error");
			}
		});

		app.get("/archive/:page", async (request, reply) => {
			try {
				const page = parseInt(request.params.page);
				if (isNaN(page) || page < 1) {
					return reply.status(400).send("Invalid page number");
				}

				const [{ posts }] = await executeQuery("blog/archive", [page - 1]);
				return reply.view("archive.hbs", { pageTitle: `Archive - Page ${page}`, posts, currentPage: page });
			} catch (err) {
				console.error(err);
				return reply.status(500).send("Internal Server Error");
			}
		});

		app.get("/categories/:slug", async (request, reply) => {
			try {
				const [{ category }] = await executeQuery("blog/getCategory", [request.params.slug, 0]);
				if (!category) {
					return reply.status(404).send("Category not found");
				}
				return reply.view("category.hbs", { pageTitle: `Category - ${formatCategoryName(category.name)}`, category });
			} catch (err) {
				console.error(err);
				return reply.status(500).send("Internal Server Error");
			}
		});

		app.get("/categories/:slug/:page", async (request, reply) => {
			try {
				const page = parseInt(request.params.page);
				if (isNaN(page) || page < 1) {
					return reply.status(400).send("Invalid page number");
				}

				const [{ category }] = await executeQuery("blog/getCategory", [request.params.slug, page - 1]);
				if (!category) {
					return reply.status(404).send("Category not found");
				}
				return reply.view("category.hbs", { pageTitle: `Category - ${formatCategoryName(category.name)}`, category, currentPage: page });
			} catch (err) {
				console.error(err);
				return reply.status(500).send("Internal Server Error");
			}
		});

		app.get("/post/:id", async (request, reply) => {
			try {
				const [{ post }] = await executeQuery("blog/getPost", [request.params.id]);
				return reply.view("post.hbs", { pageTitle: post.title, post });
			} catch (err) {
				console.error(err);
				return reply.status(500).send("Internal Server Error");
			}
		});

		app.post("/post/:id/comments", async (request, reply) => {
			try {
				await executeQuery("blog/createComment", [request.params.id, request.body.author, request.body.content]);
				return reply.redirect(`/post/${request.params.id}`);
			} catch (err) {
				console.error(err);
				return reply.status(500).send("Internal Server Error");
			}
		});

		app.get("/comments/:id/view", async (request, reply) => {
			try {
				const [comment] = await executeQuery("blog/getComment", [request.params.id]);
				return reply.view("comment.hbs", { pageTitle: `Comment by ${comment.author}`, comment });
			} catch (err) {
				console.error(err);
				return reply.status(500).send("Internal Server Error");
			}
		});
	}

	await app.listen({ port: 8080, host: "0.0.0.0" });
}
