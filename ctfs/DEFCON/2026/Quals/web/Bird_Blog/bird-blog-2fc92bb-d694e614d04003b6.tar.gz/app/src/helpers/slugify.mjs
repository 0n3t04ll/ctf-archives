import anyascii from "any-ascii";

export function slugify(text, options = {}) {
	let slug = text.split("").reduce((acc, cur) => {
		cur = anyascii(cur);
		return acc + cur.replace(options.remove ?? /[^\w\s$*_+~.()'"!\-:@]+/g, "");
	}, "");

	if (options.trim ?? true) {
		slug = slug.trim();
	}

	slug = slug.replace(/-+/g, "-");
	slug = slug.replace(/^-+|-+$/g, "");
	slug = slug.replace(/\s+/g, "-");

	if (options.lower ?? false) {
		slug = slug.toLowerCase();
	}

	return slug;
}
