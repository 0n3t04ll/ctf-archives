SELECT
	id,
	(
		SELECT jsonb_build_object(
			'id', comments.post,
			'title', posts.title
		)
		FROM posts
		WHERE posts.id = comments.post
	) AS post,
	author,
	created_at,
	content
FROM comments
WHERE id = $1
