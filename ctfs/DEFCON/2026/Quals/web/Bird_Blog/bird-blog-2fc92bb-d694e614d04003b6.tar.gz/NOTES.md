On the live server, the `BLOG_HOST` environment variable (for both the `blog_app` and `bot` services) will be set to the public URL of the blog application. Please keep this in mind when testing your solution locally. The dockerfile uses `host.docker.internal:8080` in an effort to provide a configuration that works out of the box, but **this is may not be a 100% accurate representation of the deployment environment**.

All of the services are running on the same network namespace to simulate running in a single Kubernetes pod, which is how they are actually deployed.

The `SECRET_KEY`, `APP_PASSWORD`, `POSTGRES_PASSWORD`, and `BOT_PASSWORD` environment variables are randomized for each instance.
