import { createHash, timingSafeEqual, randomBytes } from "node:crypto";

import fastify from "fastify";
import fastifyView from "@fastify/view";
import fastifyFormbody from "@fastify/formbody";
import fastifyStatic from "@fastify/static";
import handlebars from "handlebars";

const SECRET_KEY = process.env.SECRET_KEY;
const FLAG = process.env.FLAG;
const SECRET_KEY_HASH = createHash("sha256").update(SECRET_KEY).digest();
let remainingAttempts = parseInt(process.env.ADMIN_PASSWORD_ATTEMPTS ?? "5", 10);

const app = fastify();

app.register(fastifyFormbody);

app.register(fastifyStatic, {
	root: new URL("../static/", import.meta.url).pathname,
	prefix: "/static/"
});

app.register(fastifyView, {
	engine: { handlebars },
	root: new URL("../views/", import.meta.url).pathname,
	layout: "layout.hbs"
});

app.get("/", async (request, reply) => {
	return reply.view("index.hbs");
});

app.post("/submit", async (request, reply) => {
	const { secretKey } = request.body;

	if (typeof secretKey !== "string") {
		return reply.status(400).send("Invalid request");
	}

	if (remainingAttempts <= 0) {
		return reply.status(403).send("No remaining attempts");
	}

	const providedKeyHash = createHash("sha256").update(secretKey).digest();

	if (timingSafeEqual(providedKeyHash, SECRET_KEY_HASH)) {
		return reply.view("flag.hbs", { flag: FLAG });
	} else {
		remainingAttempts--;
		return reply.view("index.hbs", { error: `Incorrect secret key. Remaining attempts: ${remainingAttempts}` });
	}
});

await app.listen({ port: 1337, host: "0.0.0.0" });