#!/bin/sh
timeout 240 /poool
