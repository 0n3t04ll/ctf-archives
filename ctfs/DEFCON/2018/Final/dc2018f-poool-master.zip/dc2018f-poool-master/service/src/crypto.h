#ifndef _CRYPTO_H
#define _CRYPTO_H

#include <stdlib.h>

void ooo_hash(const unsigned char *d, size_t n, unsigned char *md);

#endif