#ifndef _DAEMON_H
#define _DAEMON_H

void *daemon_thread(void *args);

void daemon_notify();

#endif
