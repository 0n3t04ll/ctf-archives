#!/bin/bash

mkdir -p /aoool /aoool/bin/ /aoool/etc/ \
  /aoool/var/www/main /aoool/var/www/uploads /aoool/var/log

chmod 777 /aoool/var/log
chmod 777 /aoool/var/www/uploads
