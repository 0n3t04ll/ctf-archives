#!/bin/bash -e

file /service | grep -q "ELF"
