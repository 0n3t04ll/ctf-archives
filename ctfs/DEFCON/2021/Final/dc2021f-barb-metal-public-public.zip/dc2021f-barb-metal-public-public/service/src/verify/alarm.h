#ifndef MRBC_ALARM_H_
#define MRBC_ALARM_H_

#ifdef __cplusplus
extern "C" {
#endif

struct VM;
void mrbc_init_class_alarm(struct VM *vm);


#ifdef __cplusplus
}
#endif
#endif
