#ifndef B64_H_
#define B64_H_

#ifdef __cplusplus
extern "C" {
#endif

struct VM;
void mrbc_init_class_b64(struct VM *vm);

#ifdef __cplusplus
}
#endif
#endif // QEMUART_H_
