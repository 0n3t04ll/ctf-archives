/* LibTomCrypt, modular cryptographic library -- Tom St Denis */
/* SPDX-License-Identifier: Unlicense */
#include "tomcrypt_private.h"

#ifdef LTC_PRNG_ENABLE_LTC_RNG
unsigned long (*ltc_rng)(unsigned char *out, unsigned long outlen, void (*callback)(void));
#endif
