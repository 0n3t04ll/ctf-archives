class MyEqual3

end
