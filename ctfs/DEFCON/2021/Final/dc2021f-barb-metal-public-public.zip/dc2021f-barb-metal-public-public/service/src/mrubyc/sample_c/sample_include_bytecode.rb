#
# mrbc -E -Bary sample_include_bytecode.rb
#

while true
  puts "sample"
  sleep 1
end
