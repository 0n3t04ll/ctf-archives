
a = MyClass.new
a.func
