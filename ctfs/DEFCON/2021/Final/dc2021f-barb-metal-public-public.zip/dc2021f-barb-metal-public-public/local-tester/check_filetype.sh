#!/bin/bash -e

# file /service | grep -q "ELF"
exit 0
