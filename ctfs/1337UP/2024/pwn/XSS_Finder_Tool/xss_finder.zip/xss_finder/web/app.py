from flask import *
import re
import requests

app = Flask(__name__)
url_Regex = r"^https:\/\/[a-zA-Z0-9.-]+\/?$"


@app.route('/')
def home():
    return render_template('dashboard.html')


@app.route('/scan', methods=["GET", "POST"])
def scan():
    if request.method == "POST":
        url = re.findall(url_Regex, request.form['scan_url'])
        if len(url) > 0:
            _url = url[0]
            print(f"URL submitted for the scan: {_url}")
            requests.put(
                f"http://127.0.0.1:9222/json/new?{_url}/?name=<script>alert(1)</script>")
            requests.put(
                f"http://127.0.0.1:9222/json/new?{_url}/?id=<script>alert(1)</script>")
            requests.put(
                f"http://127.0.0.1:9222/json/new?{_url}/?uname='-prompt(8)-'")
            requests.put(
                f"http://127.0.0.1:9222/json/new?{_url}/?msg='`\"><\x3Cscript>javascript:alert(1)</script>")
            return "<script>alert('URL submitted for the scan'); location.href = '/'</script>"
        else:
            return "<script>alert('not a valid URL'); location.href = '/scan'</script>"
    else:
        return render_template('scan.html', status="hidediv")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
