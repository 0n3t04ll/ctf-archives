CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE "users"
(
    id             UUID         NOT NULL PRIMARY KEY DEFAULT (uuid_generate_v4()),
    "name"         VARCHAR(100) NOT NULL,
    "email"        VARCHAR(255) NOT NULL,
    "verified"     BOOL         NOT NULL,
    "password"     VARCHAR(100),
    "idp_id"       VARCHAR(36),
    "flag"         VARCHAR(100)
);
