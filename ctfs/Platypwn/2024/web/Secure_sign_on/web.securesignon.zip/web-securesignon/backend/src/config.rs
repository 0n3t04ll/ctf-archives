use common::env::load_url;
use std::env;

#[derive(Debug, Clone)]
pub struct Config {
    pub database_url: String,
    pub jwt_secret: String,
    pub oidc_challenge_secret: String,
    pub frontend_url: String,
    pub oidc_url: String,
    pub listen_port: u16,
}

impl Config {
    pub fn init() -> Self {
        let database_url = env::var("DATABASE_URL").expect("DATABASE_URL must be set");
        let jwt_secret = env::var("JWT_SECRET").expect("JWT_SECRET must be set");
        let oidc_challenge_secret =
            env::var("OIDC_CHALLENGE_SECRET").expect("OIDC_CHALLENGE_SECRET must be set");
        let listen_port = env::var("LISTEN_PORT")
            .map(|s| s.parse())
            .expect("LISTEN_PORT must be set")
            .unwrap_or(8000);

        Self {
            database_url,
            jwt_secret,
            oidc_challenge_secret,
            frontend_url: load_url("FRONTEND"),
            oidc_url: load_url("OIDC"),
            listen_port,
        }
    }
}
