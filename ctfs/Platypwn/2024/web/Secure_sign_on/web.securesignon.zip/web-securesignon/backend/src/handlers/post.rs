use crate::errors::AppError;
use crate::jwt_auth::AuthenticatedUser;
use crate::models::{Post, PostWithUser, User};
use crate::schema::posts::dsl::{content, posts, title};
use crate::schema::posts::{id, user_id};
use crate::schema::users::dsl::users;

use crate::errors::AppErrorType::NotFound;
use crate::AppState;
use actix_web::{get, post, web, HttpResponse, Responder};
use common::{PostData, PostHeadline};
use diesel::prelude::*;
use diesel::{dsl::insert_into, ExpressionMethods, RunQueryDsl};
use log::info;
use uuid::Uuid;

#[post("/")]
async fn create_post(
    body: web::Json<PostData>,
    data: web::Data<AppState>,
    user: AuthenticatedUser,
) -> impl Responder {
    web::block(move || {
        insert_into(posts)
            .values((
                user_id.eq(user.id),
                title.eq(&body.title),
                content.eq(&body.content),
            ))
            .execute(&mut data.get_connection())
            .ok()
    })
    .await
    .map_or(
        HttpResponse::BadRequest().json("Error creating post"),
        |_| HttpResponse::Created().json("Post created"),
    )
}

#[get("/post/{post_id}")]
async fn get_post(
    post_id: web::Path<Uuid>,
    user: AuthenticatedUser,
    data: web::Data<AppState>,
) -> Result<HttpResponse, AppError> {
    let post_id = post_id.into_inner();
    info!("Getting post {} for user {}", post_id, user.id);
    web::block(move || {
        posts
            .filter(id.eq(post_id))
            .inner_join(users)
            .select((Post::as_select(), User::as_select()))
            .get_result::<(Post, User)>(&mut data.get_connection())
            .map(PostWithUser::from)
            .map(Into::into)
            .map_err(|_| NotFound.into())
    })
    .await
    .or(Err(NotFound))?
    .map(|res: PostData| HttpResponse::Ok().json(res))
}

#[get("/headlines")]
async fn get_headlines(data: web::Data<AppState>) -> Result<HttpResponse, AppError> {
    let response = web::block(move || {
        posts
            .inner_join(users)
            .select((Post::as_select(), User::as_select()))
            .load::<(Post, User)>(&mut data.get_connection())
            .map(|iter| {
                iter.into_iter()
                    .map(PostWithUser::from)
                    .map(Into::into)
                    .collect::<Vec<PostHeadline>>()
            })
    })
    .await
    .or(Err(NotFound))?
    .map_or(
        HttpResponse::BadRequest().body("Error fetching posts"),
        |res| HttpResponse::Ok().json(res),
    );
    Ok(response)
}

pub fn config(conf: &mut web::ServiceConfig) {
    let scope = web::scope("/posts")
        .service(create_post)
        .service(get_post)
        .service(get_headlines);

    conf.service(scope);
}
