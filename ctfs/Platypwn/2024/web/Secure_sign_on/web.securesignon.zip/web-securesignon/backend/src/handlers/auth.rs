use crate::AppState;
use actix_session::Session;
use actix_web::{get, HttpRequest};
use diesel::{update, ExpressionMethods, RunQueryDsl};
use rauthy_client::handler::{OidcCallbackParams, OidcSetRedirectStatus};

use common::{LoginUserSchema, RegisterUserSchema};
use diesel::prelude::*;

use crate::errors::AppError;
use crate::errors::AppErrorType::{EmailLoginFailed, InvalidOidcToken};
use crate::jwt_auth::AuthenticatedUser;
use crate::models::{retrieve_user, User};
use crate::schema::users::dsl::{email, name, password, users, verified};
use crate::schema::users::{flag, idp_id};
use actix_web::http::header;
use actix_web::{post, web, HttpResponse, Responder};
use argon2::{
    password_hash::{rand_core::OsRng, PasswordHasher, SaltString},
    Argon2, PasswordHash, PasswordVerifier,
};
use diesel::dsl::{exists, insert_into, select};
use diesel::result::Error::RollbackTransaction;
use log::{error, info};
use rauthy_client::handler::OidcCookieInsecure;
use serde_json::{json, Value};

#[post("/register")]
async fn register_user_handler(
    body: web::Json<RegisterUserSchema>,
    data: web::Data<AppState>,
) -> Result<HttpResponse, AppError> {
    web::block(move || {
        data.get_connection()
            .transaction(|connection| {
                if select(exists(users.filter(email.eq(&body.email))))
                    .get_result(connection)
                    .unwrap_or(true)
                {
                    return Err(RollbackTransaction);
                }
                let salt = SaltString::generate(&mut OsRng);

                let hashed_password = Argon2::default()
                    .hash_password(body.password.as_bytes(), &salt)
                    .expect("Error while hashing password")
                    .to_string();

                insert_into(users)
                    .values((
                        name.eq(&body.name),
                        email.eq(&body.email),
                        verified.eq(false),
                        password.eq(Some(&hashed_password)),
                    ))
                    .get_result::<User>(connection)
                    .map_err(|err| {
                        error!("Insert failed: {:?}", err);
                        RollbackTransaction
                    })
            })
            .map_err(|error| {
                error!("{error}");
                EmailLoginFailed.into()
            })
    })
    .await
    .or(Err(EmailLoginFailed))?
    .map(|_| HttpResponse::NoContent().body(""))
}

#[post("/login")]
async fn login_user_handler(
    body: web::Json<LoginUserSchema>,
    data: web::Data<AppState>,
    session: Session,
) -> Result<HttpResponse, AppError> {
    let user = retrieve_user(body.email.clone(), data.get_connection()).await?;

    info!("Checking password...");
    let pwd = user.password.ok_or(EmailLoginFailed)?;
    let parsed_hash = PasswordHash::new(pwd.as_str()).unwrap();
    Argon2::default()
        .verify_password(body.password.clone().as_bytes(), &parsed_hash)
        .or(Err(EmailLoginFailed))?;
    session.insert("user", user.id)?;
    Ok(HttpResponse::NoContent().body(""))
}

#[get("/oidc_login")]
pub async fn get_oidc_login(config: web::Data<AppState>) -> impl Responder {
    rauthy_client::handler::actix_web::validate_redirect_principal(
        None,
        config.env.oidc_challenge_secret.as_bytes(),
        OidcCookieInsecure::No,
        OidcSetRedirectStatus::Yes,
    )
    .await
}

#[get("/oidc_callback")]
pub async fn get_oidc_callback(
    req: HttpRequest,
    config: web::Data<AppState>,
    params: web::Query<OidcCallbackParams>,
    session: Session,
) -> Result<HttpResponse, AppError> {
    println!("Params: {params:?}");
    let (_cookie_str, _token_set, id_claims) = rauthy_client::handler::actix_web::oidc_callback(
        &req,
        params,
        config.env.oidc_challenge_secret.as_bytes(),
        OidcCookieInsecure::No,
    )
    .await?;
    let mut conn_a = config.get_connection();
    let mut conn_b = config.get_connection();

    let user_flag = id_claims
        .custom
        .clone()
        .and_then(|c| c.get("flag").cloned())
        .and_then(|flag_claim: Value| flag_claim.as_str().map(str::to_owned));
    let user = web::block(move || {
        users
            .filter(email.eq(&id_claims.preferred_username))
            .filter(idp_id.is_null().or(idp_id.eq(&id_claims.sub)))
            .get_result::<User>(&mut conn_a)
            .ok()
            .map_or_else(
                || {
                    let given_name = &id_claims.given_name.as_ref().ok_or(InvalidOidcToken)?;
                    insert_into(users)
                        .values((
                            email.eq(&id_claims.preferred_username),
                            name.eq(given_name),
                            verified.eq(true),
                            password.eq(None::<String>),
                            idp_id.eq(id_claims.sub.as_ref()),
                            flag.eq(&user_flag),
                        ))
                        .get_result::<User>(&mut conn_a)
                        .map_err(AppError::from)
                },
                |user| {
                    if user.idp_id.as_ref() != id_claims.sub.as_ref() {
                        update(users)
                            .set((
                                idp_id.eq(id_claims.sub.as_ref()),
                                flag.eq(&user_flag),
                                password.eq(None::<String>),
                            ))
                            .execute(&mut conn_b)
                            .map_err(AppError::from)?;
                    }
                    Ok(user)
                },
            )
    })
    .await
    .or(Err(InvalidOidcToken))??;
    session.insert("user", user.id)?;
    Ok(HttpResponse::PermanentRedirect()
        .append_header((
            header::LOCATION,
            format!("{}/profile", config.env.frontend_url),
        ))
        .finish())
}

#[post("/logout")]
async fn logout_handler(session: Session, _: AuthenticatedUser) -> impl Responder {
    session.purge();
    HttpResponse::Ok().json(json!({"status": "success"}))
}

pub fn config(cfg: &mut web::ServiceConfig) {
    let scr = web::scope("/auth")
        .service(register_user_handler)
        .service(login_user_handler)
        .service(logout_handler)
        .service(get_oidc_callback)
        .service(get_oidc_login);
    cfg.service(scr);
}
