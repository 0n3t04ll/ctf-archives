mod config;

mod errors;
mod handlers;
mod jwt_auth;
mod models;

#[rustfmt::skip]
mod schema;

use crate::handlers::{auth, health, post, user};
use actix_cors::Cors;
use actix_session::storage::CookieSessionStore;
use actix_session::SessionMiddleware;
use actix_web::cookie::Key;
use actix_web::middleware::Logger;
use actix_web::{web, App, HttpServer};
use base64::prelude::BASE64_STANDARD;
use base64::Engine;
use config::Config;
use diesel::r2d2::{ConnectionManager, Pool, PooledConnection};
use diesel::PgConnection;
use process::exit;
use rauthy_client::oidc_config::{ClaimMapping, JwtClaim, JwtClaimTyp, RauthyConfig};
use rauthy_client::provider::OidcProvider;
use rauthy_client::{DangerAcceptInvalidCerts, RauthyHttpsOnly};
use std::collections::HashSet;
use std::{env, io, process};

pub struct AppState {
    pool: Pool<ConnectionManager<PgConnection>>,
    env: Config,
}

pub type ConnectionPool = PooledConnection<ConnectionManager<PgConnection>>;

impl AppState {
    #[must_use]
    pub fn get_connection(&self) -> ConnectionPool {
        self.pool
            .get()
            .expect("Error while getting connection from pool")
    }
}

#[dotenvy::load(required = false)]
#[actix_web::main]
async fn main() -> io::Result<()> {
    if env::var_os("RUST_LOG").is_none() {
        env::set_var("RUST_LOG", "trace");
    }
    env_logger::init();

    let config = Config::init();
    let port = config.listen_port;

    rauthy_client::init_with(None, RauthyHttpsOnly::Yes, DangerAcceptInvalidCerts::Yes)
        .await
        .expect("Failed to initialize rauthy client");

    let key = Key::from(
        BASE64_STANDARD
            .decode(&config.jwt_secret)
            .expect("Invalid JWT secret")
            .as_slice(),
    );

    let rauthy_config = RauthyConfig {
        // Sets the .is_admin field for the principal based on the `ClaimMapping`.
        admin_claim: ClaimMapping::Or(vec![JwtClaim {
            typ: JwtClaimTyp::Roles,
            value: "admin".to_string(),
        }]),
        // Sets the .is_user field for the principal based on the `ClaimMapping`.
        // Without this claim, a user would not have access to this app. This is
        // used, because usually you never want to just have all your OIDC users to
        // have access to a certain application.
        user_claim: ClaimMapping::Or(vec![JwtClaim {
            typ: JwtClaimTyp::Groups,
            value: "user".to_string(),
        }]),
        // In almost all cases, this should just match the `client_id`
        allowed_audiences: HashSet::from(["frontend".to_string()]),
        client_id: "frontend".to_string(),
        // If set to 'false', tokens with a non-verified email address will be rejected.
        email_verified: false,
        // The issuer URL from your Rauthy deployment
        iss: format!("{}/auth/v1", config.oidc_url),
        // The scopes you want to request. The only mandatory which always needs to exist is
        // `openid`, the rest is optional and depending on your needs.
        scope: vec![
            "openid".to_string(),
            "email".to_string(),
            "profile".to_string(),
            "groups".to_string(),
            "flag".to_string(),
        ],
        // If set to None, the client will be treated as a public client and not provide any
        // secret to the /token endpoint after the callback. Set a secret for confidential clients.
        secret: Some("secret".to_string()),
    };
    // The redirect_uri here must match the URI of this application, where we accept and handle
    // the callback after a successful login.
    OidcProvider::setup_from_config(
        rauthy_config,
        &format!("{}/backend/auth/oidc_callback", config.oidc_url),
    )
    .await
    .expect("Configuring oidc provider failed.");

    let pool = match Pool::builder()
        .test_on_check_out(true)
        .build(ConnectionManager::<PgConnection>::new(&config.database_url))
    {
        Ok(pool) => {
            println!("\u{2705}Connection to the database is successful!");
            pool
        }
        Err(err) => {
            println!("\u{1f525} Failed to connect to the database: {err}");
            #[allow(clippy::exit, reason = "allow exit here")]
            exit(1);
        }
    };

    println!("\u{1f680} Server started successfully");

    HttpServer::new(move || {
        let cors = Cors::default()
            .allow_any_origin()
            .allow_any_method()
            .allow_any_header();
        App::new()
            .app_data(web::Data::new(AppState {
                pool: pool.clone(),
                env: config.clone(),
            }))
            .wrap(Logger::default())
            .service(
                web::scope("/backend")
                    .configure(user::config)
                    .configure(auth::config)
                    .configure(post::config)
                    .configure(health::config),
            )
            .wrap(cors)
            .wrap(
                SessionMiddleware::builder(CookieSessionStore::default(), key.clone())
                    .cookie_path("/backend".to_string())
                    .build(),
            )
    })
    .bind(("127.0.0.1", port))?
    .run()
    .await
}
