use actix_session::SessionInsertError;
use actix_web::http::StatusCode;
use actix_web::{HttpResponse, ResponseError};
use common::ErrorResponse;
use diesel::result::Error;
use log::error;
use rauthy_client::rauthy_error::RauthyError;
use std::fmt;

#[derive(Debug)]
pub enum AppErrorType {
    EmailLoginFailed,
    NotFound,
    InvalidOidcToken,
    InternalError,
}

#[derive(Debug)]
pub struct AppError {
    pub cause: Option<String>,
    pub message: Option<String>,
    pub error_type: AppErrorType,
}

impl From<AppErrorType> for AppError {
    fn from(error_type: AppErrorType) -> Self {
        Self {
            cause: None,
            message: None,
            error_type,
        }
    }
}
impl fmt::Display for AppError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{self:?}")
    }
}

impl ResponseError for AppError {
    fn status_code(&self) -> StatusCode {
        match self.error_type {
            AppErrorType::EmailLoginFailed => StatusCode::BAD_REQUEST,
            AppErrorType::InvalidOidcToken => StatusCode::UNAUTHORIZED,
            AppErrorType::InternalError => StatusCode::INTERNAL_SERVER_ERROR,
            AppErrorType::NotFound => StatusCode::NOT_FOUND,
        }
    }

    fn error_response(&self) -> HttpResponse {
        HttpResponse::build(self.status_code()).json(ErrorResponse {
            error: self.message(),
        })
    }
}

impl AppError {
    // we are handling the none. function name should match field name
    fn message(&self) -> String {
        error!(
            "{:?}, {:?}, {:?}",
            self.cause, self.message, self.error_type
        );

        match self {
            Self {
                cause: _,
                message: Some(message),
                error_type: _,
            } => message.clone(),
            Self {
                cause: _,
                message: None,
                error_type: AppErrorType::InvalidOidcToken,
            } => "Invalid oidc token".to_string(),
            Self {
                cause: _,
                message: None,
                error_type: AppErrorType::EmailLoginFailed,
            } => "Invalid email or password".to_string(),
            Self {
                cause: _,
                message: None,
                error_type: AppErrorType::NotFound,
            } => "Not found".to_string(),
            _ => "An unexpected error has occurred".to_string(),
        }
    }
}

impl From<RauthyError> for AppError {
    fn from(error: RauthyError) -> Self {
        Self {
            cause: Some(error.to_string()),
            message: None,
            error_type: AppErrorType::InvalidOidcToken,
        }
    }
}

impl From<SessionInsertError> for AppError {
    fn from(error: SessionInsertError) -> Self {
        Self {
            cause: Some(error.to_string()),
            message: None,
            error_type: AppErrorType::InternalError,
        }
    }
}
impl From<Error> for AppError {
    fn from(error: Error) -> Self {
        Self {
            cause: Some(error.to_string()),
            message: None,
            error_type: AppErrorType::InvalidOidcToken,
        }
    }
}
