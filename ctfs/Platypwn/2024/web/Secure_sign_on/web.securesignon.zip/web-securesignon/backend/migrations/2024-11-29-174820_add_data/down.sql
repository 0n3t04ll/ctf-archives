-- This file should undo anything in `up.sql`

DELETE
FROM "posts"
WHERE posts.user_id >= '123e4567-e89b-12d3-a456-000000000000'::uuid
  AND posts.user_id < '123e4567-e89b-12d3-a456-ffffffffffff'::uuid;

DELETE
FROM "users"
WHERE id >= '123e4567-e89b-12d3-a456-000000000000'::uuid
  AND id < '123e4567-e89b-12d3-a456-ffffffffffff'::uuid;
