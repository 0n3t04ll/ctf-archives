use crate::errors::AppError;
use crate::errors::AppErrorType::EmailLoginFailed;
use crate::schema;
use crate::schema::users::dsl::users;
use crate::schema::users::email;
use crate::ConnectionPool;
use actix_web::web;
use common::{AuthorData, PostData, PostHeadline, PrivateUserData};
use diesel::pg::Pg;
use diesel::prelude::*;
use log::info;
use uuid::Uuid;

#[derive(Debug, Clone, Selectable, Queryable, Insertable, Identifiable)]
#[diesel(table_name = schema::users)]
#[diesel(check_for_backend(Pg))]
pub struct User {
    pub id: Uuid,
    pub name: String,
    pub email: String,
    pub verified: bool,
    pub password: Option<String>,
    pub idp_id: Option<String>,
    pub flag: Option<String>,
}

pub async fn retrieve_user(
    user_email: String,
    mut connection: ConnectionPool,
) -> Result<User, AppError> {
    web::block(move || {
        users
            .filter(email.eq(user_email))
            .get_result::<User>(&mut connection)
            .map_err(|error| {
                info!("{error}");
                EmailLoginFailed.into()
            })
    })
    .await
    .or(Err(EmailLoginFailed))?
}

impl From<User> for AuthorData {
    fn from(value: User) -> Self {
        Self {
            name: value.name,
            email: value.email,
        }
    }
}

#[derive(Queryable, Selectable, Identifiable, Associations, Debug, PartialEq, Eq)]
#[diesel(belongs_to(User))]
#[diesel(table_name = schema::posts)]
pub struct Post {
    pub id: Uuid,
    pub title: String,
    pub content: String,
    pub user_id: Uuid,
}

pub struct PostWithUser {
    post: Post,
    user: User,
}
impl From<(Post, User)> for PostWithUser {
    fn from((post, user): (Post, User)) -> Self {
        Self { post, user }
    }
}

impl From<PostWithUser> for PostData {
    fn from(post: PostWithUser) -> Self {
        Self {
            id: post.post.id,
            title: post.post.title,
            content: post.post.content,
            author: AuthorData::from(post.user),
        }
    }
}

impl From<PostWithUser> for PostHeadline {
    fn from(post: PostWithUser) -> Self {
        Self {
            id: post.post.id,
            title: post.post.title,
            author: AuthorData::from(post.user),
        }
    }
}

impl From<User> for PrivateUserData {
    fn from(value: User) -> Self {
        Self {
            email: value.email,
            name: value.name,
            flag: value.flag,
        }
    }
}
