use actix_session::Session;
use actix_web::error::ErrorUnauthorized;
use actix_web::{dev::Payload, Error as ActixWebError};
use actix_web::{FromRequest, HttpRequest};
use core::fmt;
use serde::Serialize;
use std::future::Future;
use std::pin::Pin;

#[derive(Debug, Serialize)]
struct ErrorResponse {
    status: String,
    message: String,
}

impl fmt::Display for ErrorResponse {
    #[expect(clippy::min_ident_chars, reason = "use from trait")]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}",
            serde_json::to_string(&self).ok().unwrap_or_default()
        )
    }
}

pub struct AuthenticatedUser {
    pub id: uuid::Uuid,
}

impl FromRequest for AuthenticatedUser {
    type Error = ActixWebError;
    type Future = Pin<Box<dyn Future<Output = Result<Self, Self::Error>>>>;

    fn from_request(req: &HttpRequest, _: &mut Payload) -> Self::Future {
        let future_session = Session::extract(req);
        Box::pin(async {
            if let Some(id) = future_session.await?.get("user")? {
                return Ok(Self { id });
            }
            Err(ErrorUnauthorized(ErrorResponse {
                status: "fail".to_owned(),
                message: String::new(),
            }))
        })
    }
}
