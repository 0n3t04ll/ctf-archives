use actix_web::{get, web, HttpResponse, Responder};
use serde_json::json;

#[get("/health")]
async fn health_checker_handler() -> impl Responder {
    HttpResponse::Ok()
        .json(json!({"status": "success", "message": "The service is up and running"}))
}

pub fn config(cfg: &mut web::ServiceConfig) {
    cfg.service(health_checker_handler);
}
