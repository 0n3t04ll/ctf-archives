use crate::AppState;
use diesel::{ExpressionMethods, RunQueryDsl};

use common::{PostData, PrivateUserData};
use diesel::prelude::*;

use crate::errors::AppError;
use crate::errors::AppErrorType::NotFound;
use crate::jwt_auth::AuthenticatedUser;
use crate::models::{Post, PostWithUser, User};
use crate::schema::posts::dsl::posts;
use crate::schema::posts::user_id;
use crate::schema::users::dsl::{id, users};
use actix_web::{get, web, HttpResponse, Responder};
#[get("/")]
async fn get_userdata(
    data: web::Data<AppState>,
    user: AuthenticatedUser,
) -> Result<HttpResponse, AppError> {
    web::block(move || {
        users
            .filter(id.eq(user.id))
            .get_result(&mut data.get_connection())
    })
    .await
    .or(Err(NotFound))?
    .map(|user: User| HttpResponse::Ok().json(PrivateUserData::from(user)))
    .map_err(Into::into)
}

#[get("/posts")]
async fn get_posts(data: web::Data<AppState>, user: AuthenticatedUser) -> impl Responder {
    web::block(move || {
        posts
            .filter(user_id.eq(user.id))
            .inner_join(users)
            .select((Post::as_select(), User::as_select()))
            .get_results::<(Post, User)>(&mut data.get_connection())
            .ok()
    })
    .await
    .ok()
    .flatten()
    .map_or_else(
        || HttpResponse::BadRequest().body("Error fetching posts"),
        |res| {
            HttpResponse::Ok().json(
                res.into_iter()
                    .map(PostWithUser::from)
                    .map(Into::into)
                    .collect::<Vec<PostData>>(),
            )
        },
    )
}

pub fn config(conf: &mut web::ServiceConfig) {
    let scope = web::scope("/user").service(get_userdata).service(get_posts);

    conf.service(scope);
}
