// @generated automatically by Diesel CLI.

diesel::table! {
    posts (id) {
        id -> Uuid,
        #[max_length = 100]
        title -> Varchar,
        #[max_length = 255]
        content -> Varchar,
        user_id -> Uuid,
    }
}

diesel::table! {
    users (id) {
        id -> Uuid,
        #[max_length = 100]
        name -> Varchar,
        #[max_length = 255]
        email -> Varchar,
        verified -> Bool,
        #[max_length = 100]
        password -> Nullable<Varchar>,
        #[max_length = 36]
        idp_id -> Nullable<Varchar>,
        #[max_length = 100]
        flag -> Nullable<Varchar>,
    }
}

diesel::joinable!(posts -> users (user_id));

diesel::allow_tables_to_appear_in_same_query!(
    posts,
    users,
);
