use std::process::{Child, Command};
use std::sync::Arc;
use std::time::Duration;
use thirtyfour::common::config::WebDriverConfig;
use thirtyfour::extensions::query::ElementPollerWithTimeout;
use thirtyfour::{CapabilitiesHelper, DesiredCapabilities, WebDriver};
use tokio::time::sleep;

pub async fn start_geckodriver(
    port: u16,
    headless: bool,
) -> Result<(Child, WebDriver), Box<dyn std::error::Error>> {
    #[allow(clippy::zombie_processes)] // if something fails, you have to clean it up yourself :P
    let child = Command::new("geckodriver") // chromedriver might have bugs O:
        .arg(format!("--port={port}"))
        .spawn()
        .expect("Failed to start geckodriver");
    let mut caps = DesiredCapabilities::firefox();
    if headless {
        caps.set_headless()?;
    }
    caps.accept_insecure_certs(true)?;
    let config = WebDriverConfig::builder()
        .poller(Arc::new(ElementPollerWithTimeout::new(
            Duration::from_secs(10),
            Duration::from_micros(500),
        )))
        .build()?;
    sleep(Duration::from_secs(1)).await;
    let driver =
        WebDriver::new_with_config(format!("http://127.0.0.1:{port}"), caps, config).await?;
    Ok((child, driver))
}
