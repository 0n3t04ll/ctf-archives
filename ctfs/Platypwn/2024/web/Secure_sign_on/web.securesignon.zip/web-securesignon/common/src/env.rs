use std::env;

#[must_use]
pub fn load_url(env_var_base: &str) -> String {
    let hostname = env::var(format!("{env_var_base}_HOST"))
        .unwrap_or_else(|_| panic!("{env_var_base}_HOST must be set"));
    let port = env::var(format!("{env_var_base}_PORT"))
        .map(|p| format!(":{p}"))
        .unwrap_or_default();
    format!("https://{hostname}{port}")
}
