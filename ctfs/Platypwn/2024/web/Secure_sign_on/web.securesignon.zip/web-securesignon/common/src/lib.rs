pub mod env;

use serde::{Deserialize, Serialize};
use std::fmt::{Display, Formatter};
use uuid::Uuid;
use validator::Validate;

#[derive(Debug, Serialize, Deserialize, Default, Clone, PartialEq, Eq)]
pub struct AuthorData {
    pub name: String,
    pub email: String,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone, PartialEq, Eq)]
pub struct PrivateUserData {
    pub name: String,
    pub email: String,
    pub flag: Option<String>,
}

#[derive(Validate, Debug, Default, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct LoginUserSchema {
    #[validate(
        length(min = 1u64, message = "Email is required"),
        email(message = "Email is invalid")
    )]
    pub email: String,
    #[validate(length(min = 1u64, message = "Password is required"))]
    pub password: String,
}

#[derive(Validate, Debug, Default, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RegisterUserSchema {
    #[validate(length(min = 1, message = "Name is required"))]
    pub name: String,
    #[validate(
        length(min = 1, message = "Email is required"),
        email(message = "Email is invalid")
    )]
    pub email: String,
    #[validate(length(min = 1, message = "Password is required"))]
    pub password: String,
    #[validate(
        length(min = 1, message = "Please confirm your password"),
        must_match(other = "password", message = "Passwords do not match")
    )]
    pub password_confirm: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ErrorResponse {
    pub error: String,
}

#[derive(Validate, Debug, Default, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PostData {
    pub id: Uuid,
    pub title: String,
    pub content: String,
    pub author: AuthorData,
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq, Clone)]
pub struct PostHeadline {
    pub id: Uuid,
    pub title: String,
    pub author: AuthorData,
}

impl Display for AuthorData {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(f, "{} ({})", self.name, self.email)
    }
}
