extern crate alloc;
use alloc::rc::Rc;
use core::cell::RefCell;
use core::ops::Deref;

use crate::api::posts;
use crate::components::{form_input::FormInput, loading_button::SecureButton};
use crate::router::{self};
use crate::store::{set_show_alert, Store};

use common::PostData;
use validator::Validate;
use validator::ValidationErrors;
use wasm_bindgen_futures::spawn_local;
use web_sys::HtmlInputElement;
use yew::prelude::*;
use yew_router::prelude::*;
use yewdux::prelude::*;

fn get_input_callback(
    name: String,
    cloned_form: UseStateHandle<Rc<RefCell<PostData>>>,
) -> Callback<String> {
    Callback::from(move |value| {
        let data = cloned_form.deref().clone();
        match name.as_str() {
            "title" => data.borrow_mut().title = value,
            "content" => data.borrow_mut().content = value,
            _ => unreachable!(),
        }
    })
}

#[function_component(CreatePostPage)]
pub fn create_post() -> Html {
    let (_, dispatch) = use_store::<Store>();
    let form = use_state(|| Rc::new(RefCell::new(PostData::default())));
    let validation_errors = use_state(|| Rc::new(RefCell::new(ValidationErrors::new())));
    let navigator = use_navigator().unwrap();

    let title_input_ref = NodeRef::default();
    let content_input_ref = NodeRef::default();

    let handle_title_input = get_input_callback("title".into(), form.clone());
    let handle_content_input = get_input_callback("content".into(), form.clone());

    let on_submit = {
        let form = form.clone();
        let validation_errors = validation_errors.clone();
        let title_input_ref = title_input_ref.clone();
        let content_input_ref = content_input_ref.clone();

        Callback::from(move |event: SubmitEvent| {
            let navigator = navigator.clone();
            let dispatch = dispatch.clone();

            event.prevent_default();
            if let Some(validation_error) = form.borrow_mut().validate().err() {
                validation_errors.set(Rc::new(RefCell::new(validation_error)));
                return;
            }
            let title_input = title_input_ref.cast::<HtmlInputElement>().unwrap();
            let content_input = content_input_ref.cast::<HtmlInputElement>().unwrap();
            title_input.set_value("");
            content_input.set_value("");

            let form_json = serde_json::to_string(&*form).unwrap();
            spawn_local(async move {
                let res = posts::create(&form_json).await;
                match res {
                    Ok(()) => {
                        set_show_alert("Post created successfully".to_owned(), &dispatch);
                        navigator.push(&router::Route::Profile);
                    }
                    Err(str) => {
                        set_show_alert(str, &dispatch);
                    }
                };
            });
        })
    };

    html! {
        <section class="py-8 bg-ct-blue-600 min-h-screen grid place-items-center">
            <div class="w-full">
                <h1 class="text-4xl xl:text-6xl text-center font-[600] text-ct-yellow-600 mb-4">
                    { " Welcome to Secure Sign On!" }
                </h1>
                <h2 class="text-lg text-center mb-4 text-ct-dark-200">
                    { "Post about your favourite stuff here!" }
                </h2>
                <form
                    onsubmit={on_submit}
                    class="max-w-md w-full mx-auto overflow-hidden shadow-lg bg-ct-dark-200 rounded-2xl p-8 space-y-5"
                >
                    <FormInput<PostData>
                        label="Title"
                        name="title"
                        input_type="text"
                        input_ref={title_input_ref}
                        handle_onchange={handle_title_input}
                        errors={&*validation_errors}
                        form={&*form}
                    />
                    <FormInput<PostData>
                        label="Content"
                        name="content"
                        input_type="text"
                        input_ref={content_input_ref}
                        handle_onchange={handle_content_input}
                        errors={&*validation_errors}
                        form={&*form}
                    />
                    <SecureButton
                        text_color={Some("text-ct-blue-600".to_owned())}
                        btn_color={Some("bg-ct-yellow-600".to_owned())}
                    >
                        { "Create post" }
                    </SecureButton>
                </form>
            </div>
        </section>
    }
}
