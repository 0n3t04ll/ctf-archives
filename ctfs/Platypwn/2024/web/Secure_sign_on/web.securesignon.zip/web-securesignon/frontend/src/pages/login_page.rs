extern crate alloc;
use crate::api::user::api_login;
use crate::components::{form_input::FormInput, loading_button::SecureButton};
use crate::router::Route;
use crate::store::{set_show_alert, Store};
use alloc::rc::Rc;
use common::LoginUserSchema;
use core::cell::RefCell;
use gloo::utils::window;
use validator::{Validate, ValidationErrors};
use wasm_bindgen_futures::spawn_local;
use web_sys::HtmlInputElement;
use yew::prelude::*;
use yew_router::prelude::*;
use yewdux::prelude::*;

fn get_input_callback(
    name: &'static str,
    cloned_form: UseStateHandle<Rc<RefCell<LoginUserSchema>>>,
) -> Callback<String> {
    Callback::from(move |value| {
        let data = &*cloned_form;
        match name {
            "email" => data.borrow_mut().email = value,
            "password" => data.borrow_mut().password = value,
            _ => (),
        }
    })
}

#[function_component(LoginPage)]
pub fn login_page() -> Html {
    let (_, dispatch) = use_store::<Store>();
    let form = use_state(|| Rc::new(RefCell::new(LoginUserSchema::default())));
    let validation_errors = use_state(|| Rc::new(RefCell::new(ValidationErrors::new())));
    let navigator = use_navigator().expect("Requires navigator in parent hierarchy");

    let email_input_ref = NodeRef::default();
    let password_input_ref = NodeRef::default();

    let oidc_login = use_callback((), |_, ()| {
        window()
            .location()
            .set_href("/backend/auth/oidc_login")
            .unwrap();
    });

    let handle_email_input = get_input_callback("email", form.clone());
    let handle_password_input = get_input_callback("password", form.clone());

    let on_submit = {
        let form = form.clone();
        let validation_errors = validation_errors.clone();
        let email_input_ref = email_input_ref.clone();
        let password_input_ref = password_input_ref.clone();

        Callback::from(move |event: SubmitEvent| {
            event.prevent_default();

            let dispatch = dispatch.clone();
            let navigator = navigator.clone();

            if let Some(validation_error) = form.borrow_mut().validate().err() {
                validation_errors.set(Rc::new(RefCell::new(validation_error)));
                return;
            }
            let form_json = serde_json::to_string(&*form).unwrap();

            let email_input = email_input_ref.cast::<HtmlInputElement>().unwrap();
            let password_input = password_input_ref.cast::<HtmlInputElement>().unwrap();
            email_input.set_value("");
            password_input.set_value("");

            spawn_local(async move {
                match api_login(&form_json).await {
                    Ok(()) => {
                        navigator.push(&Route::Profile);
                    }
                    Err(err) => {
                        set_show_alert(err, &dispatch);
                    }
                };
            });
        })
    };

    html! {
        <section class="bg-ct-blue-600 min-h-screen grid place-items-center">
            <div class="w-full">
                <h1 class="text-4xl xl:text-6xl text-center font-[600] text-ct-yellow-600 mb-4">
                    { "Welcome Back" }
                </h1>
                <h2 class="text-lg text-center mb-4 text-ct-dark-200">
                    { "Login to have access" }
                </h2>
                <form
                    onsubmit={on_submit}
                    class="max-w-md w-full mx-auto overflow-hidden shadow-lg bg-ct-dark-200 rounded-2xl p-8 space-y-5"
                >
                    <FormInput<LoginUserSchema>
                        label="Email"
                        name="email"
                        input_type="email"
                        input_ref={email_input_ref}
                        handle_onchange={handle_email_input}
                        errors={&*validation_errors}
                        form={&*form}
                    />
                    <FormInput<LoginUserSchema>
                        label="Password"
                        name="password"
                        input_type="password"
                        input_ref={password_input_ref}
                        handle_onchange={handle_password_input}
                        errors={&*validation_errors}
                        form={&*form}
                    />
                    <div class="text-right">
                        <a href="#">{ "Forgot Password?" }</a>
                    </div>
                    <SecureButton
                        text_color={Some("text-ct-blue-600".to_owned())}
                        btn_color={"bg-ct-yellow-600".to_owned()}
                    >
                        { "Login" }
                    </SecureButton>
                    <button
                        id="oidc-login"
                        onclick={oidc_login}
                        class="w-full py-3 font-semibold rounded-lg outline-none border-none flex justify-center bg-ct-yellow-600"
                    >
                        <span class="text-ct-blue-600">{ "Login with OIDC provider" }</span>
                    </button>
                    <span class="block">
                        { "Need an account?" }
                        { " " }
                        <Link<Route> to={Route::Register} classes="text-ct-blue-600">
                            { "Sign Up Here" }
                        </Link<Route>>
                    </span>
                </form>
            </div>
        </section>
    }
}
