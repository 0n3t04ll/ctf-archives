use crate::components::text_container::TextContainer;
use crate::router::Route;
use common::{PostData, PostHeadline};
use yew::{function_component, html, Html, Properties, UseStateHandle};
use yew_router::prelude::Link;

#[derive(Debug, Properties, PartialEq)]
pub struct HeadlineListProps {
    pub posts: UseStateHandle<Option<Vec<PostHeadline>>>,
}

#[function_component(PostHeadlineList)]
pub fn post_headline_list_component(props: &HeadlineListProps) -> Html {
    props
        .posts
        .as_deref()
        .map_or(html! { <p class="mb-4">{ "Loading..." }</p> }, |posts| {
            html! {
                <div class="mt-8 grid gap-4 grid-cols-2 mb-4">
                    { posts.iter().map(|name| {
                            html!{<PostHeadlineComponent post={name.clone()} />}
                        }).collect::<Html>() }
                </div>
            }
        })
}

#[derive(Debug, Properties, PartialEq, Eq)]
pub struct Props {
    pub post: PostHeadline,
}

#[function_component(PostHeadlineComponent)]
pub fn render_post(props: &Props) -> Html {
    let post = &props.post;
    html! {
        <div class="flex items-start" key={post.id.to_string()}>
            <div
                class="flex flex-col w-full leading-1.5 p-4 border-gray-200 bg-slate-200 rounded-e-xl rounded-es-xl dark:bg-gray-700"
            >
                <div class="flex items-center space-x-2 rtl:space-x-reverse">
                    <Link<Route>
                        to={Route::Post { id: post.id }}
                        classes="text-sm font-semibold text-gray-900 dark:text-white"
                    >
                        { &post.title }
                    </Link<Route>>
                </div>
                <p class="text-sm font-normal py-2.5 text-gray-900 dark:text-white">
                    { post.author.to_string() }
                </p>
            </div>
        </div>
    }
}

#[derive(Debug, Properties, PartialEq, Eq)]
pub struct PostProps {
    pub post: PostData,
}

#[function_component(Post)]
pub fn post(props: &PostProps) -> Html {
    html! {
        <TextContainer title={props.post.title.clone()} content={props.post.content.clone()}>
            <p class="mt-4 italic">{ props.post.author.to_string() }</p>
        </TextContainer>
    }
}
