extern crate alloc;
use alloc::rc::Rc;
use core::cell::RefCell;
use validator::{Validate, ValidationErrors};
use wasm_bindgen::JsCast;
use web_sys::HtmlInputElement;
use yew::prelude::*;

#[derive(Properties, PartialEq)]
pub struct Props<S: PartialEq> {
    pub input_type: Option<String>,
    pub label: String,
    pub name: String,
    pub input_ref: NodeRef,
    pub handle_onchange: Callback<String>,
    pub errors: Rc<RefCell<ValidationErrors>>,
    pub form: Rc<RefCell<S>>,
}

#[function_component(FormInput)]
pub fn form_input_component<T: PartialEq + Validate + 'static>(props: &Props<T>) -> Html {
    let input_type = props
        .input_type
        .clone()
        .unwrap_or_else(|| "text".to_owned());
    let val_errors = props.errors.borrow();
    let errors = val_errors.field_errors().clone();
    let empty_errors = vec![];
    let error = errors
        .get(&props.name.as_str())
        .map_or(&empty_errors, |error| error);
    let error_message = error.first().map_or_else(String::new, ToString::to_string);

    let handle_onchange = props.handle_onchange.clone();
    let onchange = Callback::from(move |event: Event| {
        let target = event.target().unwrap();
        let value = target.unchecked_into::<HtmlInputElement>().value();
        handle_onchange.emit(value);
    });

    let handle_onchange = props.handle_onchange.clone();
    let on_blur = {
        let input_name = props.name.clone();
        let form = props.form.clone();
        let errors = props.errors.clone();

        Callback::from(move |event: FocusEvent| {
            let mut validation_errors = errors.borrow_mut();
            let target = event.target().unwrap();
            handle_onchange.emit(target.unchecked_into::<HtmlInputElement>().value());
            if let Some((key, error)) = form
                .borrow_mut()
                .validate()
                .err()
                .as_ref()
                .and_then(|errors| errors.errors().get_key_value(input_name.as_str()))
            {
                validation_errors.errors_mut().insert(key, error.to_owned());
            } else {
                validation_errors.errors_mut().remove(input_name.as_str());
            }
        })
    };

    html! {
        <div>
            <label html={props.name.clone()} class="block text-ct-blue-600 mb-3">
                { props.label.clone() }
            </label>
            <input
                type={input_type}
                name={props.name.clone()}
                placeholder=""
                class="block w-full rounded-2xl appearance-none focus:outline-none py-2 px-4"
                ref={props.input_ref.clone()}
                onchange={onchange}
                onblur={on_blur}
            />
            <span class="text-red-500 text-xs pt-1 block">{ error_message }</span>
        </div>
    }
}
