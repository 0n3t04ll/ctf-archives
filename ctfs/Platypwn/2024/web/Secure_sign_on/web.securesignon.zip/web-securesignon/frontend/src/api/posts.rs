use common::{PostData, PostHeadline};
use reqwasm::http;
use uuid::Uuid;

pub async fn create(post_data: &str) -> Result<(), String> {
    let response = http::Request::post("/backend/posts/")
        .header("Content-Type", "application/json")
        .credentials(http::RequestCredentials::Include)
        .body(post_data)
        .send()
        .await
        .or(Err("Failed to make request".to_owned()))?;

    if response.status() != 201 {
        return Err("Failed to create post!".to_owned());
    }

    Ok(())
}

pub async fn get_post_headlines() -> Result<Vec<PostHeadline>, String> {
    let response = http::Request::get("/backend/posts/headlines")
        .credentials(http::RequestCredentials::Include)
        .send()
        .await
        .or(Err("Failed to make request".to_owned()))?;

    if response.status() != 200 {
        return Err("Failed to get posts!".to_owned());
    }

    let res_json = response.json::<Vec<PostHeadline>>().await;
    res_json.map_or_else(|_| Err("Failed to parse response".to_owned()), Ok)
}

pub async fn get_post(post_id: Uuid) -> Result<PostData, String> {
    let response = http::Request::get(&format!("/backend/posts/post/{post_id}"))
        .credentials(http::RequestCredentials::Include)
        .send()
        .await
        .or(Err("Failed to make request".to_owned()))?;

    if response.status() != 200 {
        return Err("Failed to get post!".to_owned());
    }

    let res_json = response.json().await;
    res_json.map_or_else(|_| Err("Failed to parse response".to_owned()), Ok)
}
