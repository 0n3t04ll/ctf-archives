use crate::router::Route;
use yew::{function_component, html, Children, Html, Properties};
use yew_router::components::Link;

#[derive(Debug, Properties, PartialEq)]
pub struct Props {
    pub title: String,
    pub content: String,
    #[prop_or_default]
    pub children: Children,
}

#[function_component(TextContainer)]
pub fn text_container(props: &Props) -> Html {
    html! {
        <div class="p-8">
            <p class="text-3xl font-semibold text-center">{ &props.title }</p>
            <p class="mt-4">{ &props.content }</p>
            { for props.children.iter() }
        </div>
    }
}

#[derive(Debug, Properties, PartialEq)]
pub struct SubtitleProps {
    pub title: String,
    pub content: String,
    pub subtitle: String,
    pub sub_content: String,
    #[prop_or_default]
    pub children: Children,
}

#[function_component(SubtitledTextContainer)]
pub fn text_container(props: &SubtitleProps) -> Html {
    html! {
        <TextContainer title={props.title.clone()} content={props.content.clone()}>
            <p class="text-2xl font-semibold mt-4">{ &props.subtitle }</p>
            <p class="my-4">{ &props.sub_content }</p>
            { for props.children.iter() }
        </TextContainer>
    }
}

impl SubtitledTextContainer {
    pub fn restriction_banner() -> Html {
        html! {
            <Self
                title="Content Restricted"
                content="You must be signed in to view this content."
                subtitle="Secure Sign On"
                sub_content="Written in safe rust. Your privacy is our priority. All data is encrypted and stored on our secure servers. We will never share your information with anyone."
            >
                <Link<Route> to={Route::Login} classes="text-ct-dark font-semibold">
                    { "Login Now!" }
                </Link<Route>>
            </Self>
        }
    }
}
