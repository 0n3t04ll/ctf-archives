use crate::api::handle_fetch_result;
use crate::api::posts::get_post;
use crate::components::header::Header;
use crate::components::post_headline::Post;
use crate::components::text_container::SubtitledTextContainer;
use crate::store::Store;
use common::PostData;
use uuid::Uuid;
use yew::prelude::*;
use yewdux::use_store;

#[derive(Debug, Properties, PartialEq, Eq)]
pub struct PostId {
    pub post_id: Uuid,
}

#[function_component(ShowPostPage)]
pub fn show_post_page(props: &PostId) -> Html {
    let (store, dispatch) = use_store::<Store>();
    let posts = use_state(Option::<PostData>::default);
    let cloned_posts = posts.clone();
    let post_to_fetch = props.post_id;

    let user_logged_in = store.auth_user.is_some();
    use_effect_with((), move |()| {
        if user_logged_in {
            wasm_bindgen_futures::spawn_local(async move {
                let fetch_result = get_post(post_to_fetch).await;
                handle_fetch_result(fetch_result, &dispatch, &cloned_posts).await;
            });
        }
    });

    let post =
        store
            .auth_user
            .as_ref()
            .map_or_else(SubtitledTextContainer::restriction_banner, |_| {
                posts
                    .as_ref()
                    .map_or(html! { <p class="mb-4">{ "Loading..." }</p> }, |post| {
                        html! { <Post post={post.clone()} /> }
                    })
            });
    html! {
        <>
            <Header />
            <section class="bg-ct-blue-600 min-h-screen pt-20">
                <div
                    class="max-w-4xl mx-auto bg-ct-dark-100 rounded-md h-[20rem] flex justify-center items-center h-full"
                >
                    { post }
                </div>
            </section>
        </>
    }
}
