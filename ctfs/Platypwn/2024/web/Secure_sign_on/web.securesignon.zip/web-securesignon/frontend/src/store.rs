use common::PrivateUserData;
use serde::{Deserialize, Serialize};
use yewdux::prelude::*;

#[derive(Debug, Eq, Serialize, Deserialize, Default, Clone, PartialEq)]
pub struct AlertInput {
    pub show_alert: bool,
    pub alert_message: String,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone, Eq, Store, PartialEq)]
pub struct Store {
    pub auth_user: Option<PrivateUserData>,
    pub alert_input: AlertInput,
}

pub fn set_auth_user(user: Option<PrivateUserData>, dispatch: &Dispatch<Store>) {
    dispatch.reduce_mut(move |store| {
        store.auth_user = user;
    });
}

pub fn set_show_alert(message: String, dispatch: &Dispatch<Store>) {
    dispatch.reduce_mut(move |store| {
        store.alert_input = AlertInput {
            alert_message: message,
            show_alert: true,
        };
    });
}

pub fn set_hide_alert(dispatch: &Dispatch<Store>) {
    dispatch.reduce_mut(move |store| {
        store.alert_input.show_alert = false;
    });
}
