use crate::store::{set_hide_alert, Store};
use gloo::timers::callback::Timeout;
use yew::{function_component, html, use_effect_with, Html, Properties};

use yewdux::use_store;

#[derive(Debug, PartialEq, Eq, Properties)]
pub struct Props {
    pub message: String,
    pub delay_ms: u32,
}

#[function_component(AlertComponent)]
pub fn alert_component(props: &Props) -> Html {
    let (store, dispatch) = use_store::<Store>();
    let show_alert = store.alert_input.show_alert;
    let delay = props.delay_ms;

    use_effect_with::<_, _, Box<dyn FnOnce()>>((show_alert, dispatch, delay), move |params| {
        let (show_alert, dispatch, delay_ms) = params.clone();
        if show_alert {
            let handle = Timeout::new(delay_ms, move || set_hide_alert(&dispatch));
            return Box::new(|| {
                handle.cancel();
            });
        }
        Box::new(|| {})
    });

    html! {
        <div
            id="myToast"
            class={format!("fixed top-14 right-10 px-5 py-4 border-r-8 border-orange-500 bg-white drop-shadow-lg {}", if show_alert { "" } else { "hidden" })}
        >
            <p class="text-sm">
                <span
                    class="mr-2 inline-block px-3 py-1 rounded-full bg-blue-500 text-white font-extrabold"
                >
                    { "i" }
                </span>
                { props.message.clone() }
            </p>
        </div>
    }
}
