use yew::prelude::*;

#[derive(Debug, Properties, PartialEq)]
pub struct Props {
    pub btn_color: Option<String>,
    pub text_color: Option<String>,
    pub children: Children,
}

#[function_component(SecureButton)]
pub fn secure_button_component(props: &Props) -> Html {
    let text_color = props
        .text_color
        .clone()
        .unwrap_or_else(|| "text-white".to_owned());
    let btn_color = props
        .btn_color
        .clone()
        .unwrap_or_else(|| "bg-ct-yellow-600".to_owned());

    html! {
        <button
            type="submit"
            class={format!(
        "w-full py-3 font-semibold rounded-lg outline-none border-none flex justify-center {}",
         btn_color.as_str()
      )}
        >
            <span class={text_color.clone()} id="secure-button">{ props.children.clone() }</span>
        </button>
    }
}
