use crate::api::handle_fetch_result;
use crate::api::posts::get_post_headlines;
use crate::components::header::Header;
use crate::components::post_headline::PostHeadlineList;
use crate::components::text_container::SubtitledTextContainer;
use crate::store::Store;
use common::PostHeadline;
use yew::prelude::*;
use yewdux::use_store;

#[function_component(HomePage)]
pub fn home_page() -> Html {
    let (_, dispatch) = use_store::<Store>();
    let posts = use_state(Option::<Vec<PostHeadline>>::default);
    let cloned_posts = posts.clone();

    use_effect_with((), move |()| {
        wasm_bindgen_futures::spawn_local(async move {
            handle_fetch_result(get_post_headlines().await, &dispatch, &cloned_posts).await;
        });
    });
    html! {
        <>
            <Header />
            <section class="bg-ct-blue-600 min-h-screen pt-20">
                <div
                    class="max-w-4xl mx-auto bg-ct-dark-100 rounded-md h-[20rem] flex justify-center items-center h-full"
                >
                    <SubtitledTextContainer
                        title="Secure Sign On"
                        content="Written in safe rust. Trusted by an increasing number of users every second! Sign up now and start posting about your favorite things. We promise you won't be disappointed."
                        subtitle="Posts"
                        sub_content="See what the community has to say about your favorite things."
                    >
                        <PostHeadlineList posts={posts} />
                    </SubtitledTextContainer>
                </div>
            </section>
        </>
    }
}
