extern crate alloc;
use crate::api::user::api_register;
use crate::components::{form_input::FormInput, loading_button::SecureButton};
use crate::router::Route;
use crate::store::{set_show_alert, Store};
use alloc::rc::Rc;
use core::cell::RefCell;

use common::RegisterUserSchema;
use validator::Validate;
use validator::ValidationErrors;
use wasm_bindgen_futures::spawn_local;
use web_sys::HtmlInputElement;
use yew::prelude::*;
use yew_router::prelude::*;
use yewdux::prelude::*;

fn update_input_for(
    name: String,
    cloned_form: UseStateHandle<Rc<RefCell<RegisterUserSchema>>>,
) -> Callback<String> {
    Callback::from(move |value| {
        let data = &*cloned_form;
        match name.as_str() {
            "name" => data.borrow_mut().name = value,
            "email" => data.borrow_mut().email = value,
            "password" => data.borrow_mut().password = value,
            "password_confirm" => data.borrow_mut().password_confirm = value,
            _ => unreachable!("Unexpected input name: {}", name),
        }
    })
}

#[function_component(RegisterPage)]
pub fn register_page() -> Html {
    let (_, dispatch) = use_store::<Store>();
    let form = use_state(|| Rc::new(RefCell::new(RegisterUserSchema::default())));
    let validation_errors = use_state(|| Rc::new(RefCell::new(ValidationErrors::new())));
    let navigator = use_navigator().unwrap();

    let name_input_ref = NodeRef::default();
    let email_input_ref = NodeRef::default();
    let password_input_ref = NodeRef::default();
    let password_confirm_input_ref = NodeRef::default();

    let handle_name_input = update_input_for("name".to_string(), form.clone());
    let handle_email_input = update_input_for("email".to_string(), form.clone());
    let handle_password_input = update_input_for("password".to_string(), form.clone());
    let handle_password_confirm_input =
        update_input_for("password_confirm".to_string(), form.clone());

    let on_submit = {
        let form = form.clone();
        let validation_errors = validation_errors.clone();

        let name_input_ref = name_input_ref.clone();
        let email_input_ref = email_input_ref.clone();
        let password_input_ref = password_input_ref.clone();
        let password_confirm_input_ref = password_confirm_input_ref.clone();

        Callback::from(move |event: SubmitEvent| {
            let navigator = navigator.clone();
            let dispatch = dispatch.clone();

            event.prevent_default();
            if let Some(validation_error) = form.borrow_mut().validate().err() {
                validation_errors.set(Rc::new(RefCell::new(validation_error)));
                return;
            }
            let form_json = serde_json::to_string(&*form).unwrap();
            let name_input = name_input_ref.cast::<HtmlInputElement>().unwrap();
            let email_input = email_input_ref.cast::<HtmlInputElement>().unwrap();
            let password_input = password_input_ref.cast::<HtmlInputElement>().unwrap();
            let password_confirm_input = password_confirm_input_ref
                .cast::<HtmlInputElement>()
                .unwrap();

            name_input.set_value("");
            email_input.set_value("");
            password_input.set_value("");
            password_confirm_input.set_value("");

            spawn_local(async move {
                match api_register(&form_json).await {
                    Ok(()) => {
                        set_show_alert("Account registered successfully".to_owned(), &dispatch);
                        navigator.push(&Route::Login);
                    }
                    Err(str) => {
                        set_show_alert(str, &dispatch);
                    }
                };
            });
        })
    };

    html! {
        <section class="py-8 bg-ct-blue-600 min-h-screen grid place-items-center">
            <div class="w-full">
                <h1 class="text-4xl xl:text-6xl text-center font-[600] text-ct-yellow-600 mb-4">
                    { " Welcome to Secure Sign On!" }
                </h1>
                <h2 class="text-lg text-center mb-4 text-ct-dark-200">
                    { "Sign Up To Get Started!" }
                </h2>
                <form
                    onsubmit={on_submit}
                    class="max-w-md w-full mx-auto overflow-hidden shadow-lg bg-ct-dark-200 rounded-2xl p-8 space-y-5"
                >
                    <FormInput<RegisterUserSchema>
                        label="Full Name"
                        name="name"
                        input_type="text"
                        input_ref={name_input_ref}
                        handle_onchange={handle_name_input}
                        errors={&*validation_errors}
                        form={&*form}
                    />
                    <FormInput<RegisterUserSchema>
                        label="Email"
                        name="email"
                        input_type="email"
                        input_ref={email_input_ref}
                        handle_onchange={handle_email_input}
                        errors={&*validation_errors}
                        form={&*form}
                    />
                    <FormInput<RegisterUserSchema>
                        label="Password"
                        name="password"
                        input_type="password"
                        input_ref={password_input_ref}
                        handle_onchange={handle_password_input}
                        errors={&*validation_errors}
                        form={&*form}
                    />
                    <FormInput<RegisterUserSchema>
                        label="Confirm Password"
                        name="password_confirm"
                        input_type="password"
                        input_ref={password_confirm_input_ref}
                        handle_onchange={handle_password_confirm_input}
                        errors={&*validation_errors}
                        form={&*form}
                    />
                    <span class="block">
                        { "Already have an account?" }
                        { " " }
                        <Link<Route> to={Route::Login} classes="text-ct-blue-600">
                            { "Login Here" }
                        </Link<Route>>
                    </span>
                    <SecureButton
                        text_color={Some("text-ct-blue-600".to_owned())}
                        btn_color={Some("bg-ct-yellow-600".to_owned())}
                    >
                        { " Sign Up" }
                    </SecureButton>
                </form>
            </div>
        </section>
    }
}
