use crate::store::{set_show_alert, Store};
use yew::UseStateHandle;
use yewdux::Dispatch;

pub mod posts;
pub mod types;
pub mod user;

pub async fn handle_fetch_result<T>(
    result: Result<T, String>,
    dispatch: &Dispatch<Store>,
    data: &UseStateHandle<Option<T>>,
) {
    match result {
        Ok(fetched_data) => {
            data.set(Some(fetched_data));
        }
        Err(err) => {
            set_show_alert(err, dispatch);
        }
    }
}
