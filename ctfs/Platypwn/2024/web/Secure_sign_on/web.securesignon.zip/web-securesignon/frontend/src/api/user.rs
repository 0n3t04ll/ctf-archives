use common::{PostData, PrivateUserData};
use reqwasm::http;

pub async fn api_register(user_data: &str) -> Result<(), String> {
    let response = http::Request::post("/backend/auth/register")
        .header("Content-Type", "application/json")
        .body(user_data)
        .send()
        .await
        .or(Err("Failed to make request".to_owned()))?;

    if !response.ok() {
        return Err("Failed to login user!".to_owned());
    }
    Ok(())
}

pub async fn api_login(credentials: &str) -> Result<(), String> {
    let response = http::Request::post("/backend/auth/login")
        .header("Content-Type", "application/json")
        .credentials(http::RequestCredentials::Include)
        .body(credentials)
        .send()
        .await
        .or(Err("Failed to make request".to_owned()))?;

    if !response.ok() {
        return Err("Failed to login user!".to_owned());
    }
    Ok(())
}

pub async fn get_user_info() -> Result<PrivateUserData, String> {
    let response = http::Request::get("/backend/user/")
        .credentials(http::RequestCredentials::Include)
        .send()
        .await
        .or(Err("Failed to make request".to_owned()))?;

    if response.status() != 200 {
        return Err("Failed to get user info!".to_owned());
    }

    let res_json = response.json().await;
    res_json.map_or_else(|_| Err("Failed to parse response".to_owned()), Ok)
}

pub async fn logout() -> Result<(), String> {
    let response = http::Request::post("/backend/auth/logout")
        .credentials(http::RequestCredentials::Include)
        .send()
        .await
        .or(Err("Failed to make request".to_owned()))?;

    if response.status() != 200 {
        return Err("Failed to logout user!".to_owned());
    }

    Ok(())
}

pub async fn get_user_posts() -> Result<Vec<PostData>, String> {
    let response = http::Request::get("/backend/user/posts")
        .credentials(http::RequestCredentials::Include)
        .send()
        .await
        .or(Err("Failed to make request".to_owned()))?;

    if response.status() != 200 {
        return Err("Failed to get posts!".to_owned());
    }

    let res_json = response.json::<Vec<PostData>>().await;
    res_json.map_or_else(|_| Err("Failed to parse response".to_owned()), Ok)
}
