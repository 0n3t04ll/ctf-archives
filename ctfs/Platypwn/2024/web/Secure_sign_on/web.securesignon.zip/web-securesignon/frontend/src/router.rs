use crate::pages::show_post_page::ShowPostPage;
use crate::pages::{
    create_post_page::CreatePostPage, home_page::HomePage, login_page::LoginPage,
    profile_page::ProfilePage, register_page::RegisterPage,
};
use uuid::Uuid;
use yew::prelude::*;
use yew_router::prelude::*;

#[derive(Clone, Routable, PartialEq, Eq, Copy)]
pub enum Route {
    #[at("/")]
    Home,
    #[at("/register")]
    Register,
    #[at("/login")]
    Login,
    #[at("/profile")]
    Profile,
    #[at("/create-post")]
    CreatePost,
    #[at("/post/:id")]
    Post { id: Uuid },
}

pub fn switch(routes: Route) -> Html {
    match routes {
        Route::Home => html! { <HomePage /> },
        Route::Register => html! { <RegisterPage /> },
        Route::Login => html! { <LoginPage /> },
        Route::Profile => html! { <ProfilePage /> },
        Route::CreatePost => html! { <CreatePostPage /> },
        Route::Post { id } => html! { <ShowPostPage post_id={id} /> },
    }
}
