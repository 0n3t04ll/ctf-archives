use crate::{
    api::user::{get_user_info, get_user_posts},
    components::header::Header,
    router,
    store::{set_auth_user, set_show_alert, Store},
};
use common::PostData;
use yew::prelude::*;
use yew_router::prelude::use_navigator;
use yewdux::prelude::*;

fn render_post(post: &PostData) -> Html {
    html! {
        <div
            class="border-r border-b border-l border-t border-gray-400 lg:border-l lg:border-t lg:border-gray-400 bg-white rounded-b lg:rounded-b-none lg:rounded-l lg:rounded-r mb-8 flex flex-col justify-between leading-normal pad-4"
        >
            <div class="mb-8">
                <div class="text-gray-900 font-bold text-xl mb-2 px-4">{ post.title.clone() }</div>
                <p class="text-gray-700 text-base px-8">{ post.content.clone() }</p>
            </div>
        </div>
    }
}
#[function_component(ProfilePage)]
pub fn profile_page() -> Html {
    let (store, dispatch) = use_store::<Store>();
    let user_store = store.auth_user.clone();
    let posts = use_state(Option::<Vec<PostData>>::default);
    let post_store = posts.clone();
    let navigator = use_navigator().unwrap();

    use_effect_with((), move |()| {
        wasm_bindgen_futures::spawn_local(async move {
            match get_user_info().await {
                Ok(user) => {
                    set_auth_user(Some(user), &dispatch);
                    if posts.is_some() {}
                }
                Err(err) => {
                    set_show_alert(err, &dispatch);
                    navigator.push(&router::Route::Login);
                }
            }
            match get_user_posts().await {
                Ok(fetched_posts) => {
                    posts.set(Some(fetched_posts));
                }
                Err(err) => {
                    set_show_alert(err, &dispatch);
                    navigator.push(&router::Route::Login);
                }
            }
        });
    });

    html! {
        <>
            <Header />
            <section class="bg-ct-blue-600 min-h-screen pt-20">
                <div
                    class="max-w-4xl mx-auto bg-ct-dark-100 rounded-md h-[20rem] flex justify-center items-center h-full"
                >
                    <div class="pt-8">
                        <p id="profile-page-header" class="text-5xl font-semibold">
                            { "Profile Page" }
                        </p>
                        if let (Some(data), Some(posts)) = (user_store, post_store.as_deref()) {
                            <div class="mt-8">
                                <p class="mb-4">{ format!("Name: {}", data.name) }</p>
                                <p class="mb-4">{ format!("Email: {}", data.email) }</p>
                                if let Some(flag) = data.flag {
                                    <p id="flag" class="mb-4">
                                        { format!("Successfully Sent Octets: {}", flag) }
                                    </p>
                                }
                            </div>
                            if posts.is_empty() {
                                <p class="my-4 text-3xl font-semibold">
                                    { "You created no posts yet." }
                                </p>
                            } else {
                                <p class="mt-4 text-3xl font-semibold">{ "My posts" }</p>
                                <div class="mt-8">
                                    { posts.iter().map(render_post).collect::<Html>() }
                                </div>
                            }
                        } else {
                            <p class="mb-4">{ "Loading..." }</p>
                        }
                    </div>
                </div>
            </section>
        </>
    }
}
