ARG UBUNTU_REF=ubuntu:26.04@sha256:889d056d5c6c0bfb55789ff3710681d68e50713cb562d2196dc07110599c7a6f

FROM ${UBUNTU_REF} AS builder

ARG LADYBIRD_REF=3d220afc3ee3469a647304fb91098ba8aac0c912
ARG UBUNTU_LIBC_VERSION=2.43-2ubuntu2.3
ENV DEBIAN_FRONTEND=noninteractive \
    RUSTUP_HOME=/opt/rustup \
    CARGO_HOME=/opt/cargo \
    PATH=/opt/cargo/bin:${PATH} \
    CC=clang-21 \
    CXX=clang++-21

RUN apt-get update && apt-get install -y --no-install-recommends \
        build-essential \
        ca-certificates \
        clang-21 \
        cmake \
        curl \
        git \
        libedit-dev \
        libc-bin=${UBUNTU_LIBC_VERSION} \
        libc-dev-bin=${UBUNTU_LIBC_VERSION} \
        libc6=${UBUNTU_LIBC_VERSION} \
        libc6-dev=${UBUNTU_LIBC_VERSION} \
        libpsl-dev \
        lld-21 \
        nasm \
        ninja-build \
        pkg-config \
        python3 \
        python3-venv \
        tar \
        unzip \
        zip \
    && rm -rf /var/lib/apt/lists/*

RUN curl --proto '=https' --tlsv1.2 -fsSL https://sh.rustup.rs -o /tmp/rustup-init \
    && chmod 0755 /tmp/rustup-init \
    && /tmp/rustup-init -y --no-modify-path --profile minimal --default-toolchain 1.98.0 \
    && rustup component add rustfmt clippy \
    && rm /tmp/rustup-init

WORKDIR /src
RUN git init \
    && git remote add origin https://github.com/LadybirdBrowser/ladybird.git \
    && git fetch --depth 1 origin "${LADYBIRD_REF}" \
    && git checkout --detach FETCH_HEAD \
    && test "$(git rev-parse HEAD)" = "${LADYBIRD_REF}"

COPY patches/js-only.patch /tmp/js-only.patch
RUN git apply --check /tmp/js-only.patch \
    && git apply /tmp/js-only.patch

RUN python3 Meta/Utils/build_vcpkg.py

RUN cmake -S /src -B /build -G Ninja \
        -DCMAKE_BUILD_TYPE=RelWithDebInfo \
        -DCMAKE_C_COMPILER=clang-21 \
        -DCMAKE_CXX_COMPILER=clang++-21 \
        -DCMAKE_LINKER=ld.lld-21 \
        -DCMAKE_TOOLCHAIN_FILE=/src/Build/vcpkg/scripts/buildsystems/vcpkg.cmake \
        -DVCPKG_MANIFEST_DIR=/src/Meta/JSOnly \
        -DVCPKG_OVERLAY_TRIPLETS=/src/Meta/CMake/vcpkg/release-triplets \
        -DVCPKG_TARGET_TRIPLET=x64-linux-dynamic \
        -DVCPKG_HOST_TRIPLET=x64-linux-dynamic \
        -DBUILD_SHARED_LIBS=ON \
        -DBUILD_TESTING=OFF \
        -DENABLE_GUI_TARGETS=OFF \
        -DENABLE_JS_SHELL_ONLY=ON \
        -DENABLE_LAGOM_CCACHE=OFF \
        -DLADYBIRD_ENABLE_CPPTRACE=OFF \
    && cmake --build /build --target js --parallel "$(nproc)"

RUN install -d -m 0755 /bundle/lib \
    && install -m 0755 /build/bin/js /bundle/js \
    && ldd /build/bin/js \
        | awk '$2 == "=>" && $3 ~ /^\// { print $1, $3 }' \
        | while read -r soname source; do \
            case "$soname" in \
                libc.so.*|libm.so.*|libpthread.so.*|libdl.so.*|librt.so.*) continue ;; \
            esac; \
            install -m 0755 "$source" "/bundle/lib/$soname"; \
          done \
    && strip --strip-unneeded /bundle/js \
    && find /bundle/lib -maxdepth 1 -type f -exec strip --strip-unneeded '{}' ';' \
    && printf '%s\n' "${LADYBIRD_REF}" > /bundle/LADYBIRD_COMMIT

FROM ${UBUNTU_REF} AS export
COPY --from=builder /bundle/ /bundle/
