#!/bin/sh
set -eu

if [ "$#" -ne 1 ]; then
    echo "usage: $0 challenge.js" >&2
    exit 1
fi

cd /challenge

payload=$1
if [ ! -s "$payload" ]; then
    echo "missing or empty payload file: $payload" >&2
    exit 1
fi

export LD_LIBRARY_PATH=/challenge/lib
exec ./js \
    --disable-ansi-colors \
    --disable-debug-output \
    "$payload"
