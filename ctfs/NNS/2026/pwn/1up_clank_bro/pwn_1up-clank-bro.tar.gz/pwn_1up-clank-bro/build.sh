#!/bin/sh
set -eu

cd "$(dirname "$0")"

builder_image=${BUILDER_IMAGE:-nns-1up-clank-bro-builder:latest}
artifact_dir=$(mktemp -d)
trap 'rm -rf "$artifact_dir"' EXIT HUP INT TERM

docker build \
    --file Dockerfile.builder \
    --target export \
    --tag "$builder_image" \
    .
docker run --rm \
    --user "$(id -u):$(id -g)" \
    --mount "type=bind,source=$artifact_dir,target=/out" \
    "$builder_image" \
    sh -c 'cp -R /bundle/* /out/'

mkdir -p dist/lib
install -m 0755 "$artifact_dir/js" dist/js
install -m 0644 "$artifact_dir/LADYBIRD_COMMIT" dist/LADYBIRD_COMMIT
find dist/lib -mindepth 1 -maxdepth 1 -type f -delete
for library in "$artifact_dir"/lib/*; do
    install -m 0755 "$library" "dist/lib/$(basename "$library")"
done
