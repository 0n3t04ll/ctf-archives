#ifndef KPRINT_H
#define KPRINT_H
void kprintc(char);
void kprints(char *);
void kprinti(int);
#endif
