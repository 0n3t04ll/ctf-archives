#!/bin/bash -e

./assemble.py shellcode.asm shellcode
